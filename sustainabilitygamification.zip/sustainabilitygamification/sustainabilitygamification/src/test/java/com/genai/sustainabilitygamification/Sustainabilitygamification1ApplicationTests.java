package com.genai.sustainabilitygamification;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
class Sustainabilitygamification1ApplicationTests {

    @Test
    void contextLoads(ApplicationContext context) {
        assertThat(context).isNotNull();
    }
    
    @Test
    public void main() {
    	SustainabilitygamificationApplication.main(new String[] {});
    }

}
