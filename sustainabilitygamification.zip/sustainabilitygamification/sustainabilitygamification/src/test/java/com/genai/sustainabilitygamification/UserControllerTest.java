//package com.genai.sustainabilitygamification;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
//
//import java.time.LocalDateTime;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//
//import com.genai.sustainabilitygamification.controller.UserController;
//import com.genai.sustainabilitygamification.dto.LoginDto;
//import com.genai.sustainabilitygamification.entity.ChallengeEmployeeDetail;
//import com.genai.sustainabilitygamification.entity.StoreDetails;
//import com.genai.sustainabilitygamification.entity.User;
//import com.genai.sustainabilitygamification.repository.UserRepository;
//import com.genai.sustainabilitygamification.service.UserService;
//import com.genai.sustainabilitygamification.service.UserServiceImpl;
//
//@SpringBootTest(classes = UserControllerTest.class)
//class UserControllerTest {
//
//    @Mock
//    private UserService userService = new UserServiceImpl();
//    
//    @Mock
//    private UserRepository userRepository;
//
//    @InjectMocks
//    private UserController userController;
//
//    @BeforeEach
//    public void setUp() {
//        MockitoAnnotations.openMocks(User.class);
//    }
//
//    @Test
//    void testSaveSuccess() {
//        User user = new User();
//        user.setName("Test User");
//        user.setEmail("test@example.com");
//        user.setPassword("password123");
//
//        when(userService.save(user)).thenReturn("User registration successful");
//
//        String response = userController.save(user);
//        
//        assertEquals("User registration successful", response);
//    }
//
//    @Test
//    void testVerifyAccount() {
//        String otp = "123456";
//
//        when(userService.verifyAccount(otp)).thenReturn("OTP verified you can login");
//
//        ResponseEntity<String> response = userController.verifyAccount(otp);
//
//        assertEquals(HttpStatus.OK, response.getStatusCode());
//        assertEquals("OTP verified you can login", response.getBody());
//    }
//
//    @Test
//    void testRegenerateOtp_Success() {
//        when(userService.regenerateOtp()).thenReturn("Email sent... please verify account within 1 minute");
//
//        ResponseEntity<String> response = userController.regenerateOtp();
//        assertEquals(HttpStatus.OK, response.getStatusCode());
//        assertEquals("Email sent... please verify account within 1 minute", response.getBody());
//    }
//
//    @Test
//    void testLogin_Success() {
//        LoginDto loginDto = new LoginDto();
//        loginDto.setEmail("test@example.com");
//        loginDto.setPassword("password123");
//        when(userService.login(loginDto)).thenReturn("Login successful");
//        ResponseEntity<String> response = userController.login(loginDto);
//        assertEquals(HttpStatus.OK, response.getStatusCode());
//        assertEquals("Login successful", response.getBody());
//        
//        LoginDto loginDto1 = new LoginDto("test1@example.com", "password456");
//        when(userService.login(loginDto1)).thenReturn("Login successful");
//        ResponseEntity<String> response1 = userController.login(loginDto1);
//        assertEquals(HttpStatus.OK, response1.getStatusCode());
//        assertEquals("Login successful", response1.getBody());
//    }
//    
//    @Test
//    void testGetUsers() {
//    	User user = new User();
//    	List<ChallengeEmployeeDetail> challengeEmployeeDetail = new ArrayList<>();
//    	List<User> employeesUnderStoreManager = new ArrayList<>();
//    	
//    	User emp1 = new User((long)9, "Test Emp1", "emp1.example@gmail.com", "pass123", false, "123456" , LocalDateTime.now().minusSeconds(30), (long)789101);
//    	employeesUnderStoreManager.add(emp1);
//    	 ChallengeEmployeeDetail obj1 = new ChallengeEmployeeDetail();
//    	user.setId((long)1);
//    	user.setName("Test Manager123");
//    	user.setEmail("test.example@gmail.com");
//    	user.setPassword("12345678");
//    	user.setOtp("123456");
//    	user.setOtpGeneratedTime(LocalDateTime.now().minusSeconds(30));
//    	user.setEmpId((long)123);
//        user.setManagerId((long)770011);
//        user.setRole("STORE_MANAGER");
//        user.setCarbonSaving((long)100);
//        user.setDollarSaving((long)20);
//        user.setWasteSaving((long)150);
//        
//        obj1.setId((long)1);
//        obj1.setChallengeId((long)4);
//        obj1.setChallengeStatus("Enrolled");
//        obj1.setEmployeeAutoId((long)2);
//        challengeEmployeeDetail.add(obj1);
//        
//        StoreDetails storeDetails = new StoreDetails();
//        storeDetails.setId((long) 1);
//        storeDetails.setStoreName("Test Store");
//        storeDetails.setStreet("Test Street");
//        storeDetails.setCity("Test City");
//        storeDetails.setCountry("Test Country");
//        storeDetails.setState("Test State");
//        storeDetails.setZipCode("123456");
//   	 
//        
//        user.setChallengeEmployeeDetail(challengeEmployeeDetail);
//        user.setStoreDetails(storeDetails);
//        user.setEmployeesUnderStoreManager(employeesUnderStoreManager);
//        
//        List<User> lstUsers = new ArrayList<User>();
//        lstUsers.add(emp1);
//        
//        when(userController.getUsers()).thenReturn(lstUsers);
//    }
//
//    @Test
//    void testGetUser() {
//    	User user = new User();
//    	List<ChallengeEmployeeDetail> challengeEmployeeDetail = new ArrayList<>();
//    	List<User> employeesUnderStoreManager = new ArrayList<>();
//    	Optional<User> emp1 = Optional.ofNullable(new User((long)9, "Test Emp1", "emp1.example@gmail.com", "pass123", false, "789101", LocalDateTime.now().minusSeconds(30), (long)770013));
//    	employeesUnderStoreManager.add(emp1.get());
//    	 ChallengeEmployeeDetail obj1 = new ChallengeEmployeeDetail();
//    	user.setId((long)1);
//    	user.setName("Test Manager123");
//    	user.setEmail("test.example@gmail.com");
//    	user.setPassword("12345678");
//    	user.setApproved(false);
//    	user.setOtp("123456");
//    	user.setOtpGeneratedTime(LocalDateTime.now().minusSeconds(30));
//    	user.setEmpId((long)123);
//        user.setManagerId((long)770011);
//        user.setRole("STORE_MANAGER");
//        user.setCarbonSaving((long)100);
//        user.setDollarSaving((long)20);
//        user.setWasteSaving((long)150);
//        
//        obj1.setId((long)1);
//        obj1.setChallengeId((long)4);
//        obj1.setChallengeStatus("Enrolled");
//        obj1.setEmployeeAutoId((long)2);
//        challengeEmployeeDetail.add(obj1);
//        
//        StoreDetails storeDetails = new StoreDetails();
//        storeDetails.setId((long) 1);
//        storeDetails.setStoreName("Test Store");
//        storeDetails.setStreet("Test Street");
//        storeDetails.setCity("Test City");
//        storeDetails.setCountry("Test Country");
//        storeDetails.setState("Test State");
//        storeDetails.setZipCode("123456");
//   	 
//        user.setChallengeEmployeeDetail(challengeEmployeeDetail);
//        user.setStoreDetails(storeDetails);
//        user.setEmployeesUnderStoreManager(employeesUnderStoreManager);
//        
//        when(userController.getUser((long)9)).thenReturn(emp1);
//    }
//
//    @Test
//    void testEmployeesUnderStoreManager() {
//    	List<User> employeesUnderStoreManager = new ArrayList<>();
//    	Optional<User> emp1 = Optional.ofNullable(new User((long)5, "Test Emp123", "emp123.example@gmail.com", "pass1234", false, "789104", LocalDateTime.now().minusSeconds(30), (long)770013));
//    	employeesUnderStoreManager.add(emp1.get());
//    	when(userController.employeesUnderStoreManager((long)1)).thenReturn(employeesUnderStoreManager);
//    }
//    
//    @Test
//    void testManagersUnderCompany() {
//    	List<User> managersUnderCompany = new ArrayList<>();
//    	User user = new User();
//    	List<ChallengeEmployeeDetail> challengeEmployeeDetail = new ArrayList<>();
//    	List<User> employeesUnderStoreManager = new ArrayList<>();
//    	User emp1 = new User((long)9, "Test Emp1", "emp1.example@gmail.com", "pass123", false, "123456", LocalDateTime.now().minusSeconds(30), (long)770012);
//    	employeesUnderStoreManager.add(emp1);
//    	 ChallengeEmployeeDetail obj1 = new ChallengeEmployeeDetail();
//    	user.setId((long)1);
//    	user.setName("Test Manager123");
//    	user.setEmail("test.example@gmail.com");
//    	user.setPassword("12345678");
//    	user.setApproved(false);
//    	user.setOtp("123456");
//    	user.setOtpGeneratedTime(LocalDateTime.now().minusSeconds(30));
//    	user.setEmpId((long)123);
//        user.setManagerId((long)770011);
//        user.setRole("STORE_MANAGER");
//        user.setCarbonSaving((long)100);
//        user.setDollarSaving((long)20);
//        user.setWasteSaving((long)150);
//        
//        obj1.setId((long)1);
//        obj1.setChallengeId((long)4);
//        obj1.setChallengeStatus("Enrolled");
//        obj1.setEmployeeAutoId((long)2);
//        challengeEmployeeDetail.add(obj1);
//        
//        StoreDetails storeDetails = new StoreDetails();
//        storeDetails.setId((long) 1);
//        storeDetails.setStoreName("Test Store");
//        storeDetails.setStreet("Test Street");
//        storeDetails.setCity("Test City");
//        storeDetails.setCountry("Test Country");
//        storeDetails.setState("Test State");
//        storeDetails.setZipCode("123456");
//   	 
//        user.setChallengeEmployeeDetail(challengeEmployeeDetail);
//        user.setStoreDetails(storeDetails);
//        user.setEmployeesUnderStoreManager(employeesUnderStoreManager);
//        managersUnderCompany.add(user);
//        when(userController.managersUnderCompany((long)8)).thenReturn(managersUnderCompany);
//        
//    }
//    	
//}
