package com.genai.sustainabilitygamification;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.assertj.core.util.Arrays;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.genai.sustainabilitygamification.entity.Notification;
import com.genai.sustainabilitygamification.repository.NotificationRepository;
import com.genai.sustainabilitygamification.service.NotificationService;

@SpringBootTest
class NotificationTest {

	@Mock
	private NotificationRepository notificationRepository;

	@InjectMocks
	private NotificationService notificationService;

	private Notification notification1;
	private Notification notification2;

	@BeforeEach
	void setUp() {
		notificationService = new NotificationService(notificationRepository);
		MockitoAnnotations.openMocks(this);
		notification1 = new Notification();
		notification1.setId(1L);
		notification1.setIsread(false);
		notification2 = new Notification();
		notification2.setId(2L);
		notification2.setIsread(false);
	}

	@Test
	void testCreateNotification() {
		Notification notification = new Notification(1L, "sushu", 123678L, "Challenge1");

		when(notificationRepository.save(notification)).thenReturn(notification);

		Notification savedNotification = notificationService.createNotification(notification);

		assertEquals(notification, savedNotification);
	}

	@Test
	void testGetAllNotifications() {
		List<Notification> notifications = new ArrayList<>();
		notifications.add(new Notification(1L, "sushmi", 123678L, "Challenge1"));
		notifications.add(new Notification(2L, "aman", 446679L, "Challenge2"));

		when(notificationRepository.findAll()).thenReturn(notifications);

		List<Notification> retrievedNotifications = notificationService.getAllNotifications();

		assertEquals(notifications.size(), retrievedNotifications.size());
		assertEquals(notifications, retrievedNotifications);
	}

	@Test
	void testGetNotificationsByStatus() {

		List<Notification> pendingNotifications = new ArrayList<>();
		pendingNotifications.add(new Notification(1L, "Jashu", 123678L, "Challenge1"));
		when(notificationRepository.findNotificationsByStatus("enrolled")).thenReturn(pendingNotifications);

		List<Notification> retrievedNotifications = notificationService.getNotificationsByStatus("enrolled");

		assertEquals(pendingNotifications.size(), retrievedNotifications.size());
		assertEquals(pendingNotifications, retrievedNotifications);
	}

	@Test
	void testMarkAsRead() {
		Notification notification = new Notification(1L, "akhil", 123678L, "Challenge1");

		when(notificationRepository.findById(1L)).thenReturn(Optional.of(notification));

		notificationService.markAsRead(1L);

		assertEquals(true, notification.isIsread());
	}

	@Test
	void testGetNotificationsByStatusWithNonEmptyStatusAndNoMatchingNotifications() {
		when(notificationRepository.findNotificationsByStatus("enrolled")).thenReturn(Collections.emptyList());
		List<Notification> allNotifications = new ArrayList<>();
		when(notificationRepository.findAll()).thenReturn(allNotifications);
		List<Notification> retrievedNotifications = notificationService.getNotificationsByStatus("enrolled");

		assertEquals(allNotifications, retrievedNotifications);
	}

	@Test
	void testGetNotificationsByStatusWithNullStatus() {

		List<Notification> allNotifications = new ArrayList<>();
		when(notificationRepository.findAll()).thenReturn(allNotifications);

		List<Notification> retrievedNotifications = notificationService.getNotificationsByStatus(null);

		assertEquals(allNotifications, retrievedNotifications);
	}

	@Test
	void testGetNotificationsByStatusWithEmptyStatus() {

		List<Notification> allNotifications = new ArrayList<>();
		when(notificationRepository.findAll()).thenReturn(allNotifications);

		List<Notification> retrievedNotifications = notificationService.getNotificationsByStatus("");

		assertEquals(allNotifications, retrievedNotifications);
	}

	@Test
	void testMarkAsReadWithNonExistingId() {
		Long nonExistingId = 999L;

		when(notificationRepository.findById(nonExistingId)).thenReturn(Optional.empty());

		assertDoesNotThrow(() -> notificationService.markAsRead(nonExistingId));
	}

	@Test
	void testDeleteByNotificationId() {
		when(notificationRepository.findById(1L)).thenReturn(Optional.of(notification1));
		boolean result = notificationService.deleteByNotificationId(1L);
		assertTrue(result);
		verify(notificationRepository, times(1)).findById(1L);
		verify(notificationRepository, times(1)).delete(notification1);

	}

	@Test
	void testMarkAllRead() {
		List<Notification> notifications = List.of(notification1, notification2);
		when(notificationRepository.findAll()).thenReturn(notifications);

		notificationService.markAsAllRead();

		assertTrue(notification1.isIsread());
		assertTrue(notification2.isIsread());
		verify(notificationRepository, times(1)).findAll();
		verify(notificationRepository, times(1)).saveAll(notifications);
	}
}
