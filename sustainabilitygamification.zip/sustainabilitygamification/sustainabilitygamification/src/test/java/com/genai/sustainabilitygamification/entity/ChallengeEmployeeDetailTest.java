package com.genai.sustainabilitygamification.entity;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.genai.sustainabilitygamification.controller.CreateChallengesController;

@SpringBootTest
public class ChallengeEmployeeDetailTest {
	Logger logger = Logger.getLogger(CreateChallengesController.class.getSimpleName());
	
	@Test
    void testChallengeEmployeeDetailParameterizedConstructorAndGetters() {
	 ChallengeEmployeeDetail challengeEmployeeDetail = new ChallengeEmployeeDetail();
	 challengeEmployeeDetail.setId((long)1);
	 challengeEmployeeDetail.setChallengeId((long)4);
	 challengeEmployeeDetail.setChallengeStatus("Enrolled");
	 challengeEmployeeDetail.setEmployeeAutoId((long)2);
	 
	 
	 assertEquals(1, challengeEmployeeDetail.getId());
     assertEquals(4, challengeEmployeeDetail.getChallengeId());
     assertEquals("Enrolled", challengeEmployeeDetail.getChallengeStatus());
     assertEquals(2, challengeEmployeeDetail.getEmployeeAutoId());
     
     logger.log(Level.INFO, challengeEmployeeDetail.toString());
     
     
  }
}
