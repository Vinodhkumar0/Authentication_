package com.genai.sustainabilitygamification.dto;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class RegisterDtoTest {
	
	@Test
	void testRegisterDto() {
		RegisterDto registerDto = new RegisterDto();
		registerDto.setName("User1");
		registerDto.setEmail("user1.exm@gmail.com");
		registerDto.setPassword("123456");
		
		assertEquals("User1", registerDto.getName());
		assertEquals("user1.exm@gmail.com", registerDto.getEmail());
		assertEquals("123456", registerDto.getPassword());
	}
}
