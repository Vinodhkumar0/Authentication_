package com.genai.sustainabilitygamification;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.genai.sustainabilitygamification.dto.MyChallengesDto;

@SpringBootTest
public class MyChallengesDtoTest {
	
	    @Test
	    void testMyChallengesParameterizedConstructorAndGetters() {
		 MyChallengesDto myChallengesDto1 = new MyChallengesDto();
		 myChallengesDto1.setOngoingChallenges(7);
		 myChallengesDto1.setOwnedChallenges(4);
		 myChallengesDto1.setCompletedChallenges(10);
		 
		 assertEquals(10, myChallengesDto1.getCompletedChallenges());
	     assertEquals(7, myChallengesDto1.getOngoingChallenges());
	     assertEquals(4, myChallengesDto1.getOwnedChallenges());
		 
		 MyChallengesDto myChallengesDto2 = new MyChallengesDto(2, 4, 6);
		 assertEquals(2, myChallengesDto2.getCompletedChallenges());
	     assertEquals(4, myChallengesDto2.getOngoingChallenges());
	     assertEquals(6, myChallengesDto2.getOwnedChallenges());
	    }


}
