package com.genai.sustainabilitygamification;


import com.genai.sustainabilitygamification.entity.ParticipateTab;
import com.genai.sustainabilitygamification.repository.ParticipateRepo;
import com.genai.sustainabilitygamification.service.ParticipateServiceImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDate;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@SpringBootTest
class ParticipateServiceImplTest {
    @Mock
    private ParticipateRepo participateRepo;
    @InjectMocks
    private ParticipateServiceImpl participateService;

    @BeforeEach
    public void init() {
        MockitoAnnotations.openMocks(ParticipateTab.class);
    }


    @Test
    void testGetParticipateById() {
        ParticipateTab expectedParticipate = new ParticipateTab(1, "Sustainability Challenge", LocalDate.now(), LocalDate.now(), " By Me", "defaultEnrolled", "company");
        when(participateRepo.findById(Mockito.anyInt())).thenReturn(Optional.of(expectedParticipate));
        ParticipateTab actualParticipate = participateService.getParticipateById(1);
        assertEquals(expectedParticipate, actualParticipate);
    }

    @Test
    void testGetParticipateList() {
        when(participateRepo.findAll()).thenReturn(Arrays.asList(
                new ParticipateTab(1, "Sustainability Challenge", LocalDate.now(), LocalDate.now(), "Featured By Me", "enrolled", "company")
        ));
        List<ParticipateTab> participateList = participateService.getParticipateList();
        assertEquals(1, participateList.size());
        ParticipateTab participate = participateList.get(0);
        assertEquals(1, participate.getChallengeId());
        assertEquals("Sustainability Challenge", participate.getChallengeName());
        assertEquals("Featured By Me", participate.getFeaturedBy());
    }

    @Test
    void testGetParticipateList_EmptyList() {
        when(participateRepo.findAll()).thenReturn(new ArrayList<>());
        List<ParticipateTab> actualList = participateService.getParticipateList();
        Assertions.assertTrue(actualList.isEmpty());
    }

}