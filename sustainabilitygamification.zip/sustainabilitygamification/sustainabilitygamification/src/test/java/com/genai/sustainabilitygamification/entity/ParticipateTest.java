package com.genai.sustainabilitygamification.entity;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ParticipateTest {
	
	@Test
    void testParticipateParameterizedConstructorAndGetters() {
		
		Participate participate = new Participate();
		String employeeId = "123456";
		LocalDate startDate = LocalDate.of(2024, 4, 1);
		List<MyProgress> myProgressList = Arrays.asList(new MyProgress(1L, startDate, 100.0, 10.0));
		participate.setId((long)1);
		participate.setChallengeName("Test Challenge");
		participate.setChallengeStatus("Default Enrolled");
		participate.setEmployeeId(employeeId);
		participate.setCreatedBy("COMPANY");
		participate.setStartDate(LocalDate.of(2024, 2, 20));
		participate.setEndDate(LocalDate.of(2024, 5, 16));	
		participate.setFeaturedBy("Featured by ABC Campaign");
		participate.setMyProgress(myProgressList);
		
		assertEquals(1, participate.getId());
	    assertEquals("Test Challenge", participate.getChallengeName());
	    assertEquals("Default Enrolled", participate.getChallengeStatus());
	    assertEquals("123456", participate.getEmployeeId());
	    assertEquals("COMPANY", participate.getCreatedBy());
	    assertEquals(LocalDate.of(2024, 2, 20), participate.getStartDate());
   	    assertEquals(LocalDate.of(2024, 5, 16), participate.getEndDate());
	    assertEquals("Featured by ABC Campaign", participate.getFeaturedBy());
	    
	    participate.getMyProgress().stream().forEach(i-> {
	    	 assertEquals(1, i.getId());
	    	 assertEquals(LocalDate.of(2024, 4, 1), i.getDate());
	    	 assertEquals(100.0, i.getSales());
	    	 assertEquals(10.0, i.getAmountPackagingPurchased());
	     });
	    
	    Participate participate1 = new Participate((long)2, 
	    		"Test Challenge1", LocalDate.of(2024, 7, 22), 
	    		LocalDate.of(2024, 10, 24), "Featured by DEF Campaign", "Enrolled", "COMPANY", employeeId, myProgressList);
	    
	    assertEquals(2, participate1.getId());
	    assertEquals("Test Challenge1", participate1.getChallengeName());
	    assertEquals("Enrolled", participate1.getChallengeStatus());
	    assertEquals("123456", participate1.getEmployeeId());
	    assertEquals("COMPANY", participate.getCreatedBy());
	    assertEquals(LocalDate.of(2024, 7, 22), participate1.getStartDate());
   	    assertEquals(LocalDate.of(2024, 10, 24), participate1.getEndDate());
	    assertEquals("Featured by DEF Campaign", participate1.getFeaturedBy());
	    
	    participate1.getMyProgress().stream().forEach(i-> {
	    	 assertEquals(1, i.getId());
	    	 assertEquals(LocalDate.of(2024, 4, 1), i.getDate());
	    	 assertEquals(100.0, i.getSales());
	    	 assertEquals(10.0, i.getAmountPackagingPurchased());
	     });
	    
	}
}
