package com.genai.sustainabilitygamification;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import com.genai.sustainabilitygamification.dto.MySavingsDto;
@SpringBootTest
public class MySavingsDtoTest {
	
    @Test
    void testMySavingsDtoParameterizedConstructorAndGetters() { 
    	MySavingsDto mySavingsDto = new MySavingsDto();
    	MySavingsDto mySavingsDto1 = new MySavingsDto((long)4, (long)6, (long)150);
    	
    	mySavingsDto.setDollarSavings((long)3);
    	mySavingsDto.setWasteSavings((long)5);
    	mySavingsDto.setCo2Savings((long)100);
    	
    	assertEquals(3, mySavingsDto.getDollarSavings());
		assertEquals(5, mySavingsDto.getWasteSavings());
		assertEquals(100, mySavingsDto.getCo2Savings());
		
		assertEquals(4, mySavingsDto1.getDollarSavings());
		assertEquals(6, mySavingsDto1.getWasteSavings());
		assertEquals(150, mySavingsDto1.getCo2Savings());
    }

}
