package com.genai.sustainabilitygamification;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.genai.sustainabilitygamification.controller.MyProgressController;
import com.genai.sustainabilitygamification.dto.MyProgressDto;
import com.genai.sustainabilitygamification.entity.MyProgress;
import com.genai.sustainabilitygamification.service.MyProgressService;


class MyProgressTest {

	@Mock
	private MyProgressService myProgressService;

	@InjectMocks
	private MyProgressController myProgressController;

	@BeforeEach
	public void setup() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testGetProgressByEmployeeId() {

		String employeeId = "123";
		List<MyProgressDto> progressDtos = List.of(new MyProgressDto(), new MyProgressDto());

		when(myProgressService.getProgressByEmployeeId(employeeId)).thenReturn(progressDtos);

		ResponseEntity<List<MyProgressDto>> responseEntity = myProgressController.getPreogressByemployeeId(employeeId);

		assertSame(HttpStatus.OK, responseEntity.getStatusCode());
		assertSame(progressDtos, responseEntity.getBody());
	}
	
	@Test
	void testGetterSetters() {

		MyProgress myProgress = new MyProgress();
		myProgress.setId((long)2);
		myProgress.setAmountPackagingPurchased((long)100);
		myProgress.setCo2savings((long)150);
		myProgress.setDate(LocalDate.of(2024, 4, 1));
		myProgress.setDollerSavings((long)4);
		myProgress.setSales((long)300);
		myProgress.setWasteSavings((long)50);
		
		assertEquals(2, myProgress.getId());
		assertEquals(100, myProgress.getAmountPackagingPurchased());
		assertEquals(150, myProgress.getCo2savings());
		assertEquals(LocalDate.of(2024, 4, 1), myProgress.getDate());
		assertEquals(4, myProgress.getDollerSavings());
		assertEquals(300, myProgress.getSales());
		assertEquals(50, myProgress.getWasteSavings());
	}
	
	@Test
	void testCalculatedGetterSetters() {
		MyProgress myProgress = new MyProgress();
		myProgress.setCo2savings((long)200, 50);
		myProgress.setWasteSavings((long)300, 60);
		myProgress.setDollerSavings((long)600, 70);
		myProgress.setProgressPercentage(70);
		
		assertEquals(5000, myProgress.getCo2savings());
		assertEquals(36000, myProgress.getWasteSavings());
		assertEquals(42000, myProgress.getDollerSavings());
		assertEquals(70, myProgress.getProgressPercentage());
		
	}
}
