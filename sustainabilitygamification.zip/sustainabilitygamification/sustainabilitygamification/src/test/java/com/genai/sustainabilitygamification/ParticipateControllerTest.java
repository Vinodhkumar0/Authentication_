package com.genai.sustainabilitygamification;


import com.genai.sustainabilitygamification.controller.ParticipateController;
import com.genai.sustainabilitygamification.entity.ParticipateTab;
import com.genai.sustainabilitygamification.service.ParticipateService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cglib.core.Local;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest
class ParticipateControllerTest {
    @Mock
    private ParticipateService participateService;
    @InjectMocks
    private ParticipateController participateController;

    @BeforeEach
    public void init() {
        MockitoAnnotations.openMocks(ParticipateTab.class);
    }

    @Test
    void testGetParticipateList() {
        List<ParticipateTab> expectedList = new ArrayList<>();
        expectedList.add(new ParticipateTab(1, "Sustainability Challenge", LocalDate.now(), LocalDate.now(), "Featured By Me", "enrolled", "company"));
        Mockito.when(participateService.getParticipateList()).thenReturn(expectedList);
        List<ParticipateTab> actualList = participateController.getParticipateList();
        assertEquals(expectedList.size(), actualList.size());
        assertEquals(expectedList.get(0), actualList.get(0));
    }

    @Test
    void testGetParticipate() {
        ParticipateTab expectedParticipate = new ParticipateTab(1, "Sustainability Challenge", LocalDate.now(), LocalDate.now(), "Featured By Me", "enrolled", "company");
        Mockito.when(participateService.getParticipateById(1)).thenReturn(expectedParticipate);
        ResponseEntity<ParticipateTab> responseEntity = participateController.getParticipate(1); // Assuming ID 1
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(expectedParticipate, responseEntity.getBody());
    }
}
