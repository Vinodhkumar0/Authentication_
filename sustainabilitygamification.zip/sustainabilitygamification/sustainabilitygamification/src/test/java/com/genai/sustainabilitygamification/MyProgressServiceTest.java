package com.genai.sustainabilitygamification;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.genai.sustainabilitygamification.dto.MyProgressDto;
import com.genai.sustainabilitygamification.entity.MyProgress;
import com.genai.sustainabilitygamification.entity.Participate;
import com.genai.sustainabilitygamification.repository.ParticipateRepository;
import com.genai.sustainabilitygamification.service.MyProgressService;



class MyProgressServiceTest {

	@Mock
	private ParticipateRepository participateRepository;

	@InjectMocks
	private MyProgressService myProgressService;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testGetProgressByEmployeeId_EmptyList() {
		String employeeId = "employee123";
		when(participateRepository.findByEmployeeId(employeeId)).thenReturn(new ArrayList<>());

	
		List<MyProgressDto> progressList = myProgressService.getProgressByEmployeeId(employeeId);

	
		assertEquals(0, progressList.size());
	}

	@Test
	void testGetProgressByEmployeeId_SingleParticipate() {
		
		String employeeId = "employee123";
		LocalDate startDate = LocalDate.of(2024, 4, 1);
		List<MyProgress> myProgressList = Arrays.asList(new MyProgress(1L, startDate, 100.0, 10.0));
		Participate p = new Participate();
		p.setChallengeStatus("enrolled");
		p.setStartDate(startDate);
		p.setMyProgress(myProgressList);
		List<Participate> participateList = Arrays.asList(p);
		when(participateRepository.findByEmployeeId(employeeId)).thenReturn(participateList);

		
		List<MyProgressDto> progressList = myProgressService.getProgressByEmployeeId(employeeId);

		
		assertEquals(1, progressList.size());
		assertEquals(1000, progressList.get(0).getDollerSavings());
		assertEquals(2000, progressList.get(0).getWasteSavings());
		assertEquals(500, progressList.get(0).getCo2Savings());
		assertEquals(1, progressList.get(0).getWeeknumber());
	}

	@Test
	void testGetProgressByEmployeeId_MultipleParticipates() {
		
	        String employeeId = "employee123";
	        LocalDate startDate = LocalDate.of(2024, 4, 1);
	        
	        List<MyProgress> myProgressList1 = Arrays.asList(new MyProgress(1L, startDate, 100.0, 10.0));
	        Participate p1 = new Participate();
	        p1.setChallengeStatus("enrolled");
	        p1.setStartDate(startDate);
	        p1.setMyProgress(myProgressList1);

	        List<MyProgress> myProgressList2 = Arrays.asList(new MyProgress(2L, startDate.plusDays(7), 80.0, 8.0));
	        Participate p2 = new Participate();
	        p2.setChallengeStatus("defaultenrolled");
	        p2.setStartDate(startDate.plusDays(7));
	        p2.setMyProgress(myProgressList2);

	        List<Participate> participateList = Arrays.asList(p1, p2);
	        when(participateRepository.findByEmployeeId(employeeId)).thenReturn(participateList);

	        List<MyProgressDto> progressList = myProgressService.getProgressByEmployeeId(employeeId);

	        assertEquals(2, progressList.size());
	        assertEquals(1000, progressList.get(0).getDollerSavings());
	        assertEquals(2000, progressList.get(0).getWasteSavings());
	        assertEquals(500, progressList.get(0).getCo2Savings());
	        assertEquals(1, progressList.get(0).getWeeknumber());

	        assertEquals(640, progressList.get(1).getDollerSavings());
	        assertEquals(1280, progressList.get(1).getWasteSavings());
	        assertEquals(320, progressList.get(1).getCo2Savings());
	        assertEquals(2, progressList.get(1).getWeeknumber());
	    }
	
	@Test
	void testGetProgressSetterGetters() {
		MyProgressDto myProgressDto = new MyProgressDto();
		myProgressDto.setCo2Savings((long)200);
		myProgressDto.setDollerSavings((long)15);
		myProgressDto.setWasteSavings((long)3);
		myProgressDto.setWeeknumber(5);
		
		assertEquals((long)15, myProgressDto.getDollerSavings());
        assertEquals((long)3, myProgressDto.getWasteSavings());
        assertEquals((long)200, myProgressDto.getCo2Savings());
        assertEquals(5, myProgressDto.getWeeknumber());
		
		
	}
}
