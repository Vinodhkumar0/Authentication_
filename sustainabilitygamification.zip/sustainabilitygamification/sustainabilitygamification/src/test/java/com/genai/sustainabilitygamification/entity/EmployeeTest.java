package com.genai.sustainabilitygamification.entity;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class EmployeeTest {
	
	@Test
    void testChallengeEmployeeDetailParameterizedConstructorAndGetters() {
	 Employee employee = new Employee();
	 employee.setUserId(4);
	 employee.setName("Test Employee");
	 employee.setEmail("test.emp@gmail.com");
	 
	 ParticipateTab participateTab = new ParticipateTab();
	 List<ParticipateTab> lstParticipateTab = new ArrayList();
	 participateTab.setChallengeId(1);
	 participateTab.setChallengeName("Test Challenge");
	 participateTab.setChallengeStatus("Default Enrolled");
	 participateTab.setCreatedBy("COMPANY");
	 participateTab.setStartDate(LocalDate.of(2024, 1, 12));
	 participateTab.setEndDate(LocalDate.of(2024, 7, 24));
	 lstParticipateTab.add(participateTab);
	 
	 employee.setParticipateTabs(lstParticipateTab);
	 
	 assertEquals(4, employee.getUserId());
     assertEquals("Test Employee", employee.getName());
     assertEquals("test.emp@gmail.com", employee.getEmail());
     
     employee.getParticipateTabs().stream().forEach(i-> {
    	 assertEquals(1, i.getChallengeId());
    	 assertEquals("Test Challenge", i.getChallengeName());
    	 assertEquals("Default Enrolled", i.getChallengeStatus());
    	 assertEquals("COMPANY", i.getCreatedBy());
    	 assertEquals("COMPANY", i.getCreatedBy());
    	 assertEquals(LocalDate.of(2024, 1, 12), i.getStartDate());
    	 assertEquals(LocalDate.of(2024, 7, 24), i.getEndDate());
     });
     
     ParticipateTab participateTab1 = new ParticipateTab();
	 List<ParticipateTab> lstParticipateTab1 = new ArrayList();
	 participateTab1.setChallengeId(2);
	 participateTab1.setChallengeName("Test Challenge1");
	 participateTab1.setChallengeStatus("Save Draft");
	 participateTab1.setCreatedBy("STORE_MANAGER");
	 participateTab1.setStartDate(LocalDate.of(2024, 2, 20));
	 participateTab1.setEndDate(LocalDate.of(2024, 5, 16));
	 lstParticipateTab1.add(participateTab1);
	 
	 Employee employee1 = new Employee(3, "Test Employee1", "test.emp1@gmail.com", lstParticipateTab1);
	 assertEquals(3, employee1.getUserId());
     assertEquals("Test Employee1", employee1.getName());
     assertEquals("test.emp1@gmail.com", employee1.getEmail());
     
     employee1.getParticipateTabs().stream().forEach(i-> {
    	 assertEquals(2, i.getChallengeId());
    	 assertEquals("Test Challenge1", i.getChallengeName());
    	 assertEquals("Save Draft", i.getChallengeStatus());
    	 assertEquals("STORE_MANAGER", i.getCreatedBy());
    	 assertEquals(LocalDate.of(2024, 2, 20), i.getStartDate());
    	 assertEquals(LocalDate.of(2024, 5, 16), i.getEndDate());
     });
     
     
     
  }
}
