//package com.genai.sustainabilitygamification;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertFalse;
//import static org.junit.jupiter.api.Assertions.assertThrows;
//import static org.junit.jupiter.api.Assertions.assertTrue;
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.ArgumentMatchers.anyLong;
//import static org.mockito.ArgumentMatchers.anyString;
//import static org.mockito.Mockito.never;
//import static org.mockito.Mockito.times;
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
//
//import java.time.LocalDateTime;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//import java.util.logging.Level;
//import java.util.logging.Logger;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.Mockito;
//import org.springframework.boot.test.context.SpringBootTest;
//
//import com.genai.sustainabilitygamification.dto.LoginDto;
//import com.genai.sustainabilitygamification.entity.ChallengeEmployeeDetail;
//import com.genai.sustainabilitygamification.entity.Notification;
//import com.genai.sustainabilitygamification.entity.StoreDetails;
//import com.genai.sustainabilitygamification.entity.User;
//import com.genai.sustainabilitygamification.repository.NotificationRepository;
//import com.genai.sustainabilitygamification.repository.UserRepository;
//import com.genai.sustainabilitygamification.service.NotificationService;
//import com.genai.sustainabilitygamification.service.UserServiceImpl;
//import com.genai.sustainabilitygamification.util.EmailUtil;
//import com.genai.sustainabilitygamification.util.OtpUtil;
//
//import jakarta.mail.MessagingException;
//
//@SpringBootTest(classes = UserServiceImplTest.class)
//class UserServiceImplTest {
//
//    @InjectMocks
//    UserServiceImpl userService;
//    @Mock
//    private UserRepository userRepository;
//    
//    @Mock
//    private NotificationRepository notificationRepository;
//    
//    @Mock
//    private NotificationService notificationService;
//    @Mock 
//    private OtpUtil otpUtil;
//    @Mock
//    private EmailUtil emailUtil;
//    
//    Logger logger = Logger.getLogger(UserServiceImplTest.class.getSimpleName());
//    private User user;
//    @BeforeEach
//    void setUp() {
//        user = new User();
//        user.setId(1L);
//        user.setName("Test User");
//    }
//
//	@Test
//	void testSave_storeDetailsIsNotNull() throws MessagingException {
//		User user = new User();
//		user.setName("Test User");
//		user.setEmail("test@example.com");
//		user.setPassword("password");
//
//		StoreDetails storeDetails = new StoreDetails();
//		storeDetails.setStoreName("Test Store");
//		storeDetails.setStreet("XYZ Street");
//		storeDetails.setCity("Test City");
//		storeDetails.setState("Test state");
//		storeDetails.setCountry("India");
//		storeDetails.setStoreManagerId(user.getId());
//
//		user.setStoreDetails(storeDetails);
//
//		String otp = "123456";
//		when(otpUtil.generateOtp()).thenReturn(otp);
//		String result = userService.save(user);
//		verify(emailUtil).sendOtpEmail("test@example.com", "123456");
//		verify(userRepository).save(any(User.class));
//		assertEquals(result, "User registered. OTP is sent to " + user.getEmail());
//	}
//
//	@Test
//	void testSave_storeDetailsIsNull() throws MessagingException {
//		User user = new User();
//		user.setName("Test User");
//		user.setEmail("test@example.com");
//		user.setPassword("password");
//		user.setEmpId(67890L);
//		user.setStoreDetails(null);
//		
//		
//		String otp = "123456";
//		when(otpUtil.generateOtp()).thenReturn(otp);
//		String result = userService.save(user);
//		verify(emailUtil).sendOtpEmail("test@example.com", "123456");
//		verify(userRepository).save(any(User.class));
//		Notification notification = new Notification();
//		notification.setEmpName(user.getName());
//		notification.setEmpId(user.getEmpId());
//		notification.setIsread(false);
//		notification.setStatus("registered");
//		notificationService.createNotification(notification);
//		assertEquals(result, "User registered. OTP is sent to " + user.getEmail());
//	}
//
//	@Test
//	void testSave_userIsNull() throws MessagingException {
//		User user = null;
//
//		String result = userService.save(user);
//
//		assertEquals(result, "User information is incomplete. Please try again.");
//	}
//
//	@Test
//	void testVerifyAccount_ValidOtp() {
//		User user = new User();
//		user.setEmail("test@example.com");
//		user.setOtp("123456");
//		user.setOtpGeneratedTime(LocalDateTime.now().minusSeconds(30));
//		user.setApproved(false);
//		user.setEmpId((long) 177223);
//		user.setManagerId((long) 0);
//		user.setRole("STORE_MANAGER");
//		user.setCarbonSaving((long) 200);
//		user.setDollarSaving((long) 40);
//		user.setWasteSaving((long) 100);
//
//		when(userRepository.findTheLatestEmail()).thenReturn(user);
//		assertEquals("OTP verified you can login", userService.verifyAccount(user.getOtp()));
//		assertEquals(false, user.isApproved());
//		verify(userRepository).save(user);
//	}
//
//	@Test
//	void testVerifyAccount_InvalidOtp() {
//		User user = new User();
//		user.setEmail("test@example.com");
//		user.setOtp("123456");
//		user.setOtpGeneratedTime(LocalDateTime.now().minusSeconds(30));
//		user.setApproved(false);
//		user.setEmpId((long) 123);
//		user.setManagerId((long) 770011);
//		user.setRole("EMPLOYEE");
//		user.setCarbonSaving((long) 100);
//		user.setDollarSaving((long) 20);
//		user.setWasteSaving((long) 150);
//
//		when(userRepository.findTheLatestEmail()).thenReturn(user);
//		assertEquals("Please regenerate otp and try again", userService.verifyAccount("654321"));
//		assertEquals(false, user.isApproved());
//		verify(userRepository, never()).save(user);
//	}
//
//	@Test
//	void testRegenerateOtpSuccess() throws MessagingException {
//		User user = new User();
//		user.setEmail("test@example.com");
//		Mockito.when(userRepository.findTheLatestEmail()).thenReturn(user);
//		Mockito.when(otpUtil.generateOtp()).thenReturn("654321");
//
//		String result = userService.regenerateOtp();
//
//		assertEquals("Email sent... please verify account within 1 minute", result);
//		assertEquals("654321", user.getOtp());
//		Mockito.verify(emailUtil).sendOtpEmail("test@example.com", "654321");
//		Mockito.verify(userRepository).save(user);
//	}
//
//	@Test
//	void testLogin_ValidCredentials() {
//		User user = new User();
//		user.setEmail("test@example.com");
//		user.setPassword("password");
//		user.setApproved(true);
//		when(userRepository.findByEmail(anyString())).thenReturn(Optional.of(user));
//		LoginDto loginDto = new LoginDto();
//		loginDto.setEmail(user.getEmail());
//		loginDto.setPassword(user.getPassword());
//		assertEquals("Login successful", userService.login(loginDto));
//	}
//
//	@Test
//	void testLogin_IncorrectPassword() {
//		User user = new User();
//		user.setEmail("test@example.com");
//		user.setPassword("password");
//		user.setApproved(true);
//		when(userRepository.findByEmail(anyString())).thenReturn(Optional.of(user));
//		LoginDto loginDto = new LoginDto();
//		loginDto.setEmail(user.getEmail());
//		loginDto.setPassword("wrong_password");
//		assertEquals("Password is incorrect", userService.login(loginDto));
//	}
//
//	@Test
//	void testLogin_UserNotFound() {
//		String email = "xyz@example.com";
//		String password = "password";
//		when(userRepository.findByEmail(email)).thenReturn(Optional.empty());
//		LoginDto loginDto = new LoginDto();
//		loginDto.setEmail(email);
//		loginDto.setPassword(password);
//
//		assertThrows(RuntimeException.class, () -> userService.login(loginDto));
//	}
//
//	@Test
//	void testLogin_AccountNotVerified() {
//		User user = new User();
//		user.setEmail("test@example.com");
//		user.setPassword("password");
//		user.setApproved(false);
//		when(userRepository.findByEmail(anyString())).thenReturn(Optional.of(user));
//		LoginDto loginDto = new LoginDto();
//		loginDto.setEmail(user.getEmail());
//		loginDto.setPassword(user.getPassword());
//		assertEquals("your account is not verified", userService.login(loginDto));
//	}
//
//	@Test
//	void testUserGetterSetters() {
//		User user = new User();
//		List<ChallengeEmployeeDetail> challengeEmployeeDetail = new ArrayList<>();
//		List<User> employeesUnderStoreManager = new ArrayList<>();
//		User emp1 = new User((long) 9, "Test Emp1", "emp1.example@gmail.com", "pass123", false, "789101",
//				LocalDateTime.now().minusSeconds(30), null);
//		employeesUnderStoreManager.add(emp1);
//		ChallengeEmployeeDetail obj1 = new ChallengeEmployeeDetail();
//		user.setId((long) 1);
//		user.setName("Test Manager123");
//		user.setEmail("test.example@gmail.com");
//		user.setPassword("12345678");
//		user.setApproved(false);
//		user.setOtp("123456");
//		user.setOtpGeneratedTime(LocalDateTime.now().minusSeconds(30));
//		user.setEmpId((long) 123);
//		user.setManagerId((long) 770011);
//		user.setRole("STORE_MANAGER");
//		user.setCarbonSaving((long) 100);
//		user.setDollarSaving((long) 20);
//		user.setWasteSaving((long) 150);
//
//		obj1.setId((long) 1);
//		obj1.setChallengeId((long) 4);
//		obj1.setChallengeStatus("Enrolled");
//		obj1.setEmployeeAutoId((long) 2);
//		challengeEmployeeDetail.add(obj1);
//
//		StoreDetails storeDetails = new StoreDetails();
//		storeDetails.setId((long) 1);
//		storeDetails.setStoreName("Test Store");
//		storeDetails.setStreet("Test Street");
//		storeDetails.setCity("Test City");
//		storeDetails.setCountry("Test Country");
//		storeDetails.setState("Test State");
//		storeDetails.setZipCode("123456");
//
//		user.setChallengeEmployeeDetail(challengeEmployeeDetail);
//		user.setStoreDetails(storeDetails);
//		user.setEmployeesUnderStoreManager(employeesUnderStoreManager);
//
//		assertEquals((long) 1, user.getId());
//		assertEquals("Test Manager123", user.getName());
//		assertEquals("test.example@gmail.com", user.getEmail());
//		assertEquals("12345678", user.getPassword());
//		assertEquals(false, user.isApproved());
//		assertEquals((long) 1, user.getId());
//		assertEquals((long) 123, user.getEmpId());
//		assertEquals((long) 770011, user.getManagerId());
//		assertEquals("STORE_MANAGER", user.getRole());
//		assertEquals((long) 100, user.getCarbonSaving());
//		assertEquals((long) 20, user.getDollarSaving());
//		assertEquals((long) 150, user.getWasteSaving());
//
//		assertEquals(1, user.getStoreDetails().getId());
//		assertEquals("Test Store", user.getStoreDetails().getStoreName());
//		assertEquals("Test Street", user.getStoreDetails().getStreet());
//		assertEquals("Test City", user.getStoreDetails().getCity());
//		assertEquals("Test Country", user.getStoreDetails().getCountry());
//		assertEquals("Test State", user.getStoreDetails().getState());
//		assertEquals("123456", user.getStoreDetails().getZipCode());
//
//		user.getChallengeEmployeeDetail().stream().forEach(i -> {
//			assertEquals(1, i.getId());
//			assertEquals(4, i.getChallengeId());
//			assertEquals("Enrolled", i.getChallengeStatus());
//			assertEquals(2, i.getEmployeeAutoId());
//		});
//
//        user.getEmployeesUnderStoreManager().stream().forEach(i-> {
//        	assertEquals(9, i.getId());
//       	 	assertEquals("Test Emp1", i.getName());
//       	 	assertEquals("emp1.example@gmail.com", i.getEmail());
//       	 	assertEquals("pass123", i.getPassword());
//       	 	assertEquals(false, i.isApproved());
//       	 	assertEquals("789101", i.getOtp());
//        });
//        logger.log(Level.INFO, user.toString());
//    }
//    
//
//   
//
//    @Test
//    void testApproveUser_userExists() {
//        when(userRepository.findById(anyLong())).thenReturn(Optional.of(user));
//        when(userRepository.save(any(User.class))).thenReturn(user);
//
//        Optional<User> approvedUser = userService.approveUser(user.getId());
//        assertTrue(approvedUser.isPresent());
//        assertEquals(user.getName(), approvedUser.get().getName());
//        verify(userRepository, times(1)).findById(anyLong());
//        verify(userRepository, times(1)).save(any(User.class));
//    }
//
//    @Test
//    void testApproveUser_userNotFound() {
//        when(userRepository.findById(anyLong())).thenReturn(Optional.empty());
//
//        Optional<User> approvedUser = userService.approveUser(user.getId());
//        assertFalse(approvedUser.isPresent());
//        verify(userRepository, times(1)).findById(anyLong());
//    }
//
//    @Test
//    void testDeclineUser_userExists() {
//        when(userRepository.findById(anyLong())).thenReturn(Optional.of(user));
//        when(userRepository.save(any(User.class))).thenReturn(user);
//
//        Optional<User> declinedUser = userService.declineUser(user.getId());
//        assertTrue(declinedUser.isPresent());
//        assertEquals(user.getName(), declinedUser.get().getName());
//        verify(userRepository, times(1)).findById(anyLong());
//        verify(userRepository, times(1)).save(any(User.class));
//    }
//
//    @Test
//    void testDeclineUser_userNotFound() {
//        when(userRepository.findById(anyLong())).thenReturn(Optional.empty());
//        Optional<User> declinedUser = userService.declineUser(user.getId());
//        assertFalse(declinedUser.isPresent());
//        verify(userRepository, times(1)).findById(anyLong());
//    }
//
//    @Test
//    void testGetUserById() {
//    	Optional<User> result = userService.getUser((long)3);
//    	verify(userRepository).findById((long)3);
//    }
//}
