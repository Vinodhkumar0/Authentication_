package com.genai.sustainabilitygamification;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.web.servlet.MockMvc;

import com.genai.sustainabilitygamification.controller.ExportToExcelController;
import com.genai.sustainabilitygamification.dto.EmployeeDto;
import com.genai.sustainabilitygamification.dto.ManagersDto;
import com.genai.sustainabilitygamification.service.ExportToExcelService;

import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;

public class ExportToExcelTest {
	
	@Mock
	HttpServletResponse httpServletResponse;
	
	ExportToExcelService excelService;
	ExportToExcelController controller;
	
	@BeforeEach
	public void setup() {
		MockitoAnnotations.openMocks(this);
		excelService=new ExportToExcelService();
		controller=new ExportToExcelController(excelService);
		
	}
	
	@Test
	public void ExportToExcelServiceTest() throws IOException {
		List<EmployeeDto> e=new ArrayList<>();
		e.add(new EmployeeDto("Abc",1,2,4,2,"23w"));
		List<ManagersDto> m=new ArrayList<>();
		m.add(new ManagersDto("Abc","123","a@gmail.com","store","state","12-12-2024",e));
		
		ServletOutputStream stream=mock(ServletOutputStream.class);
		when(httpServletResponse.getOutputStream()).thenReturn(stream);
		excelService.getstoreAllstoreDetails(m, httpServletResponse);
		
	}
	
	@Test
	public void EXportToExcelControllerTest() throws IOException {
		List<EmployeeDto> e=new ArrayList<>();
		e.add(new EmployeeDto("Abc",1,2,4,2,"23w"));
		List<ManagersDto> m=new ArrayList<>();
		m.add(new ManagersDto("Abc","123","a@gmail.com","store","state","12-12-2024",e));
		ServletOutputStream stream=mock(ServletOutputStream.class);
		when(httpServletResponse.getOutputStream()).thenReturn(stream);
		controller.generateExcel(m, httpServletResponse);
	}

}
