package com.genai.sustainabilitygamification;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import com.genai.sustainabilitygamification.dto.StoreDetailsDto;

@SpringBootTest
public class StoreDetailsDtoTest {
	
	@Test
    void testStoreDetailsDtoParameterizedConstructorAndGetters() {
	 StoreDetailsDto storeDetailsDto1 = new StoreDetailsDto();
	 storeDetailsDto1.setId((long) 1);
	 storeDetailsDto1.setStoreName("Test Store");
	 storeDetailsDto1.setStreet("Test Street");
	 storeDetailsDto1.setCity("Test City");
	 storeDetailsDto1.setCountry("Test Country");
	 storeDetailsDto1.setState("Test State");
	 storeDetailsDto1.setZipCode("123456");
	 
	 assertEquals(1, storeDetailsDto1.getId());
     assertEquals("Test Store", storeDetailsDto1.getStoreName());
     assertEquals("Test Street", storeDetailsDto1.getStreet());
     assertEquals("Test City", storeDetailsDto1.getCity());
     assertEquals("Test Country", storeDetailsDto1.getCountry());
     assertEquals("Test State", storeDetailsDto1.getState());
     assertEquals("123456", storeDetailsDto1.getZipCode());
     
    }

}
