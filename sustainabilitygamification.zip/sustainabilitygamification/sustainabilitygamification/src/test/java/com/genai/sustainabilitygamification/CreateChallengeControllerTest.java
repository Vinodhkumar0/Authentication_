package com.genai.sustainabilitygamification;

import com.genai.sustainabilitygamification.controller.CreateChallengesController;
import com.genai.sustainabilitygamification.entity.CreateChallenges;
import com.genai.sustainabilitygamification.service.CreateChallengesService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@SpringBootTest
class CreateChallengeControllerTest {

    @Mock
    private CreateChallengesService challengesService;

    @InjectMocks
    private CreateChallengesController controller;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateChallenge() {

        CreateChallenges challenge = new CreateChallenges();
        when(challengesService.createChallenge(challenge)).thenReturn(challenge);

        ResponseEntity<String> response = controller.createChallenge(challenge);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Challenge is Published", response.getBody());
        verify(challengesService).createChallenge(challenge);
    }

    @Test
    void testSaveDraft() {

        CreateChallenges challenge = new CreateChallenges();
        when(challengesService.saveDraft(challenge)).thenReturn(challenge);

        ResponseEntity<String> response = controller.saveDraft(challenge);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Challenge is saved as draft", response.getBody());
        verify(challengesService).saveDraft(challenge);
    }

}

