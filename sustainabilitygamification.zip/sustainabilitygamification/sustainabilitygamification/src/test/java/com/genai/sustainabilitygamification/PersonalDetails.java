//package com.genai.sustainabilitygamification;
//
//import static org.mockito.Mockito.mock;
//import static org.mockito.Mockito.when;
//
//import java.time.LocalDate;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//
//import com.genai.sustainabilitygamification.controller.PersonalDetailsController;
//import com.genai.sustainabilitygamification.entity.StoreDetails;
//import com.genai.sustainabilitygamification.entity.StoreManager;
//import com.genai.sustainabilitygamification.repository.StoreManagerRepository;
//import com.genai.sustainabilitygamification.service.PersonalDetailsService;
//
//
//
// class PersonalDetails {
//
//	private PersonalDetailsController personalDetailsController;
//	private PersonalDetailsService detailsService;
//	private PersonalDetailsService personalDetailsService;
//	private StoreManagerRepository managerRepository;
//
//	@BeforeEach
//	public void setup() {
//		detailsService = mock(PersonalDetailsService.class);
//		personalDetailsController = new PersonalDetailsController(detailsService);
//		managerRepository = mock(StoreManagerRepository.class);
//		personalDetailsService = new PersonalDetailsService(managerRepository);
//	}
//
//	@Test
//	void testGetDetailsByEmployeeId() {
//		StoreManager manager = new StoreManager();
//		manager.setName("John Doe");
//		manager.setEmployeeId("12345");
//		manager.setEmail("john@example.com");
//		manager.setDateOfBirth(LocalDate.of(1990, 1, 1));
//		manager.setGender("Male");
//
//		StoreDetails storeDetails = new StoreDetails();
//		storeDetails.setId(1L);
//		storeDetails.setStoreName("Store 1");
//		storeDetails.setStreet("123 Main St");
//		storeDetails.setCity("City");
//		storeDetails.setCountry("Country");
//		storeDetails.setState("State");
//		storeDetails.setZipCode("12345");
//
//		//manager.setStoreDetails(storeDetails);
//
//		when(managerRepository.findByEmployeeId("12345")).thenReturn(manager);
//
//		//StoreManagerDto result = personalDetailsService.getDetailsByEmployeeId("12345");
//
//		/*
//		 * assertEquals("John Doe", result.getName()); assertEquals("12345",
//		 * result.getEmployeeId()); assertEquals("john@example.com", result.getEmail());
//		 * assertEquals(LocalDate.of(1990, 1, 1), result.getDateOfBirth());
//		 * assertEquals("Male", result.getGender()); StoreDetailsDto storeDetailsDto =
//		 * result.getStoreDetails();
//		 */
//		/*
//		 * assertEquals(1L, storeDetailsDto.getId()); assertEquals("Store 1",
//		 * storeDetailsDto.getStoreName()); assertEquals("123 Main St",
//		 * storeDetailsDto.getStreet()); assertEquals("City",
//		 * storeDetailsDto.getCity()); assertEquals("Country",
//		 * storeDetailsDto.getCountry()); assertEquals("State",
//		 * storeDetailsDto.getState()); assertEquals("12345",
//		 * storeDetailsDto.getZipCode());
//		 */
//	}
//
//	@Test
//	void testGetPersonalDetailsByEmployeeId() {
//		/*
//		 * StoreManagerDto managerDto = new StoreManagerDto("John Doe", "12345",
//		 * "john@example.com", LocalDate.of(1990, 1, 1), "Male", new StoreDetailsDto(1L,
//		 * "Store 1", "123 Main St", "City", "Country", "State", "12345"));
//		 */
//
//		//when(detailsService.getDetailsByEmployeeId("12345")).thenReturn(managerDto);
//
//		/*
//		 * ResponseEntity<StoreManagerDto> responseEntity = personalDetailsController
//		 * .getPersonalDetailsByEmployeeId("12345");
//		 */
//		//assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
//		//assertEquals(managerDto, responseEntity.getBody());
//	}
//
//}
