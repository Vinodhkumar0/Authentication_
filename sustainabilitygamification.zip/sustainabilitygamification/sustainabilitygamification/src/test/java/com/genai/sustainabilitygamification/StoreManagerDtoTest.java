package com.genai.sustainabilitygamification;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.genai.sustainabilitygamification.dto.StoreDetailsDto;
import com.genai.sustainabilitygamification.dto.StoreManagerDto;

@SpringBootTest
public class StoreManagerDtoTest {
	
	@Test
    void testStoreManagerDtoParameterizedConstructorAndGetters() {
	 StoreManagerDto storeManagerDto = new StoreManagerDto();
	 storeManagerDto.setName("XYZ Store Manager");
	 storeManagerDto.setEmployeeId("770022");
	 storeManagerDto.setEmail("xyz@storemanager.com");
	 storeManagerDto.setDateOfBirth(LocalDate.of(1990, 1, 13));
	 storeManagerDto.setGender("Male");
	 
	 StoreDetailsDto storeDetailsDto = new StoreDetailsDto();
	 storeDetailsDto.setId((long) 1);
	 storeDetailsDto.setStoreName("Test Store");
	 storeDetailsDto.setStreet("Test Street");
	 storeDetailsDto.setCity("Test City");
	 storeDetailsDto.setCountry("Test Country");
	 storeDetailsDto.setState("Test State");
	 storeDetailsDto.setZipCode("123456");
	 
	 storeManagerDto.setStoreDetails(storeDetailsDto);
	 
	 assertEquals(1, storeDetailsDto.getId());
	 assertEquals("XYZ Store Manager", storeManagerDto.getName());
	 assertEquals("770022", storeManagerDto.getEmployeeId());
	 assertEquals("xyz@storemanager.com", storeManagerDto.getEmail());
	 assertEquals(LocalDate.of(1990, 1, 13), storeManagerDto.getDateOfBirth());
	 assertEquals("Male", storeManagerDto.getGender());
	 
     assertEquals("Test Store", storeManagerDto.getStoreDetails().getStoreName());
     assertEquals("Test Street", storeManagerDto.getStoreDetails().getStreet());
     assertEquals("Test City", storeManagerDto.getStoreDetails().getCity());
     assertEquals("Test Country", storeManagerDto.getStoreDetails().getCountry());
     assertEquals("Test State", storeManagerDto.getStoreDetails().getState());
     assertEquals("123456", storeManagerDto.getStoreDetails().getZipCode());
     
     StoreDetailsDto storeDetailsDto1 = new StoreDetailsDto();
	 storeDetailsDto1.setId((long) 2);
	 storeDetailsDto1.setStoreName("Test Store1");
	 storeDetailsDto1.setStreet("Test Street1");
	 storeDetailsDto1.setCity("Test City1");
	 storeDetailsDto1.setCountry("Test Country1");
	 storeDetailsDto1.setState("Test State1");
	 storeDetailsDto1.setZipCode("456789");
     StoreManagerDto storeManagerDto1 = new StoreManagerDto("PQR Store manager", "770011", "pqr@storemanager.com", LocalDate.of(1989, 11, 12), "Female", 
    		 storeDetailsDto1);
     
     assertEquals(2, storeDetailsDto1.getId());
	 assertEquals("PQR Store manager", storeManagerDto1.getName());
	 assertEquals("770011", storeManagerDto1.getEmployeeId());
	 assertEquals("pqr@storemanager.com", storeManagerDto1.getEmail());
	 assertEquals(LocalDate.of(1989, 11, 12), storeManagerDto1.getDateOfBirth());
	 assertEquals("Female", storeManagerDto1.getGender());
	 
     assertEquals("Test Store1", storeManagerDto1.getStoreDetails().getStoreName());
     assertEquals("Test Street1", storeManagerDto1.getStoreDetails().getStreet());
     assertEquals("Test City1", storeManagerDto1.getStoreDetails().getCity());
     assertEquals("Test Country1", storeManagerDto1.getStoreDetails().getCountry());
     assertEquals("Test State1", storeManagerDto1.getStoreDetails().getState());
     assertEquals("456789", storeManagerDto1.getStoreDetails().getZipCode());
     
    }

}
