package com.genai.sustainabilitygamification;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.genai.sustainabilitygamification.controller.MyChallengesController;
import com.genai.sustainabilitygamification.dto.MyChallengesDto;
import com.genai.sustainabilitygamification.entity.MyProgress;
import com.genai.sustainabilitygamification.entity.Participate;
import com.genai.sustainabilitygamification.repository.ParticipateRepository;
import com.genai.sustainabilitygamification.service.MyChallengesService;



public class MyChallenges {

	@Mock
	private ParticipateRepository participateRepository;

	@InjectMocks
	private MyChallengesService myChallengesService;

	@BeforeEach
	public void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	 void testGetMychallegesByEmployeeId_NoParticipates() {
		when(participateRepository.findByEmployeeId("employee123")).thenReturn(new ArrayList<>());

		MyChallengesDto result = myChallengesService.getMychallegesByEmployeeId("employee123");

		assertEquals(0, result.getOwnedChallenges());
		assertEquals(0, result.getOngoingChallenges());
		assertEquals(0, result.getCompletedChallenges());
	}

	@Test
	void testGetMychallegesByEmployeeId_MixedParticipates() {
		List<Participate> participates = new ArrayList<>();
		List<MyProgress> list = new ArrayList<>();
		MyProgress myProgress = new MyProgress();
		myProgress.setProgressPercentage(100);
		myProgress.setDate(LocalDate.now().minusDays(9));
		list.add(myProgress);

		participates.add(new Participate(1L, "Challenge 1", LocalDate.now().minusDays(10), LocalDate.now().minusDays(5),
				"Featured", "Completed", "User123", "Employee123", list));
		participates.add(new Participate(2L, "Challenge 2", LocalDate.now().minusDays(1), LocalDate.now().plusDays(1),
				"Featured", "Enrolled", "User123", "Employee123", null));
		participates.add(new Participate(3L, "Challenge 3", LocalDate.now().minusDays(1), LocalDate.now().plusDays(1),
				"Featured", "Enrolled", "employee123", "Employee123", null));

		when(participateRepository.findByEmployeeId("employee123")).thenReturn(participates);
		when(participateRepository.findAll()).thenReturn(participates);

		MyChallengesDto result = myChallengesService.getMychallegesByEmployeeId("employee123");

		assertEquals(1, result.getOwnedChallenges());
		assertEquals(2, result.getOngoingChallenges());
		assertEquals(0, result.getCompletedChallenges());
	}

	@Test
	 void testGetMychallegesByEmployeeId_CompletedAndOngoingChallenges_ReturnsCorrectCounts() {
		String employeeId = "123";
		Participate completedParticipate = new Participate();
		completedParticipate.setEmployeeId(employeeId);
		completedParticipate.setChallengeStatus("enrolled");
		completedParticipate.setCreatedBy("124");
		completedParticipate.setStartDate(LocalDate.now().minusDays(10));
		completedParticipate.setEndDate(LocalDate.now().minusDays(5));
		List<MyProgress> completedProgressList = new ArrayList<>();
		MyProgress completedProgress = new MyProgress();
		completedProgress.setProgressPercentage(100);
		completedProgressList.add(completedProgress);
		completedParticipate.setMyProgress(completedProgressList);

		Participate ongoingParticipate = new Participate();
		ongoingParticipate.setEmployeeId(employeeId);
		ongoingParticipate.setChallengeStatus("enrolled");
		ongoingParticipate.setCreatedBy("124");
		ongoingParticipate.setStartDate(LocalDate.now().minusDays(1));
		ongoingParticipate.setEndDate(LocalDate.now().plusDays(1));

		when(participateRepository.findByEmployeeId(employeeId))
				.thenReturn(Arrays.asList(completedParticipate, ongoingParticipate));

		MyChallengesDto result = myChallengesService.getMychallegesByEmployeeId(employeeId);

		assertEquals(1, result.getCompletedChallenges());
		assertEquals(1, result.getOngoingChallenges());
		assertEquals(0, result.getOwnedChallenges());
	}

	@Test
	void testFindChallengeDetailsByEmployeeID() {
		MyChallengesService serviceMock = mock(MyChallengesService.class);

		when(serviceMock.getMychallegesByEmployeeId("employee123")).thenReturn(new MyChallengesDto(1, 2, 3));

		MyChallengesController controller = new MyChallengesController();
		controller.challengesService = serviceMock;

		ResponseEntity<MyChallengesDto> responseEntity = controller.findChallengeDetailsByEmployeeID("employee123");

		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		assertEquals(1, responseEntity.getBody().getCompletedChallenges());
		assertEquals(2, responseEntity.getBody().getOngoingChallenges());
		assertEquals(3, responseEntity.getBody().getOwnedChallenges());
	}

}
