package com.genai.sustainabilitygamification;

import com.genai.sustainabilitygamification.controller.CreateChallengesController;
import com.genai.sustainabilitygamification.entity.Awards;
import com.genai.sustainabilitygamification.entity.CreateChallenges;
import com.genai.sustainabilitygamification.entity.TypeOfSavings;
import com.genai.sustainabilitygamification.repository.AwardsRepository;
import com.genai.sustainabilitygamification.repository.CreateChallengesRepository;
import com.genai.sustainabilitygamification.repository.TypeOfSavingsRepository;
import com.genai.sustainabilitygamification.service.CreateChallengesService;
import com.genai.sustainabilitygamification.service.NotificationService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@SpringBootTest
class CreateChallengesTest {

	@MockBean
	private CreateChallengesRepository challengesRepo;

	@Mock
	private AwardsRepository awardsRepository;

	@Mock
	private TypeOfSavingsRepository typeOfSavingsRepository;

	@InjectMocks
	private CreateChallengesService service;

	@InjectMocks
	private CreateChallengesController controller;
	
	@Mock
	private NotificationService notificationService;

	@BeforeEach
	void setUp() {
		service = new CreateChallengesService();
		service.setChallengesRepo(challengesRepo);
		service.setAwardsRepository(awardsRepository);
		service.setTypeOfSavingsRepository(typeOfSavingsRepository);
		service.setNotificationService(notificationService);
	}

	@Test
	void testCreateChallenge() {

		TypeOfSavings obj1 = new TypeOfSavings((long) 1, "Carbon Saving", "Reference Data[1] challengetest",
				"conversion factor");
		TypeOfSavings obj2 = new TypeOfSavings((long) 2, "Carbon Saving", "Reference Data[1] challengetest",
				"conversion factor");
		TypeOfSavings obj3 = new TypeOfSavings((long) 3, "Carbon Saving", "Reference Data[1] challengetest",
				"conversion factor");
		List<TypeOfSavings> challengeSavingTypeList = new ArrayList<>();
		challengeSavingTypeList.add(obj1);
		challengeSavingTypeList.add(obj2);
		challengeSavingTypeList.add(obj3);

		Awards challengeAward = new Awards((long) 1, "Winner 100 USD", "Trophy 1st Ruuner, 50 USD",
				"Trophy 2nd Ruuner, 25 USD");

		CreateChallenges challenge = new CreateChallenges((long) 1, "My Challenge Test",
				"Amount of packaging purchased per $ sale", "Test eligibility", "STORE_MANAGER",
				"Test Data Required my Challenge Test", challengeSavingTypeList, challengeAward,
				LocalDate.parse("2024-05-06"), LocalDate.parse("2024-07-15"), LocalDate.parse("2024-07-15"),
				"Published", "Featured by me");

		when(challengesRepo.save(any())).thenReturn(challenge);

		CreateChallenges result = service.createChallenge(challenge);

		assertNotNull(result);
		assertEquals("Published", result.getStatus());
		verify(challengesRepo).save(any());

	}

	@Test
	void testSaveDraftWithNullInput() {

		CreateChallenges result = service.saveDraft(null);

		assertNull(result);
		verifyNoInteractions(challengesRepo);
		verifyNoInteractions(awardsRepository);
	}

	@Test
	void testSaveDraftWithValidInputAndEmptyTypeOfSavingsList() {

		TypeOfSavings obj1 = new TypeOfSavings((long) 0, "Carbon Saving", "Reference Data[1] challengetest",
				"conversion factor");
		TypeOfSavings obj2 = new TypeOfSavings((long) 0, "Carbon Saving", "Reference Data[1] challengetest",
				"conversion factor");
		TypeOfSavings obj3 = new TypeOfSavings((long) 0, "Carbon Saving", "Reference Data[1] challengetest",
				"conversion factor");
		List<TypeOfSavings> challengeSavingTypeList = new ArrayList<>();
		challengeSavingTypeList.add(obj1);
		challengeSavingTypeList.add(obj2);
		challengeSavingTypeList.add(obj3);

		Awards challengeAward = new Awards((long) 0, "Winner 100 USD", "Trophy 1st Ruuner, 50 USD",
				"Trophy 2nd Ruuner, 25 USD");

		CreateChallenges challenge = new CreateChallenges((long) 0, "My Challenge Test",
				"Amount of packaging purchased per $ sale", "Test eligibility", "STORE_MANAGER",
				"Test Data Required my Challenge Test", challengeSavingTypeList, challengeAward,
				LocalDate.parse("2024-05-06"), LocalDate.parse("2024-07-15"), LocalDate.parse("2024-07-15"),
				"Save Draft", "Featured by me");

		when(challengesRepo.save(any())).thenReturn(challenge);
		CreateChallenges result = service.saveDraft(challenge);

		verify(challengesRepo, times(1)).save(any());

		verifyNoInteractions(typeOfSavingsRepository);

		assertNotNull(result);
		assertEquals("Save Draft", result.getStatus());
	}

	@Test
	void testCreateChallengeWithNullInput() {
		CreateChallenges result = service.createChallenge(null);
		assertNull(result);
		verifyNoInteractions(challengesRepo);
		verifyNoInteractions(awardsRepository);

	}

	@Test
	void testSaveDraftWithValidInputAndNonNullTypeOfSavings() {

		TypeOfSavings obj1 = new TypeOfSavings((long) 0, "Carbon Saving", "Reference Data[1] challengetest",
				"conversion factor");
		TypeOfSavings obj2 = new TypeOfSavings((long) 0, "Carbon Saving", "Reference Data[1] challengetest",
				"conversion factor");
		TypeOfSavings obj3 = new TypeOfSavings((long) 0, "Carbon Saving", "Reference Data[1] challengetest",
				"conversion factor");
		List<TypeOfSavings> challengeSavingTypeList = new ArrayList<>();
		challengeSavingTypeList.add(obj1);
		challengeSavingTypeList.add(obj2);
		challengeSavingTypeList.add(obj3);

		Awards challengeAward = new Awards((long) 0, "Winner 100 USD", "Trophy 1st Ruuner, 50 USD",
				"Trophy 2nd Ruuner, 25 USD");

		CreateChallenges challenge = new CreateChallenges((long) 0, "My Challenge Test",
				"Amount of packaging purchased per $ sale", "Test eligibility", "STORE_MANAGER",
				"Test Data Required my Challenge Test", challengeSavingTypeList, challengeAward,
				LocalDate.parse("2024-05-06"), LocalDate.parse("2024-07-15"), LocalDate.parse("2024-07-15"),
				"Save Draft", "Featured by me");
		when(challengesRepo.save(any())).thenReturn(challenge);

		CreateChallenges result = service.saveDraft(challenge);

		assertNotNull(result);
		assertEquals("Save Draft", result.getStatus());
		verify(challengesRepo).save(any());
		verifyNoInteractions(typeOfSavingsRepository);
	}

	@Test
	void testCreateChallengeWithValidInputButNullTypeOfSavings() {

		Awards challengeAward = new Awards((long) 0, "Winner 100 USD", "Trophy 1st Ruuner, 50 USD",
				"Trophy 2nd Ruuner, 25 USD");

		CreateChallenges challenge = new CreateChallenges((long) 0, "My Challenge Test",
				"Amount of packaging purchased per $ sale", "Test eligibility", "STORE_MANAGER",
				"Test Data Required my Challenge Test", null, challengeAward, LocalDate.parse("2024-05-06"),
				LocalDate.parse("2024-07-15"), LocalDate.parse("2024-07-15"), "Published", "Featured by me");
		when(challengesRepo.save(any())).thenReturn(challenge);

		CreateChallenges result = service.createChallenge(challenge);

		assertNotNull(result);
		assertEquals("Published", result.getStatus());
		verify(challengesRepo).save(any());
		verifyNoInteractions(awardsRepository);
		verifyNoInteractions(typeOfSavingsRepository);
	}

	@Test
	void testCreateChallengeWithValidInputButNullAwards() {

		TypeOfSavings obj1 = new TypeOfSavings((long) 0, "Carbon Saving", "Reference Data[1] challengetest",
				"conversion factor");
		TypeOfSavings obj2 = new TypeOfSavings((long) 0, "Carbon Saving", "Reference Data[1] challengetest",
				"conversion factor");
		TypeOfSavings obj3 = new TypeOfSavings((long) 0, "Carbon Saving", "Reference Data[1] challengetest",
				"conversion factor");
		List<TypeOfSavings> challengeSavingTypeList = new ArrayList<>();
		challengeSavingTypeList.add(obj1);
		challengeSavingTypeList.add(obj2);
		challengeSavingTypeList.add(obj3);

		Awards challengeAward = new Awards((long) 0, "Winner 100 USD", "Trophy 1st Ruuner, 50 USD",
				"Trophy 2nd Ruuner, 25 USD");

		CreateChallenges challenge = new CreateChallenges((long) 0, "My Challenge Test",
				"Amount of packaging purchased per $ sale", "Test eligibility", "STORE_MANAGER",
				"Test Data Required my Challenge Test", challengeSavingTypeList, null, LocalDate.parse("2024-05-06"),
				LocalDate.parse("2024-07-15"), LocalDate.parse("2024-07-15"), "Published", "Featured by me");
		when(challengesRepo.save(any())).thenReturn(challenge);

		CreateChallenges result = service.createChallenge(challenge);

		assertNotNull(result);
		assertEquals("Published", result.getStatus());
		verify(challengesRepo).save(any());
		verifyNoInteractions(awardsRepository);
	}

	@Test
	void testSaveTypeOfSavingsIfNewWithEmptyList() {
		service.saveTypeOfSavingsIfNew(new ArrayList<>());
		verifyNoInteractions(typeOfSavingsRepository);
	}

	@Test
	void testCreateChallengeWithValidInputAndNonNullAwards() {

		TypeOfSavings obj1 = new TypeOfSavings((long) 0, "Carbon Saving", "Reference Data[1] challengetest",
				"conversion factor");
		TypeOfSavings obj2 = new TypeOfSavings((long) 0, "Carbon Saving", "Reference Data[1] challengetest",
				"conversion factor");
		TypeOfSavings obj3 = new TypeOfSavings((long) 0, "Carbon Saving", "Reference Data[1] challengetest",
				"conversion factor");
		List<TypeOfSavings> challengeSavingTypeList = new ArrayList<>();
		challengeSavingTypeList.add(obj1);
		challengeSavingTypeList.add(obj2);
		challengeSavingTypeList.add(obj3);

		Awards challengeAward = new Awards((long) 0, "Winner 100 USD", "Trophy 1st Ruuner, 50 USD",
				"Trophy 2nd Ruuner, 25 USD");

		CreateChallenges challenge = new CreateChallenges((long) 0, "My Challenge Test",
				"Amount of packaging purchased per $ sale", "Test eligibility", "STORE_MANAGER",
				"Test Data Required my Challenge Test", challengeSavingTypeList, challengeAward,
				LocalDate.parse("2024-05-06"), LocalDate.parse("2024-07-15"), LocalDate.parse("2024-07-15"),
				"Published", "Featured by me");
		when(challengesRepo.save(any())).thenReturn(challenge);

		CreateChallenges result = service.createChallenge(challenge);

		assertNotNull(result);
		assertEquals("Published", result.getStatus());
		verify(challengesRepo).save(any());

	}

	@Test
	void testSaveDraftWithValidInputButNullTypeOfSavings() {

		Awards challengeAward = new Awards((long) 0, "Winner 100 USD", "Trophy 1st Ruuner, 50 USD",
				"Trophy 2nd Ruuner, 25 USD");

		CreateChallenges challenge = new CreateChallenges((long) 0, "My Challenge Test",
				"Amount of packaging purchased per $ sale", "Test eligibility", "STORE_MANAGER",
				"Test Data Required my Challenge Test", null, challengeAward, LocalDate.parse("2024-05-06"),
				LocalDate.parse("2024-07-15"), LocalDate.parse("2024-07-15"), "Save Draft", "Featured by me");
		when(challengesRepo.save(any())).thenReturn(challenge);
		CreateChallenges result = service.saveDraft(challenge);
		assertNotNull(result);
		assertEquals("Save Draft", result.getStatus());
		verify(challengesRepo).save(any());
		verifyNoInteractions(typeOfSavingsRepository);
	}

	@Test
	void testSaveDraftWithValidInputAndNonNullAwardsButNullAwardsId() {

		TypeOfSavings obj1 = new TypeOfSavings((long) 0, "Carbon Saving", "Reference Data[1] challengetest",
				"conversion factor");
		TypeOfSavings obj2 = new TypeOfSavings((long) 0, "Carbon Saving", "Reference Data[1] challengetest",
				"conversion factor");
		TypeOfSavings obj3 = new TypeOfSavings((long) 0, "Carbon Saving", "Reference Data[1] challengetest",
				"conversion factor");
		List<TypeOfSavings> challengeSavingTypeList = new ArrayList<>();
		challengeSavingTypeList.add(obj1);
		challengeSavingTypeList.add(obj2);
		challengeSavingTypeList.add(obj3);

		Awards challengeAward = new Awards(null, "Winner 100 USD", "Trophy 1st Ruuner, 50 USD",
				"Trophy 2nd Ruuner, 25 USD");

		CreateChallenges challenge = new CreateChallenges((long) 0, "My Challenge Test",
				"Amount of packaging purchased per $ sale", "Test eligibility", "STORE_MANAGER",
				"Test Data Required my Challenge Test", challengeSavingTypeList, challengeAward,
				LocalDate.parse("2024-05-06"), LocalDate.parse("2024-07-15"), LocalDate.parse("2024-07-15"),
				"Save Draft", "Featured by me");
		when(challengesRepo.save(any())).thenReturn(challenge);
		when(awardsRepository.save(any())).thenReturn(challengeAward);

		CreateChallenges result = service.saveDraft(challenge);
		assertNotNull(result);
		assertEquals("Save Draft", result.getStatus());
		verify(challengesRepo).save(any());
		verify(awardsRepository).save(any());
	}

	@Test
	void testSaveDraftWithValidInputButNullAwards() {

		TypeOfSavings obj1 = new TypeOfSavings((long) 0, "Carbon Saving", "Reference Data[1] challengetest",
				"conversion factor");
		TypeOfSavings obj2 = new TypeOfSavings((long) 0, "Carbon Saving", "Reference Data[1] challengetest",
				"conversion factor");
		TypeOfSavings obj3 = new TypeOfSavings((long) 0, "Carbon Saving", "Reference Data[1] challengetest",
				"conversion factor");
		List<TypeOfSavings> challengeSavingTypeList = new ArrayList<>();
		challengeSavingTypeList.add(obj1);
		challengeSavingTypeList.add(obj2);
		challengeSavingTypeList.add(obj3);

		CreateChallenges challenge = new CreateChallenges((long) 0, "My Challenge Test",
				"Amount of packaging purchased per $ sale", "Test eligibility", "STORE_MANAGER",
				"Test Data Required my Challenge Test", challengeSavingTypeList, null, LocalDate.parse("2024-05-06"),
				LocalDate.parse("2024-07-15"), LocalDate.parse("2024-07-15"), "Save Draft", "Featured by me");
		when(challengesRepo.save(any())).thenReturn(challenge);

		CreateChallenges result = service.saveDraft(challenge);

		assertNotNull(result);
		assertEquals("Save Draft", result.getStatus());
		verify(challengesRepo).save(any());
		verifyNoInteractions(awardsRepository);
	}

	@Test
	void testSaveDraftWithValidInputAndNonNullAwards() {

		TypeOfSavings obj1 = new TypeOfSavings((long) 0, "Carbon Saving", "Reference Data[1] challengetest",
				"conversion factor");
		TypeOfSavings obj2 = new TypeOfSavings((long) 0, "Carbon Saving", "Reference Data[1] challengetest",
				"conversion factor");
		TypeOfSavings obj3 = new TypeOfSavings((long) 0, "Carbon Saving", "Reference Data[1] challengetest",
				"conversion factor");
		List<TypeOfSavings> challengeSavingTypeList = new ArrayList<>();
		challengeSavingTypeList.add(obj1);
		challengeSavingTypeList.add(obj2);
		challengeSavingTypeList.add(obj3);

		Awards challengeAward = new Awards((long) 0, "Winner 100 USD", "Trophy 1st Ruuner, 50 USD",
				"Trophy 2nd Ruuner, 25 USD");

		CreateChallenges challenge = new CreateChallenges((long) 0, "My Challenge Test",
				"Amount of packaging purchased per $ sale", "Test eligibility", "STORE_MANAGER",
				"Test Data Required my Challenge Test", challengeSavingTypeList, challengeAward,
				LocalDate.parse("2024-05-06"), LocalDate.parse("2024-07-15"), LocalDate.parse("2024-07-15"),
				"Save Draft", "Featured by me");
		when(challengesRepo.save(any())).thenReturn(challenge);

		CreateChallenges result = service.saveDraft(challenge);

		assertNotNull(result);
		assertEquals("Save Draft", result.getStatus());
		verify(challengesRepo).save(any());

	}

	@Test
	void testCreateChallengesConstructorAndGetters() {

		Long id = 1L;
		String challengeName = "Challenge";
		String evaluationKpi = "KPI";
		String eligibility = "Eligibility";
		String createdBy = "User";
		String dataRequired = "Data";
		List<TypeOfSavings> typeOfSavings = new ArrayList<>();
		TypeOfSavings savings = new TypeOfSavings();
		typeOfSavings.add(savings);
		Awards awards = new Awards();
		LocalDate startDate = LocalDate.now();
		LocalDate endDate = LocalDate.now().plusDays(7);
		LocalDate winnerAnnouncementDate = LocalDate.now().plusDays(14);
		String status = "Published";

		CreateChallenges challenge = new CreateChallenges(id, challengeName, evaluationKpi, eligibility, createdBy,
				dataRequired, typeOfSavings, awards, winnerAnnouncementDate, winnerAnnouncementDate,
				winnerAnnouncementDate, status, status);
		CreateChallenges challenges = new CreateChallenges(id, status, status, status, status, status, typeOfSavings,
				awards, startDate, endDate, winnerAnnouncementDate, status, status);

		assertEquals(id, challenge.getId());
		assertEquals(challengeName, challenge.getChallengeName());
		assertEquals(evaluationKpi, challenge.getEvaluationKpi());
		assertEquals(eligibility, challenge.getEligibility());
		assertEquals(createdBy, challenge.getCreatedBy());
		assertEquals(dataRequired, challenge.getDataRequired());
		assertEquals(typeOfSavings, challenges.getTypeOfSavings());
		assertEquals(awards, challenges.getAwards());
		assertEquals(startDate, challenges.getStartDate());
		assertEquals(endDate, challenges.getEndDate());
		assertEquals(winnerAnnouncementDate, challenges.getWinnerAnnouncementDate());
		assertEquals(status, challenges.getStatus());
	}

	@Test
	void testAwardsConstructorAndGetters() {

		Long id = 1L;
		String winner = "Sush";
		String firstRunnerUp = "rish";
		String secondRunnerUp = "bhags";
		Awards awards = new Awards(id, winner, firstRunnerUp, secondRunnerUp);
		assertEquals(id, awards.getId());
		assertEquals(winner, awards.getWinner());
		assertEquals(firstRunnerUp, awards.getFirstRunnerUp());
		assertEquals(secondRunnerUp, awards.getSecondRunnerUp());
	}

	@Test
	void testCreateChallengesDefaultConstructor() {

		CreateChallenges challenge = new CreateChallenges();

		assertNull(challenge.getId());
		assertNull(challenge.getChallengeName());
		assertNull(challenge.getEvaluationKpi());
		assertNull(challenge.getEligibility());
		assertNull(challenge.getCreatedBy());
		assertNull(challenge.getDataRequired());
		assertNull(challenge.getTypeOfSavings());
		assertNull(challenge.getAwards());
		assertNull(challenge.getStartDate());
		assertNull(challenge.getEndDate());
		assertNull(challenge.getWinnerAnnouncementDate());
		assertNull(challenge.getStatus());
	}

	@Test
	void testSetters() {

		Awards awards = new Awards();
		Long id = 1L;
		String winner = "Sush mitha";
		String firstRunnerUp = "mitha";
		String secondRunnerUp = "kontham sush";

		awards.setId(id);
		awards.setWinner(winner);
		awards.setFirstRunnerUp(firstRunnerUp);
		awards.setSecondRunnerUp(secondRunnerUp);

		assertEquals(id, awards.getId());
		assertEquals(winner, awards.getWinner());
		assertEquals(firstRunnerUp, awards.getFirstRunnerUp());
		assertEquals(secondRunnerUp, awards.getSecondRunnerUp());
	}

	@Test
	void testAwardsDefaultConstructor() {

		Awards awards = new Awards();

		assertNull(awards.getId());
		assertNull(awards.getWinner());
		assertNull(awards.getFirstRunnerUp());
		assertNull(awards.getSecondRunnerUp());
	}

	@Test
	void testTypeOfSavingsDefaultConstructor() {

		TypeOfSavings typeOfSavings = new TypeOfSavings();

		assertNull(typeOfSavings.getId());
		assertNull(typeOfSavings.getName());
		assertNull(typeOfSavings.getReferenceData());
		assertNull(typeOfSavings.getConversionFactor());
	}

	@Test
	void testSettersTypeOfSavings() {

		TypeOfSavings typeOfSavings = new TypeOfSavings();
		Long id = 1L;
		String name = "carbon saving";
		String referenceData = "Reference";
		String conversionFactor = "Factor";

		typeOfSavings.setId(id);
		typeOfSavings.setName(name);
		typeOfSavings.setReferenceData(referenceData);
		typeOfSavings.setConversionFactor(conversionFactor);

		assertEquals(id, typeOfSavings.getId());
		assertEquals(name, typeOfSavings.getName());
		assertEquals(referenceData, typeOfSavings.getReferenceData());
		assertEquals(conversionFactor, typeOfSavings.getConversionFactor());
	}

	@Test
	void testNullValues() {

		TypeOfSavings typeOfSavings = new TypeOfSavings(null, null, null, null);
		assertNull(typeOfSavings.getId());
		assertNull(typeOfSavings.getName());
		assertNull(typeOfSavings.getReferenceData());
		assertNull(typeOfSavings.getConversionFactor());
	}

	@Test
	void testSettersCreateChallenge() {

		CreateChallenges createChallenges = new CreateChallenges();
		Long id = 1L;
		String challengeName = "Package Challenge";
		String evaluationKpi = "KPI1";
		String eligibility = "Eligibility";
		String createdBy = "Storemanager";
		String dataRequired = "data";
		List<TypeOfSavings> typeOfSavings = new ArrayList<>();
		Awards awards = new Awards();
		LocalDate startDate = LocalDate.now();
		LocalDate endDate = LocalDate.now().plusDays(7);
		LocalDate winnerAnnouncementDate = LocalDate.now().plusDays(14);
		String status = "Published";

		createChallenges.setId(id);
		createChallenges.setChallengeName(challengeName);
		createChallenges.setEvaluationKpi(evaluationKpi);
		createChallenges.setEligibility(eligibility);
		createChallenges.setCreatedBy(createdBy);
		createChallenges.setDataRequired(dataRequired);
		createChallenges.setTypeOfSavings(typeOfSavings);
		createChallenges.setAwards(awards);
		createChallenges.setStartDate(startDate);
		createChallenges.setEndDate(endDate);
		createChallenges.setWinnerAnnouncementDate(winnerAnnouncementDate);
		createChallenges.setStatus(status);

		assertEquals(id, createChallenges.getId());
		assertEquals(challengeName, createChallenges.getChallengeName());
		assertEquals(evaluationKpi, createChallenges.getEvaluationKpi());
		assertEquals(eligibility, createChallenges.getEligibility());
		assertEquals(createdBy, createChallenges.getCreatedBy());
		assertEquals(dataRequired, createChallenges.getDataRequired());
		assertEquals(typeOfSavings, createChallenges.getTypeOfSavings());
		assertEquals(awards, createChallenges.getAwards());
		assertEquals(startDate, createChallenges.getStartDate());
		assertEquals(endDate, createChallenges.getEndDate());
		assertEquals(winnerAnnouncementDate, createChallenges.getWinnerAnnouncementDate());
		assertEquals(status, createChallenges.getStatus());
	}

}