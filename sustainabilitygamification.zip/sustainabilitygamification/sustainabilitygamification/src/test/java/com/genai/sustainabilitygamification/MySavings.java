package com.genai.sustainabilitygamification;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.genai.sustainabilitygamification.controller.MySavingsController;
import com.genai.sustainabilitygamification.dto.MySavingsDto;
import com.genai.sustainabilitygamification.entity.MyProgress;
import com.genai.sustainabilitygamification.entity.Participate;
import com.genai.sustainabilitygamification.repository.ParticipateRepository;
import com.genai.sustainabilitygamification.service.MySavingsService;



@ExtendWith(MockitoExtension.class)
class MySavings {

	@Mock
	private ParticipateRepository participateRepository;

	@InjectMocks
	private MySavingsService savingsService;

	@Test
	void testGetSavingsByEmployeeId() {
		String employeeId = "123";
		Participate participate1 = new Participate();
		participate1.setChallengeStatus("enrolled");
		MyProgress progress1 = new MyProgress(1L, LocalDate.now(), 1000.0, 20.0);
		List<MyProgress> progressList1 = new ArrayList<>();
		progressList1.add(progress1);
		participate1.setMyProgress(progressList1);

		Participate participate2 = new Participate();
		participate2.setChallengeStatus("defaultenrolled");
		MyProgress progress2 = new MyProgress(2L, LocalDate.now().minusDays(1), 1500.0, 30.0);
		List<MyProgress> progressList2 = new ArrayList<>();
		progressList2.add(progress2);
		participate2.setMyProgress(progressList2);

		List<Participate> participateList = new ArrayList<>();
		participateList.add(participate1);
		participateList.add(participate2);

		when(participateRepository.findByEmployeeId(employeeId)).thenReturn(participateList);

		MySavingsDto result = savingsService.getSavingsByEmployeeId(employeeId);

		Assertions.assertEquals(65000L, result.getDollarSavings());
		Assertions.assertEquals(130000L, result.getWasteSavings());
		Assertions.assertEquals(32500L, result.getCo2Savings());
	}

	@Test
	void testFindSavingsByEmployeeId() {
		MySavingsService serviceMock = mock(MySavingsService.class);

		when(serviceMock.getSavingsByEmployeeId("employee123")).thenReturn(new MySavingsDto(10000L, 20000L, 3000L));

		MySavingsController controller = new MySavingsController();
		controller.savingsService = serviceMock;

		ResponseEntity<MySavingsDto> responseEntity = controller.findSavingsByEmployeeId("employee123");

		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		assertEquals(10000L, responseEntity.getBody().getDollarSavings());
		assertEquals(20000L, responseEntity.getBody().getWasteSavings());
		assertEquals(3000L, responseEntity.getBody().getCo2Savings());
	}

}
