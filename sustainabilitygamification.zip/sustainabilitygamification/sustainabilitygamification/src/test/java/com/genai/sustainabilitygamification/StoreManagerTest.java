//package com.genai.sustainabilitygamification;
//
//import com.genai.sustainabilitygamification.controller.StoreManagerController;
//import com.genai.sustainabilitygamification.entity.ErrorResponse;
//import com.genai.sustainabilitygamification.entity.Login;
//import com.genai.sustainabilitygamification.entity.StoreDetails;
//import com.genai.sustainabilitygamification.entity.StoreManager;
//import com.genai.sustainabilitygamification.exception.*;
//import com.genai.sustainabilitygamification.repository.StoreDetailsRepository;
//import com.genai.sustainabilitygamification.repository.StoreManagerRepository;
//import com.genai.sustainabilitygamification.service.StoreManagerService;
//import org.junit.jupiter.api.Assertions;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.params.ParameterizedTest;
//import org.junit.jupiter.params.provider.Arguments;
//import org.junit.jupiter.params.provider.MethodSource;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//
//import java.time.LocalDate;
//import java.util.stream.Stream;
//
//import static org.junit.jupiter.api.Assertions.*;
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.ArgumentMatchers.anyString;
//import static org.mockito.Mockito.mock;
//import static org.mockito.Mockito.when;
//
//@SpringBootTest
//class StoreManagerTest {
//
//    private final GlobalExceptionHandler handler = new GlobalExceptionHandler();
//
//    static Stream<Arguments> passwordProvider() {
//        return Stream.of(
//                Arguments.of("", ""),
//                Arguments.of(null, null),
//                Arguments.of("pass", "pass"),
//                Arguments.of("verylongpassword1234567890", "verylongpassword1234567890")
//        );
//    }
//
//    static Stream<Arguments> loginData() {
//        return Stream.of(
//                Arguments.of(null, null, "Employee ID and password are required"),
//                Arguments.of("", null, "Employee ID and password are required"),
//                Arguments.of("123", null, "Employee ID and password are required"),
//                Arguments.of(null, "", "Employee ID and password are required"),
//                Arguments.of("", "", "Employee ID and password are required"),
//                Arguments.of("  ", "password", "Employee ID and password are required"),
//                Arguments.of("123", "  ", "Employee ID and password are required")
//        );
//    }
//
//    @Test
//    void testRegisterManager_Successful()
//            throws EmailAlreadyExistsException, EmployeeIdAlreadyExistsException, InvalidNameException,
//            InvalidEmailFormatException, InvalidPasswordFormatException, ContainsOnlyDigitsException {
//
//        StoreManagerService managerService = mock(StoreManagerService.class);
//        StoreManagerRepository repository = mock(StoreManagerRepository.class);
//        StoreDetailsRepository storeDetailsRepository = mock(StoreDetailsRepository.class);
//
//        StoreManager storeManager = new StoreManager();
//        storeManager.setName("Vinodh");
//        storeManager.setEmployeeId("123567");
//        storeManager.setEmail("vin@example.com");
//        storeManager.setPassword("Password@123");
//        storeManager.setConfirmPassword("Password@123");
//
//        when(managerService.register(any(StoreManager.class))).thenReturn(storeManager);
//        when(repository.existsByEmployeeId(anyString())).thenReturn(false);
//        when(repository.existsByEmail(anyString())).thenReturn(false);
//
//        StoreManagerController controller = new StoreManagerController();
//        controller.setManagerService(managerService);
//        controller.setRepository(repository);
//        controller.setStoreDetailsRepository(storeDetailsRepository);
//
//        ResponseEntity<String> response = controller.registerManager(storeManager);
//
//        assertEquals("Manager registered successfully", response.getBody());
//    }
//
//    @ParameterizedTest
//    @MethodSource("passwordProvider")
//    void testRegisterManager_InvalidPasswordFormat(String password, String confirmPassword) {
//        StoreManagerService managerService = mock(StoreManagerService.class);
//        StoreManagerRepository repository = mock(StoreManagerRepository.class);
//
//        StoreManager storeManager = new StoreManager();
//        storeManager.setName("Vinodh");
//        storeManager.setEmployeeId("123456");
//        storeManager.setEmail("vin@example.com");
//        storeManager.setPassword(password);
//        storeManager.setConfirmPassword(confirmPassword);
//
//        StoreManagerController controller = new StoreManagerController();
//        controller.setManagerService(managerService);
//        controller.setRepository(repository);
//
//        Assertions.assertThrows(InvalidPasswordFormatException.class, () -> controller.registerManager(storeManager));
//    }
//
//    @Test
//    void testRegisterManager_PasswordTooLong() {
//
//        StoreManagerService managerService = mock(StoreManagerService.class);
//        StoreManagerRepository repository = mock(StoreManagerRepository.class);
//
//        StoreManager storeManager = new StoreManager();
//        storeManager.setName("Vinodh");
//        storeManager.setEmployeeId("123");
//        storeManager.setEmail("vin@example.com");
//        storeManager.setPassword("verylongpassword123456");
//        storeManager.setConfirmPassword("verylongpassword123456");
//
//        when(repository.existsByEmployeeId(anyString())).thenReturn(false);
//        when(repository.existsByEmail(anyString())).thenReturn(false);
//
//        StoreManagerController controller = new StoreManagerController();
//        controller.setManagerService(managerService);
//        controller.setRepository(repository);
//
//        Assertions.assertThrows(InvalidPasswordFormatException.class, () -> controller.registerManager(storeManager));
//    }
//
//    @Test
//    void testStoreDetailsParameterizedConstructorAndGetters() {
//        StoreManager storeManager = new StoreManager();
//        StoreDetails storeDetails = new StoreDetails(1L, storeManager, "StoreXyZ");
//        StoreDetails storeDetails1 = new StoreDetails("kundalhali", "City", "Country",
//                "State", "12345");
//
//        assertEquals(1L, storeDetails.getId());
//       // assertEquals(storeManager, storeDetails.getStoreManager());
//        assertEquals("StoreXyZ", storeDetails.getStoreName());
//        assertEquals("kundalhali", storeDetails1.getStreet());
//        assertEquals("City", storeDetails1.getCity());
//        assertEquals("Country", storeDetails1.getCountry());
//        assertEquals("State", storeDetails1.getState());
//        assertEquals("12345", storeDetails1.getZipCode());
//    }
//
//    @Test
//    void testRegisterManager_EmptyEmail() {
//        StoreManagerService managerService = mock(StoreManagerService.class);
//        StoreManagerRepository repository = mock(StoreManagerRepository.class);
//
//        StoreManager storeManager = new StoreManager();
//        storeManager.setName("Sushmi");
//        storeManager.setEmployeeId("123456");
//        storeManager.setEmail("");
//        storeManager.setPassword("Password@123");
//        storeManager.setConfirmPassword("Password@123");
//
//        when(repository.existsByEmployeeId(anyString())).thenReturn(false);
//        when(repository.existsByEmail(anyString())).thenReturn(false);
//
//        StoreManagerController controller = new StoreManagerController();
//        controller.setManagerService(managerService);
//        controller.setRepository(repository);
//
//        Assertions.assertThrows(InvalidEmailFormatException.class, () -> controller.registerManager(storeManager));
//    }
//
//    @Test
//    void testRegisterManager_ValidEmail()
//            throws EmailAlreadyExistsException, EmployeeIdAlreadyExistsException, InvalidNameException,
//            InvalidEmailFormatException, InvalidPasswordFormatException, ContainsOnlyDigitsException {
//
//        StoreManagerService managerService = mock(StoreManagerService.class);
//        StoreManagerRepository repository = mock(StoreManagerRepository.class);
//        StoreDetailsRepository storeDetailsRepository = mock(StoreDetailsRepository.class);
//
//        StoreManager storeManager = new StoreManager();
//        storeManager.setName("Alisha");
//        storeManager.setEmployeeId("789123");
//        storeManager.setEmail("alisha@example.com");
//        storeManager.setPassword("Password@123");
//        storeManager.setConfirmPassword("Password@123");
//
//        when(repository.existsByEmail(anyString())).thenReturn(false);
//
//        StoreManagerController controller = new StoreManagerController();
//        controller.setManagerService(managerService);
//        controller.setRepository(repository);
//        controller.setStoreDetailsRepository(storeDetailsRepository);
//
//        ResponseEntity<String> response = controller.registerManager(storeManager);
//
//        assertEquals("Manager registered successfully", response.getBody());
//    }
//
//    @Test
//    void testLogin_InactiveAccount() throws EmployeeNotFoundException {
//        StoreManagerRepository repository = mock(StoreManagerRepository.class);
//
//        StoreManager storeManager = new StoreManager();
//        storeManager.setEmployeeId("987654");
//        storeManager.setPassword("Password@123");
//        storeManager.setVerified(false);
//
//        when(repository.findByEmployeeId("987654")).thenReturn(storeManager);
//
//        StoreManagerController controller = new StoreManagerController();
//        controller.setRepository(repository);
//
//        ResponseEntity<String> response = controller.login(new Login("987654", "Password@123"));
//
//        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
//        assertEquals("Company's approval pending", response.getBody());
//    }
//
//    @Test
//    void testRegisterManager_ValidPassword()
//            throws EmailAlreadyExistsException, EmployeeIdAlreadyExistsException, InvalidNameException,
//            InvalidEmailFormatException, InvalidPasswordFormatException, ContainsOnlyDigitsException {
//
//        StoreManagerService managerService = mock(StoreManagerService.class);
//        StoreManagerRepository repository = mock(StoreManagerRepository.class);
//        StoreDetailsRepository storeDetailsRepository = mock(StoreDetailsRepository.class);
//
//        StoreManager storeManager = new StoreManager();
//        storeManager.setName("sush");
//        storeManager.setEmployeeId("456789");
//        storeManager.setEmail("sush@example.com");
//        storeManager.setPassword("Secure123");
//        storeManager.setConfirmPassword("Secure123");
//
//        when(repository.existsByEmployeeId(anyString())).thenReturn(false);
//
//        StoreManagerController controller = new StoreManagerController();
//        controller.setManagerService(managerService);
//        controller.setRepository(repository);
//        controller.setStoreDetailsRepository(storeDetailsRepository);
//
//        ResponseEntity<String> response = controller.registerManager(storeManager);
//
//        assertEquals("Manager registered successfully", response.getBody());
//    }
//
//    @Test
//    void testRegisterManager_PasswordWithSpecialCharacters() {
//        StoreManagerService managerService = mock(StoreManagerService.class);
//        StoreManagerRepository repository = mock(StoreManagerRepository.class);
//        StoreDetailsRepository storeDetailsRepository = mock(StoreDetailsRepository.class);
//        StoreManager storeManager = new StoreManager();
//        storeManager.setName("sush");
//        storeManager.setEmployeeId("123456");
//        storeManager.setEmail("sush23@example.com");
//        storeManager.setPassword("Pass@word123");
//        storeManager.setConfirmPassword("Pass@word123");
//
//        when(repository.existsByEmployeeId(anyString())).thenReturn(false);
//        when(repository.existsByEmail(anyString())).thenReturn(false);
//
//        StoreManagerController controller = new StoreManagerController();
//        controller.setManagerService(managerService);
//        controller.setRepository(repository);
//        controller.setStoreDetailsRepository(storeDetailsRepository);
//
//        Assertions.assertDoesNotThrow(() -> controller.registerManager(storeManager));
//    }
//
//    @Test
//    void testRegisterManager_InvalidConfirmPassword() {
//        StoreManagerService managerService = mock(StoreManagerService.class);
//        StoreManagerRepository repository = mock(StoreManagerRepository.class);
//
//        StoreManager storeManager = new StoreManager();
//        storeManager.setName("sushm");
//        storeManager.setEmployeeId("123456");
//        storeManager.setEmail("sushmi@example.com");
//        storeManager.setPassword("Password@123");
//        storeManager.setConfirmPassword("DifferentPassword");
//
//        when(repository.existsByEmployeeId(anyString())).thenReturn(false);
//        when(repository.existsByEmail(anyString())).thenReturn(false);
//
//        StoreManagerController controller = new StoreManagerController();
//        controller.setManagerService(managerService);
//        controller.setRepository(repository);
//
//        Assertions.assertThrows(InvalidPasswordFormatException.class, () -> controller.registerManager(storeManager));
//    }
//
//    @Test
//    void testLogin_CompanyApprovalPending() throws EmployeeNotFoundException {
//        StoreManagerRepository repository = mock(StoreManagerRepository.class);
//
//        StoreManager storeManager = new StoreManager();
//        storeManager.setEmployeeId("123456");
//        storeManager.setPassword("Password@123");
//        storeManager.setVerified(false);
//
//        when(repository.findByEmployeeId("123456")).thenReturn(storeManager);
//
//        StoreManagerController controller = new StoreManagerController();
//        controller.setRepository(repository);
//
//        ResponseEntity<String> response = controller.login(new Login("123456", "Password@123"));
//
//        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
//        assertEquals("Company's approval pending", response.getBody());
//    }
//
//    @ParameterizedTest
//    @MethodSource("loginData")
//    void testLogin_InvalidInput(String employeeId, String password, String expectedMessage) throws EmployeeNotFoundException {
//        StoreManagerRepository repository = mock(StoreManagerRepository.class);
//
//        StoreManagerController controller = new StoreManagerController();
//        controller.setRepository(repository);
//
//        ResponseEntity<String> response = controller.login(new Login(employeeId, password));
//
//        Assertions.assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
//        Assertions.assertEquals(expectedMessage, response.getBody());
//    }
//
//    @Test
//    void testLogin_IncorrectPassword() throws EmployeeNotFoundException {
//        StoreManagerRepository repository = mock(StoreManagerRepository.class);
//
//        StoreManager storeManager = new StoreManager();
//        storeManager.setEmployeeId("123456");
//        storeManager.setPassword("Password@123");
//
//        when(repository.findByEmployeeId("123456")).thenReturn(storeManager);
//
//        StoreManagerController controller = new StoreManagerController();
//        controller.setRepository(repository);
//
//        ResponseEntity<String> response = controller.login(new Login("123456", "WrongPassword"));
//
//        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
//        assertEquals("Invalid credentials", response.getBody());
//    }
//
//    @Test
//    void testLogin_NullLoginObject() {
//        StoreManagerRepository repository = mock(StoreManagerRepository.class);
//
//        StoreManagerController controller = new StoreManagerController();
//        controller.setRepository(repository);
//
//        Assertions.assertThrows(NullPointerException.class, () -> controller.login(null));
//    }
//
//    @Test
//    void testRegisterManager_NullEmail() {
//
//        StoreManagerService managerService = mock(StoreManagerService.class);
//        StoreManagerRepository repository = mock(StoreManagerRepository.class);
//
//        StoreManager storeManager = new StoreManager();
//        storeManager.setName("Vinodh");
//        storeManager.setEmployeeId("123456");
//        storeManager.setEmail(null);
//        storeManager.setPassword("Password@123");
//        storeManager.setConfirmPassword("Password@123");
//
//        when(repository.existsByEmployeeId("123456")).thenReturn(false);
//
//        StoreManagerController controller = new StoreManagerController();
//        controller.setManagerService(managerService);
//        controller.setRepository(repository);
//
//        Assertions.assertThrows(InvalidEmailFormatException.class, () -> controller.registerManager(storeManager));
//    }
//
//    @Test
//    void testRegisterManager_PasswordMismatch() {
//
//        StoreManagerService managerService = mock(StoreManagerService.class);
//        StoreManagerRepository repository = mock(StoreManagerRepository.class);
//
//        StoreManager storeManager = new StoreManager();
//        storeManager.setPassword("Password@123");
//        storeManager.setConfirmPassword("Password@38");
//
//        StoreManagerController controller = new StoreManagerController();
//        controller.setManagerService(managerService);
//        controller.setRepository(repository);
//
//        assertThrows(InvalidPasswordFormatException.class, () -> {
//            controller.registerManager(storeManager);
//        });
//    }
//
//    @Test
//    void testLogin_Successful() throws EmployeeNotFoundException {
//
//        StoreManagerRepository repository = mock(StoreManagerRepository.class);
//
//        StoreManager storeManager = new StoreManager();
//        storeManager.setEmployeeId("123678");
//        storeManager.setPassword("Password@12");
//        storeManager.setVerified(true);
//
//        when(repository.findByEmployeeId("123678")).thenReturn(storeManager);
//
//        StoreManagerController controller = new StoreManagerController();
//        controller.setRepository(repository);
//
//        ResponseEntity<String> response = controller.login(new Login("123678", "Password@12"));
//
//        assertEquals(HttpStatus.OK, response.getStatusCode());
//        assertEquals("Login successful", response.getBody());
//    }
//
//    @Test
//    void testLogin_InvalidCredentials() throws EmployeeNotFoundException {
//
//        StoreManagerRepository repository = mock(StoreManagerRepository.class);
//
//        StoreManager storeManager = new StoreManager();
//        storeManager.setEmployeeId("123");
//        storeManager.setPassword("password");
//
//        when(repository.findByEmployeeId("123")).thenReturn(storeManager);
//
//        StoreManagerController controller = new StoreManagerController();
//        controller.setRepository(repository);
//
//        ResponseEntity<String> response = controller.login(new Login("123", "invalid"));
//
//        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
//        assertEquals("Invalid credentials", response.getBody());
//    }
//
//    @Test
//    void testLogin_EmployeeNotFound() {
//
//        StoreManagerRepository repository = mock(StoreManagerRepository.class);
//
//        when(repository.findByEmployeeId("123")).thenReturn(null);
//
//        StoreManagerController controller = new StoreManagerController();
//        controller.setRepository(repository);
//
//        assertThrows(EmployeeNotFoundException.class, () -> controller.login(new Login("123", "password")));
//    }
//
//    @Test
//    void testRegisterManager_DuplicateEmployeeId() {
//
//        StoreManagerService managerService = mock(StoreManagerService.class);
//        StoreManagerRepository repository = mock(StoreManagerRepository.class);
//
//        StoreManager storeManager = new StoreManager();
//        storeManager.setName("vinodh");
//        storeManager.setEmployeeId("127893");
//        storeManager.setEmail("vin12@example.com");
//        storeManager.setPassword("Password@123");
//        storeManager.setConfirmPassword("Password@123");
//
//        when(repository.existsByEmployeeId("127893")).thenReturn(true);
//
//        StoreManagerController controller = new StoreManagerController();
//        controller.setManagerService(managerService);
//        controller.setRepository(repository);
//
//        Assertions.assertThrows(EmployeeIdAlreadyExistsException.class, () -> controller.registerManager(storeManager));
//    }
//
//    @Test
//    void testRegisterManager_NullPassword() {
//
//        StoreManagerService managerService = mock(StoreManagerService.class);
//        StoreManagerRepository repository = mock(StoreManagerRepository.class);
//
//        StoreManager storeManager = new StoreManager();
//        storeManager.setName("vinodh");
//        storeManager.setEmployeeId("123");
//        storeManager.setEmail("vin@example.com");
//        storeManager.setPassword(null);
//        storeManager.setConfirmPassword("password");
//
//        when(repository.existsByEmployeeId(anyString())).thenReturn(false);
//        when(repository.existsByEmail(anyString())).thenReturn(false);
//
//        StoreManagerController controller = new StoreManagerController();
//        controller.setManagerService(managerService);
//        controller.setRepository(repository);
//
//        Assertions.assertThrows(InvalidPasswordFormatException.class, () -> controller.registerManager(storeManager));
//    }
//
//    @Test
//    void testRegisterManager_DuplicateEmail() {
//
//        StoreManagerService managerService = mock(StoreManagerService.class);
//        StoreManagerRepository repository = mock(StoreManagerRepository.class);
//
//        StoreManager storeManager = new StoreManager();
//        storeManager.setName("vinodh");
//        storeManager.setEmployeeId("123456");
//        storeManager.setEmail("vin@example.com");
//        storeManager.setPassword("Password@123");
//        storeManager.setConfirmPassword("Password@123");
//
//        when(repository.existsByEmployeeId("123456")).thenReturn(false);
//        when(repository.existsByEmail("vin@example.com")).thenReturn(true);
//
//        StoreManagerController controller = new StoreManagerController();
//        controller.setManagerService(managerService);
//        controller.setRepository(repository);
//
//        assertThrows(EmailAlreadyExistsException.class, () -> controller.registerManager(storeManager));
//    }
//
//    @Test
//    void testRegisterManager_NullEmployeeID() {
//        StoreManagerService managerService = mock(StoreManagerService.class);
//        StoreManagerRepository repository = mock(StoreManagerRepository.class);
//
//        StoreManager storeManager = new StoreManager();
//        storeManager.setName("Vinodh");
//        storeManager.setEmployeeId(null);
//        storeManager.setEmail("vin@example.com");
//        storeManager.setPassword("Password@123");
//        storeManager.setConfirmPassword("Password@123");
//
//        StoreManagerController controller = new StoreManagerController();
//        controller.setManagerService(managerService);
//        controller.setRepository(repository);
//
//        assertThrows(ContainsOnlyDigitsException.class, () -> controller.registerManager(storeManager));
//    }
//
////    @Test
////    void testRegisterManager_MinimumPasswordLength() {
////        StoreManagerService managerService = mock(StoreManagerService.class);
////        StoreManagerRepository repository = mock(StoreManagerRepository.class);
////
////        StoreManager storeManager = new StoreManager();
////        storeManager.setName("Vinodh");
////        storeManager.setEmployeeId("123456");
////        storeManager.setEmail("vin@example.com");
////        storeManager.setPassword("pass");
////        storeManager.setConfirmPassword("pass");
////
////        StoreManagerController controller = new StoreManagerController();
////        controller.setManagerService(managerService);
////        controller.setRepository(repository);
////
////        Assertions.assertThrows(InvalidPasswordFormatException.class, () -> controller.registerManager(storeManager));
////    }
////
////    @Test
////    void testRegisterManager_MaximumPasswordLength() {
////        StoreManagerService managerService = mock(StoreManagerService.class);
////        StoreManagerRepository repository = mock(StoreManagerRepository.class);
////
////        StoreManager storeManager = new StoreManager();
////        storeManager.setName("Vinodh");
////        storeManager.setEmployeeId("123456");
////        storeManager.setEmail("vin@example.com");
////        storeManager.setPassword("verylongpassword1234567890");
////        storeManager.setConfirmPassword("verylongpassword1234567890");
////
////        StoreManagerController controller = new StoreManagerController();
////        controller.setManagerService(managerService);
////        controller.setRepository(repository);
////
////        Assertions.assertThrows(InvalidPasswordFormatException.class, () -> controller.registerManager(storeManager));
////    }
//
//    @Test
//    void testRegisterManager_InvalidEmailFormat() {
//        StoreManagerService managerService = mock(StoreManagerService.class);
//        StoreManagerRepository repository = mock(StoreManagerRepository.class);
//
//        StoreManager storeManager = new StoreManager();
//        storeManager.setName("Vinodh");
//        storeManager.setEmployeeId("123456");
//        storeManager.setEmail("invalidemail.com");
//        storeManager.setPassword("Password@123");
//        storeManager.setConfirmPassword("Password@123");
//
//        StoreManagerController controller = new StoreManagerController();
//        controller.setManagerService(managerService);
//        controller.setRepository(repository);
//
//        assertThrows(InvalidEmailFormatException.class, () -> controller.registerManager(storeManager));
//    }
//
//    @Test
//    void testRegisterManager_PasswordWithoutUppercase() {
//        StoreManagerService managerService = mock(StoreManagerService.class);
//        StoreManagerRepository repository = mock(StoreManagerRepository.class);
//        StoreDetailsRepository storeDetailsRepository = mock(StoreDetailsRepository.class); // Mock the repository
//
//        StoreManager storeManager = new StoreManager();
//        storeManager.setName("Vinodh");
//        storeManager.setEmployeeId("123456");
//        storeManager.setEmail("vin43@example.com");
//        storeManager.setPassword("password@123");
//        storeManager.setConfirmPassword("password@123");
//
//        StoreManagerController controller = new StoreManagerController();
//        controller.setManagerService(managerService);
//        controller.setRepository(repository);
//        controller.setStoreDetailsRepository(storeDetailsRepository);
//
//        Assertions.assertThrows(InvalidPasswordFormatException.class, () -> controller.registerManager(storeManager));
//    }
//
//    @Test
//    void testRegisterManager_NullName() {
//        StoreManagerService managerService = mock(StoreManagerService.class);
//        StoreManagerRepository repository = mock(StoreManagerRepository.class);
//
//        StoreManager storeManager = new StoreManager();
//        storeManager.setName(null);
//        storeManager.setEmployeeId("123456");
//        storeManager.setEmail("vin@example.com");
//        storeManager.setPassword("Password@123");
//        storeManager.setConfirmPassword("Password@123");
//
//        StoreManagerController controller = new StoreManagerController();
//        controller.setManagerService(managerService);
//        controller.setRepository(repository);
//
//        assertThrows(InvalidNameException.class, () -> controller.registerManager(storeManager));
//    }
//
//    @Test
//    void testRegisterManager_EmptyName() {
//
//        StoreManagerService managerService = mock(StoreManagerService.class);
//        StoreManagerRepository repository = mock(StoreManagerRepository.class);
//
//        StoreManager storeManager = new StoreManager();
//        storeManager.setName("");
//        storeManager.setEmployeeId("123456");
//        storeManager.setEmail("vin@example.com");
//        storeManager.setPassword("Password@12");
//        storeManager.setConfirmPassword("Password@12");
//
//        when(repository.existsByEmployeeId("123456")).thenReturn(false);
//        when(repository.existsByEmail("vin@example.com")).thenReturn(false);
//
//        StoreManagerController controller = new StoreManagerController();
//        controller.setManagerService(managerService);
//        controller.setRepository(repository);
//
//        Assertions.assertThrows(InvalidNameException.class, () -> controller.registerManager(storeManager));
//    }
//
//    @Test
//    void testRegisterManager_NameTooShort() {
//
//        StoreManagerService managerService = mock(StoreManagerService.class);
//        StoreManagerRepository repository = mock(StoreManagerRepository.class);
//
//        StoreManager storeManager = new StoreManager();
//        storeManager.setName("V");
//        storeManager.setEmployeeId("123567");
//        storeManager.setEmail("vin67@example.com");
//        storeManager.setPassword("Password@123");
//        storeManager.setConfirmPassword("Password@123");
//
//        when(repository.existsByEmployeeId(anyString())).thenReturn(false);
//        when(repository.existsByEmail(anyString())).thenReturn(false);
//
//        StoreManagerController controller = new StoreManagerController();
//        controller.setManagerService(managerService);
//        controller.setRepository(repository);
//
//        Assertions.assertThrows(InvalidNameException.class, () -> controller.registerManager(storeManager));
//    }
//
//    @Test
//    void testRegisterManager_NameTooLong() {
//
//        StoreManagerService managerService = mock(StoreManagerService.class);
//        StoreManagerRepository repository = mock(StoreManagerRepository.class);
//
//        StoreManager storeManager = new StoreManager();
//        storeManager.setName("VinodhVinodhVinodhVinodhVinodh");
//        storeManager.setEmployeeId("123456");
//        storeManager.setEmail("vin@example.com");
//        storeManager.setPassword("Password@123");
//        storeManager.setConfirmPassword("Password@123");
//
//        when(repository.existsByEmployeeId(anyString())).thenReturn(false);
//        when(repository.existsByEmail(anyString())).thenReturn(false);
//
//        StoreManagerController controller = new StoreManagerController();
//        controller.setManagerService(managerService);
//        controller.setRepository(repository);
//
//        Assertions.assertThrows(InvalidNameException.class, () -> controller.registerManager(storeManager));
//    }
//
//    @Test
//    void testLogin_ValidCredentials() throws EmployeeNotFoundException {
//
//        StoreManagerRepository repository = mock(StoreManagerRepository.class);
//
//        StoreManager storeManager = new StoreManager();
//        storeManager.setEmployeeId("123890");
//        storeManager.setPassword("Password@123");
//        storeManager.setVerified(true);
//
//        when(repository.findByEmployeeId("123890")).thenReturn(storeManager);
//
//        StoreManagerController controller = new StoreManagerController();
//        controller.setRepository(repository);
//
//        ResponseEntity<String> response = controller.login(new Login("123890", "Password@123"));
//
//        assertEquals(HttpStatus.OK, response.getStatusCode());
//        assertEquals("Login successful", response.getBody());
//    }
//
//    @Test
//    void testRegisterManager_ExistingEmail() {
//
//        StoreManagerService managerService = mock(StoreManagerService.class);
//        StoreManagerRepository repository = mock(StoreManagerRepository.class);
//
//        StoreManager storeManager = new StoreManager();
//        storeManager.setName("mithasush");
//        storeManager.setEmployeeId("123789");
//        storeManager.setEmail("mithasush@example.com");
//        storeManager.setPassword("Password123");
//        storeManager.setConfirmPassword("Password123");
//
//        when(repository.existsByEmail("mithasush@example.com")).thenReturn(true);
//
//        StoreManagerController controller = new StoreManagerController();
//        controller.setManagerService(managerService);
//        controller.setRepository(repository);
//
//        Assertions.assertThrows(EmailAlreadyExistsException.class, () -> controller.registerManager(storeManager));
//    }
//
//    @Test
//    void testRegisterManager_ValidEmployeeId()
//            throws EmailAlreadyExistsException, EmployeeIdAlreadyExistsException, InvalidNameException,
//            InvalidEmailFormatException, InvalidPasswordFormatException, ContainsOnlyDigitsException {
//
//        StoreManagerService managerService = mock(StoreManagerService.class);
//        StoreManagerRepository repository = mock(StoreManagerRepository.class);
//        StoreDetailsRepository storeDetailsRepository = mock(StoreDetailsRepository.class);
//
//        StoreManager storeManager = new StoreManager();
//        storeManager.setName("Jayray");
//        storeManager.setEmployeeId("456789");
//        storeManager.setEmail("jayraydoe@example.com");
//        storeManager.setPassword("Password@123");
//        storeManager.setConfirmPassword("Password@123");
//
//        when(repository.existsByEmployeeId(anyString())).thenReturn(false);
//
//        StoreManagerController controller = new StoreManagerController();
//        controller.setManagerService(managerService);
//        controller.setRepository(repository);
//        controller.setStoreDetailsRepository(storeDetailsRepository);
//
//        ResponseEntity<String> response = controller.registerManager(storeManager);
//
//        assertEquals("Manager registered successfully", response.getBody());
//    }
//
//    @Test
//    void testHandleEmployeeIdAlreadyExistsException() {
//        EmployeeIdAlreadyExistsException ex = new EmployeeIdAlreadyExistsException("Employee ID already exists");
//        ResponseEntity<ErrorResponse> response = handler.handleException(ex);
//
//        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
//        assertEquals("Employee ID already exists", response.getBody().getMessage());
//    }
//
//    @Test
//    void testStoreManagerSetterAndGetterId() {
//        StoreManager storeManager = new StoreManager();
//        storeManager.setId(1L);
//
//        assertEquals(1L, storeManager.getId());
//    }
//
//    @Test
//    void testStoreManagerSetterAndGetterName() {
//        StoreManager storeManager = new StoreManager();
//        storeManager.setName("Sushmitha");
//
//        assertEquals("Sushmitha", storeManager.getName());
//    }
//
//    @Test
//    void testStoreManagerEqualsDifferentObject() {
//        StoreManager storeManager = new StoreManager(1L, "Sushmitha", "789012", "sush12@gmail.com",
//                LocalDate.of(1995, 5, 20), "Female");
//        StoreManager storeManager1 = new StoreManager(null, "Password@123", "Password@123", true);
//
//        Object obj = new Object();
//
//        assertNotEquals(storeManager, obj);
//        assertNotEquals(storeManager1, obj);
//    }
//
//    @Test
//    void testStoreManagerSetterAndGetGender() {
//        StoreManager storeManager = new StoreManager();
//        String gender = "Female";
//        storeManager.setGender(gender);
//
//        assertEquals(gender, storeManager.getGender());
//    }
//
//    @Test
//    void testStoreManagerSetterAndGetStoreDetails() {
//        StoreManager storeManager = new StoreManager();
//        StoreDetails storeDetails = new StoreDetails();
//       // storeManager.setStoreDetails(storeDetails);
//
//       // assertEquals(storeDetails, storeManager.getStoreDetails());
//    }
//
//    @Test
//    void testStoreManagerSetterAndGetDateOfBirth() {
//        StoreManager storeManager = new StoreManager();
//        LocalDate dateOfBirth = LocalDate.of(1995, 5, 20);
//        storeManager.setDateOfBirth(dateOfBirth);
//
//        assertEquals(dateOfBirth, storeManager.getDateOfBirth());
//    }
//
//    @Test
//    void testStoreManagerEmptyConstructor() {
//        StoreManager storeManager = new StoreManager();
//
//        assertNull(storeManager.getId());
//        assertNull(storeManager.getName());
//        assertNull(storeManager.getEmployeeId());
//        assertNull(storeManager.getEmail());
//        assertNull(storeManager.getDateOfBirth());
//        assertNull(storeManager.getGender());
//        //assertNull(storeManager.getStoreDetails());
//        assertNull(storeManager.getPassword());
//        assertNull(storeManager.getConfirmPassword());
//
//    }
//
//    @Test
//    void testHandleInvalidEmailFormatException() {
//        InvalidEmailFormatException ex = new InvalidEmailFormatException("Invalid email format");
//        ResponseEntity<ErrorResponse> response = handler.handleException(ex);
//
//        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
//        assertEquals("Invalid email format", response.getBody().getMessage());
//    }
//
//    @Test
//    void testHandleInvalidNameException() {
//        InvalidNameException ex = new InvalidNameException("Invalid name");
//        ResponseEntity<ErrorResponse> response = handler.handleException(ex);
//
//        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
//        assertEquals("Invalid name", response.getBody().getMessage());
//    }
//
//    @Test
//    void testHandleEmployeeNotFoundException() {
//        EmployeeNotFoundException ex = new EmployeeNotFoundException("Employee not found");
//        ResponseEntity<ErrorResponse> response = handler.handleException(ex);
//
//        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
//        assertEquals("Employee not found", response.getBody().getMessage());
//    }
//
//    @Test
//    void testHandleInvalidPasswordFormatException() {
//        InvalidPasswordFormatException ex = new InvalidPasswordFormatException("Invalid password format");
//        ResponseEntity<ErrorResponse> response = handler.handleException(ex);
//
//        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
//        assertEquals("Invalid password format", response.getBody().getMessage());
//    }
//
//    @Test
//    void testHandleContainsOnlyDigitsException() {
//        ContainsOnlyDigitsException ex = new ContainsOnlyDigitsException("Contains only digits");
//        ResponseEntity<ErrorResponse> response = handler.handleException(ex);
//
//        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
//        assertEquals("Contains only digits", response.getBody().getMessage());
//    }
//
//    @Test
//    void testHandleEmailAlreadyExistsException() {
//        EmailAlreadyExistsException ex = new EmailAlreadyExistsException("Email already exists");
//        ResponseEntity<ErrorResponse> response = handler.handleException(ex);
//
//        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
//        assertEquals("Email already exists", response.getBody().getMessage());
//    }
//
//    @Test
//    void testStoreManagerParameterizedConstructor() {
//        StoreManager storeManager = new StoreManager(1L, "Sushmitha", "789012", "sush12@gmail.com",
//                LocalDate.of(1995, 5, 20), "Female");
//
//        StoreManager storeManager1 = new StoreManager(null, "Password@123", "Password@123", true);
//        assertEquals(1L, storeManager.getId());
//        assertEquals("Sushmitha", storeManager.getName());
//        assertEquals("789012", storeManager.getEmployeeId());
//        assertEquals("sush12@gmail.com", storeManager.getEmail());
//        assertEquals(LocalDate.of(1995, 5, 20), storeManager.getDateOfBirth());
//        assertEquals("Female", storeManager.getGender());
//       // assertNull(storeManager1.getStoreDetails());
//        assertEquals("Password@123", storeManager1.getPassword());
//        assertEquals("Password@123", storeManager1.getConfirmPassword());
//        assertEquals(true, storeManager1.isVerified());
//    }
//
//    @Test
//    void testStoreManagerConstructorAndGettersSetters() {
//        StoreManager storeManager = new StoreManager();
//        storeManager.setId(1L);
//        storeManager.setName("Sushmitha");
//        storeManager.setEmployeeId("789012");
//        storeManager.setEmail("sush12@gmail.com");
//        storeManager.setDateOfBirth(LocalDate.of(1995, 5, 20));
//        storeManager.setGender("Female");
//        storeManager.setPassword("Password@123");
//        storeManager.setConfirmPassword("Password@123");
//        storeManager.setVerified(true);
//
//        assertEquals(1L, storeManager.getId());
//        assertEquals("Sushmitha", storeManager.getName());
//        assertEquals("789012", storeManager.getEmployeeId());
//        assertEquals("sush12@gmail.com", storeManager.getEmail());
//        assertEquals(LocalDate.of(1995, 5, 20), storeManager.getDateOfBirth());
//        assertEquals("Female", storeManager.getGender());
//        assertEquals("Password@123", storeManager.getPassword());
//        assertEquals("Password@123", storeManager.getConfirmPassword());
//        assertEquals(true, storeManager.isVerified());
//    }
//
//}
