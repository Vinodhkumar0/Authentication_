package com.genai.sustainabilitygamification;

import static org.mockito.Mockito.*;
import static org.mockito.Mockito.any;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.hamcrest.Matchers.*;
import org.assertj.core.error.ShouldHaveSameSizeAs;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.genai.sustainabilitygamification.controller.NotificationController;
import com.genai.sustainabilitygamification.entity.ChallengeEmployeeDetail;
import com.genai.sustainabilitygamification.entity.CreateChallenges;
import com.genai.sustainabilitygamification.entity.Notification;
import com.genai.sustainabilitygamification.entity.User;
import com.genai.sustainabilitygamification.repository.ChallengeEmployeeDetailRepository;
import com.genai.sustainabilitygamification.repository.CreateChallengesRepository;
import com.genai.sustainabilitygamification.repository.UserRepository;
import com.genai.sustainabilitygamification.service.NotificationService;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class NotificationControllerTest {

	private MockMvc mockMvc;

	@Mock
	private NotificationService notificationService;

	@InjectMocks
	private NotificationController notificationController;

	@Mock
	private ChallengeEmployeeDetailRepository challengeEmployeeDetailRepository;

	@Mock
	private UserRepository userrepository;

	@Mock
	private CreateChallengesRepository challengesRepository;

	List<Notification> list;
	ChallengeEmployeeDetail challengeEmployeeDetail;
	User user;
	CreateChallenges challenges;

	@SuppressWarnings("deprecation")
	@BeforeEach
	public void setup() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(notificationController).build();
		Notification notification1 = new Notification();
		notification1.setId(1L);
		notification1.setEmpName("kontham");
		notification1.setEmpId(98765L);
		notification1.setChallengeName("EChallenge");
		notification1.setNotificationDate("2024-05-03");
		notification1.setNotificationTime("10:30");
		notification1.setStatus("launched");
		notification1.setIsread(false);

		Notification notification2 = new Notification();
		notification2.setId(2L);
		notification2.setEmpName("Alisha");
		notification2.setEmpId(76548L);
		notification2.setChallengeName("package");
		notification2.setNotificationDate("2024-05-04");
		notification2.setNotificationTime("11:00");
		notification2.setStatus("launched");
		notification2.setIsread(false);
		list = Arrays.asList(notification1, notification2);

		challengeEmployeeDetail = new ChallengeEmployeeDetail();
		challengeEmployeeDetail.setEmployeeAutoId(1L);
		challengeEmployeeDetail.setChallengeStatus("enrolled");

		user = new User();
		user.setEmpId(12345L);
		user.setName("Sushmitha");

		challenges = new CreateChallenges();
		challenges.setChallengeName("packaging peril");
	}

	@Test
	void testGetNotifications() throws Exception {

		when(notificationService.getNotificationsByStatus("launched")).thenReturn(list);

		mockMvc.perform(get("/notifications/launched")).andExpect(status().isOk())
				.andExpect(jsonPath("$[0].id").value(1L)).andExpect(jsonPath("$[0].empName").value("kontham"))
				.andExpect(jsonPath("$[0].empId").value("98765"))
				.andExpect(jsonPath("$[0].challengeName").value("EChallenge"))
				.andExpect(jsonPath("$[0].notificationDate").value("2024-05-03"))
				.andExpect(jsonPath("$[0].notificationTime").value("10:30"))
				.andExpect(jsonPath("$[0].status").value("launched")).andExpect(jsonPath("$[0].isread").value(false))
				.andExpect(jsonPath("$[1].id").value(2L)).andExpect(jsonPath("$[1].empName").value("Alisha"))
				.andExpect(jsonPath("$[1].empId").value("76548"))
				.andExpect(jsonPath("$[1].challengeName").value("package"))
				.andExpect(jsonPath("$[1].notificationDate").value("2024-05-04"))
				.andExpect(jsonPath("$[1].notificationTime").value("11:00"))
				.andExpect(jsonPath("$[1].status").value("launched")).andExpect(jsonPath("$[1].isread").value(false));

		verify(notificationService, times(1)).getNotificationsByStatus("launched");
	}

	@Test
	void testCreateNotification() throws Exception {
		Notification notification = new Notification();
		notification.setId(1L);
		notification.setEmpName("Sushmitha");
		notification.setEmpId(12345L);
		notification.setChallengeName("PerilChallenge");
		notification.setNotificationDate("2024-05-03");
		notification.setNotificationTime("10:00");
		notification.setStatus("enrolled");
		notification.setIsread(false);

		when(notificationService.createNotification(any(Notification.class))).thenReturn(notification);

		mockMvc.perform(
				post("/createNotification").contentType(MediaType.APPLICATION_JSON).content(asJsonString(notification)))
				.andExpect(status().isOk()).andExpect(jsonPath("$.id").value(1L))
				.andExpect(jsonPath("$.empName").value("Sushmitha")).andExpect(jsonPath("$.empId").value("12345"))
				.andExpect(jsonPath("$.challengeName").value("PerilChallenge"))
				.andExpect(jsonPath("$.notificationDate").value("2024-05-03"))
				.andExpect(jsonPath("$.notificationTime").value("10:00"))
				.andExpect(jsonPath("$.status").value("enrolled")).andExpect(jsonPath("$.isread").value(false));

		verify(notificationService, times(1)).createNotification(any(Notification.class));
	}

	private String asJsonString(final Object obj) throws JsonProcessingException {

		return new ObjectMapper().writeValueAsString(obj);

	}

	@Test
	void testMarkNotificationAsRead() throws Exception {
		Long notificationId = 1L;

		mockMvc.perform(put("/notifications/markAsRead/{id}", notificationId)).andExpect(status().isOk())
				.andExpect(content().string("Notification is Read"));

		verify(notificationService, times(1)).markAsRead(notificationId);
	}

	@Test
	void testGetAllNotifications() throws Exception {
		when(notificationService.getAllNotifications()).thenReturn(list);
		mockMvc.perform(get("/getallnotifications")).andExpect(status().isOk()).andExpect(jsonPath("$", hasSize(2)))
				.andExpect(jsonPath("$[0].id", is(1))).andExpect(jsonPath("$[1].id", is(2)));

	}

	@Test
	void testDeleteNotification() throws Exception {
		when(notificationService.deleteByNotificationId(1L)).thenReturn(true);
		mockMvc.perform(delete("/deleteNotification/1")).andExpect(status().isOk())
				.andExpect(content().string("Notification has been deleted"));
		when(notificationService.deleteByNotificationId(1L)).thenReturn(false);
		mockMvc.perform(delete("/deleteNotification/1")).andExpect(status().isOk())
				.andExpect(content().string("Not deleted"));

	}

	@Test
	void testMarkAllRead() throws Exception {
		doNothing().when(notificationService).markAsAllRead();
		mockMvc.perform(patch("/markallasread")).andExpect(status().isOk());
	}

	@Test
	void testGetEnrolledChallenge() throws Exception {
		when(challengeEmployeeDetailRepository.findById(1L)).thenReturn(Optional.of(challengeEmployeeDetail));
		when(userrepository.findById(1L)).thenReturn(Optional.of(user));
		when(challengesRepository.findById(1L)).thenReturn(Optional.of(challenges));

		notificationController.getChallengeEnroll(1L);

		verify(notificationService, never()).createNotification(any(Notification.class));
	}

	@Test
	void testGetChallengeEnrollNull() throws Exception {
		when(challengeEmployeeDetailRepository.findById(1L)).thenReturn(null);
		notificationController.getChallengeEnroll(1L);
		verify(notificationService, never()).createNotification(any(Notification.class));
	}

	@Test
	void testGetChallengeEnrollNoUser() throws Exception {
		when(challengeEmployeeDetailRepository.findById(1L)).thenReturn(Optional.of(challengeEmployeeDetail));
		when(userrepository.findById(1L)).thenReturn(Optional.empty());
		notificationController.getChallengeEnroll(1L);
		verify(notificationService, never()).createNotification(any(Notification.class));
	}

}
