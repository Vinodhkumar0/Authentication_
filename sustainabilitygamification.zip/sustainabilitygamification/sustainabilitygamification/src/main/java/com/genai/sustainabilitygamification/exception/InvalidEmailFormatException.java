package com.genai.sustainabilitygamification.exception;

public class InvalidEmailFormatException extends Exception {

	public InvalidEmailFormatException(String msg) {
		super(msg);
	}
}
