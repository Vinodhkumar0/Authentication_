package com.genai.sustainabilitygamification.service;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genai.sustainabilitygamification.entity.CreateChallenges;
import com.genai.sustainabilitygamification.entity.Notification;
import com.genai.sustainabilitygamification.entity.TypeOfSavings;
import com.genai.sustainabilitygamification.repository.AwardsRepository;
import com.genai.sustainabilitygamification.repository.CreateChallengesRepository;
import com.genai.sustainabilitygamification.repository.TypeOfSavingsRepository;

import io.micrometer.common.util.StringUtils;

@Service
public class CreateChallengesService {

	@Autowired
	private CreateChallengesRepository challengesRepo;

	@Autowired
	private AwardsRepository awardsRepository;

	@Autowired
	private NotificationService notificationService;

	

	public void setNotificationService(NotificationService notificationService) {
		this.notificationService = notificationService;
	}

	@Autowired
	private TypeOfSavingsRepository typeOfSavingsRepository;

	public CreateChallenges createChallenge(CreateChallenges challenge) {
		if (challenge == null) {
			return null;
		}
		saveAwardsIfNew(challenge);
		saveTypeOfSavingsIfNew(challenge.getTypeOfSavings());
		if (!StringUtils.isEmpty(challenge.getStatus())) {
			challenge.setStatus(challenge.getStatus());
		} else {
			challenge.setStatus("");
		}
		Notification notification = new Notification();
		notification.setChallengeName(challenge.getChallengeName());
		notification.setIsread(false);
		notification.setStatus("launched");
		notificationService.createNotification(notification);

		return challengesRepo.save(challenge);
	}

	public CreateChallenges saveDraft(CreateChallenges challenge) {
		if (challenge == null) {
			return null;
		}
		saveAwardsIfNew(challenge);
		saveTypeOfSavingsIfNew(challenge.getTypeOfSavings());
		if (!StringUtils.isEmpty(challenge.getStatus())) {
			challenge.setStatus(challenge.getStatus());
		} else {
			challenge.setStatus("");
		}
		return challengesRepo.save(challenge);
	}

	public void saveAwardsIfNew(CreateChallenges challenge) {
		if (challenge != null && challenge.getAwards() != null && challenge.getAwards().getId() == null) {
			challenge.setAwards(awardsRepository.save(challenge.getAwards()));
		}
	}

	public void saveTypeOfSavingsIfNew(List<TypeOfSavings> typeOfSavingsList) {
		if (typeOfSavingsList != null) {
			for (TypeOfSavings typeOfSavings : typeOfSavingsList) {
				if (typeOfSavings.getId() == null) {
					typeOfSavingsRepository.save(typeOfSavings);
				}
			}
		}
	}

	public void setChallengesRepo(CreateChallengesRepository challengesRepo) {
		this.challengesRepo = challengesRepo;
	}

	public void setAwardsRepository(AwardsRepository awardsRepository) {
		this.awardsRepository = awardsRepository;
	}

	public void setTypeOfSavingsRepository(TypeOfSavingsRepository typeOfSavingsRepository) {
		this.typeOfSavingsRepository = typeOfSavingsRepository;
	}

	
	public List<CreateChallenges> getChallenges() {
		return challengesRepo.findAll();
	}

	public Optional<CreateChallenges> getChallenge(Long id) {
		return challengesRepo.findById(id);
	}

}
