package com.genai.sustainabilitygamification;

import com.genai.sustainabilitygamification.entity.CreateChallenges;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class SustainabilitygamificationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SustainabilitygamificationApplication.class, args);
	}

	@Bean
	CreateChallenges challenges() {
		return new CreateChallenges();
	}
}
