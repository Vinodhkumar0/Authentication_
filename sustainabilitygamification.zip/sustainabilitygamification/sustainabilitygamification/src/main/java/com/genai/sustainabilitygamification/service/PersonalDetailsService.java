package com.genai.sustainabilitygamification.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genai.sustainabilitygamification.repository.StoreManagerRepository;



@Service
public class PersonalDetailsService {

	@Autowired
	StoreManagerRepository managerRepository;

	public PersonalDetailsService(StoreManagerRepository managerRepository) {
		this.managerRepository = managerRepository;
	}

	/*
	 * public StoreManagerDto getDetailsByEmployeeId(String employeeid) {
	 * StoreManager manager = managerRepository.findByEmployeeId(employeeid);
	 * StoreDetailsDto detailsDto = new
	 * StoreDetailsDto(manager.getStoreDetails().getId(),
	 * manager.getStoreDetails().getStoreName(),
	 * manager.getStoreDetails().getStreet(), manager.getStoreDetails().getCity(),
	 * manager.getStoreDetails().getCountry(), manager.getStoreDetails().getState(),
	 * manager.getStoreDetails().getZipCode()); StoreManagerDto managerDto = new
	 * StoreManagerDto(manager.getName(), manager.getEmployeeId(),
	 * manager.getEmail(), manager.getDateOfBirth(), manager.getGender(),
	 * detailsDto); return managerDto; }
	 */

}
