package com.genai.sustainabilitygamification.service;

import static com.genai.sustainabilitygamification.util.CreateChallengeUtil.USER_NOT_FOUND;
import static javax.management.timer.Timer.ONE_MINUTE;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.TextStyle;
import java.time.temporal.ChronoField;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.genai.sustainabilitygamification.dto.LoginDto;
import com.genai.sustainabilitygamification.entity.AuthenticationResponse;
import com.genai.sustainabilitygamification.entity.Notification;
import com.genai.sustainabilitygamification.entity.RegisterResponse;
import com.genai.sustainabilitygamification.entity.Role;
import com.genai.sustainabilitygamification.entity.StoreDetails;
import com.genai.sustainabilitygamification.entity.Token;
import com.genai.sustainabilitygamification.entity.User;
import com.genai.sustainabilitygamification.exception.CustomException;
import com.genai.sustainabilitygamification.repository.ChallengeEmployeeDetailRepository;
import com.genai.sustainabilitygamification.repository.StoreDetailsRepository;
import com.genai.sustainabilitygamification.repository.TokenRepository;
import com.genai.sustainabilitygamification.repository.UserRepository;
import com.genai.sustainabilitygamification.util.EmailUtil;
import com.genai.sustainabilitygamification.util.OtpUtil;

import jakarta.mail.MessagingException;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.security.authentication.AuthenticationManager;

@Service
public class UserServiceImpl implements UserService, UserDetailsService {

	private OtpUtil otpUtil;

	private EmailUtil emailUtil;

	private UserRepository userRepository;

	private TokenRepository tokenRepository;

	private NotificationService notificationService;

	AuthenticationManager authenticationManager;

	JwtService jwtService;

	PasswordEncoder passwordEncoder;

	StoreDetailsRepository storeDetailsRepository;

	private ChallengeEmployeeDetailRepository challengeEmployeeDetailRepository;

	@Autowired
	public UserServiceImpl(@Lazy AuthenticationManager authenticationManager, OtpUtil otpUtil, EmailUtil emailUtil,
			UserRepository userRepository, ChallengeEmployeeDetailRepository challengeEmployeeDetailRepository,
			NotificationService notificationService, PasswordEncoder passwordEncoder,
			StoreDetailsRepository storeDetailsRepository, TokenRepository tokenRepository) {
		this.authenticationManager = authenticationManager;
		this.otpUtil = otpUtil;
		this.emailUtil = emailUtil;
		this.userRepository = userRepository;
		this.challengeEmployeeDetailRepository = challengeEmployeeDetailRepository;
		this.notificationService = notificationService;
		this.tokenRepository = tokenRepository;
		this.passwordEncoder = passwordEncoder;
		this.storeDetailsRepository = storeDetailsRepository;

	}

	@Autowired
	public void setAuthenticationManager(AuthenticationManager authenticationManager) {
		this.authenticationManager = authenticationManager;
	}

	@Autowired
	public void setJwtService(JwtService jwtService) {
		this.jwtService = jwtService;
	}

	public UserServiceImpl() {
	}

	@Override
	public String verifyAccount(String otp) {

		User user = getLatestRegisteredUser();

		if (user == null) {
			throw new CustomException(USER_NOT_FOUND);
		}
		if (user.getOtp().equals(otp)
				&& Duration.between(user.getOtpGeneratedTime(), LocalDateTime.now()).getSeconds() < (ONE_MINUTE)) {
			userRepository.save(user);
			return "OTP verified you can login";
		}
		return "Please regenerate otp and try again";
	}

	@Override
	public String regenerateOtp() {
		User user = getLatestRegisteredUser();
		if (user == null) {
			throw new CustomException(USER_NOT_FOUND);
		}
		String otp = otpUtil.generateOtp();
		try {
			emailUtil.sendOtpEmail(user.getEmail(), otp);
		} catch (MessagingException e) {
			throw new CustomException("Unable to send otp please try again");
		}
		user.setOtp(otp);
		user.setOtpGeneratedTime(LocalDateTime.now());
		userRepository.save(user);
		return "Email sent... please verify account within 1 minute";
	}

	@Override
	public String login(LoginDto loginDto) {
		User user = userRepository.findByEmail(loginDto.getEmail())
				.orElseThrow(() -> new CustomException(USER_NOT_FOUND + loginDto.getEmail()));
		if (!loginDto.getPassword().equals(user.getPassword())) {
			return "Password is incorrect";
		} else if (!user.isApproved()) {
			return "your account is not verified";
		}
		return "Login successful";
	}

	private void saveUserToken(String accessToken, User user) {
		Token token = new Token();
		token.setAccessToken(accessToken);

		token.setLoggedOut(false);
		token.setUser(user);
		tokenRepository.save(token);
	}

	@Override
	public List<User> findAll() {
		return userRepository.findAll();
	}

	public AuthenticationResponse authenticate(User user) {

		authenticationManager
				.authenticate(new UsernamePasswordAuthenticationToken(user.getEmpId(), user.getPassword()));
		System.out.println("sushshsh");
		User user1 = userRepository.findByEmpId(user.getEmpId()).orElseThrow();
		System.out.println("after");
		String accessToken = jwtService.generateAccessToken(user1);
		System.out.println("before");
		String refreshToken = jwtService.generateRefreshToken(user1);

		System.out.println("shabash");
		revokeAllTokenByUser(user1);
		System.out.println("after shabash");
		saveUserToken(accessToken, user1);
		System.out.println("axxrdd " + accessToken);

		return new AuthenticationResponse(accessToken, "User login was successful");

	}

	private void revokeAllTokenByUser(User user) {
		System.out.println(user.getId());
		System.out.println(user.toString());
		if (user == null || user.getId() == null) {
			throw new IllegalArgumentException("User or User ID cannot be null");
		}

		List<Token> validTokens = tokenRepository.findAllAccessTokensByUser(user.getId().intValue());
		if (validTokens.isEmpty()) {
			return;
		}

		validTokens.forEach(t -> {
			t.setLoggedOut(true);
		});

		tokenRepository.saveAll(validTokens);
	}

	public ResponseEntity refreshToken(HttpServletRequest request, HttpServletResponse response) {
		// extract the token from authorization header
		String authHeader = request.getHeader(HttpHeaders.AUTHORIZATION);

		if (authHeader == null || !authHeader.startsWith("Bearer ")) {
			return new ResponseEntity(HttpStatus.UNAUTHORIZED);
		}

		String token = authHeader.substring(7);

		// extract username from token
		String username = jwtService.extractEmployeeId(token);

		// check if the user exist in database
		User user = userRepository.findByEmpId(Long.parseLong(username))
				.orElseThrow(() -> new RuntimeException("No user found"));

		// check if the token is valid
		if (jwtService.isValidRefreshToken(token, user)) {
			// generate access token
			String accessToken = jwtService.generateAccessToken(user);
			String refreshToken = jwtService.generateRefreshToken(user);

			revokeAllTokenByUser(user);
			saveUserToken(accessToken, user);

			return new ResponseEntity(new AuthenticationResponse(accessToken, "New token generated"), HttpStatus.OK);
		}

		return new ResponseEntity(HttpStatus.UNAUTHORIZED);

	}

	@Override
	public RegisterResponse save(User user) {

		if (userRepository.findByEmpId(user.getEmpId()).isPresent()) {
			return new RegisterResponse("User already exist");
		}
		if (user != null) {
			if (user.getStoreDetails() != null) {

				StoreDetails storeDetails = new StoreDetails(user.getStoreDetails().getStoreName(),
						user.getStoreDetails().getStreet(), user.getStoreDetails().getCity(),
						user.getStoreDetails().getCountry(), user.getStoreDetails().getState(),
						user.getStoreDetails().getZipCode());

				storeDetailsRepository.save(storeDetails);

				user.setName(user.getName());
				user.setEmpId(user.getEmpId());
				user.setPassword(passwordEncoder.encode(user.getPassword()));
				user.setDateOfBirth(user.getDateOfBirth());
				user.setEmail(user.getEmail());
				user.setGender(user.getGender());
				user.setStoreDetails(storeDetails);
				user.setRole(user.getRole());
//		user.setVerified(user.isVerified());
				user.getStoreDetails().setStoreManagerId(user.getManagerId());
				user = userRepository.save(user);

			}

			String otp = otpUtil.generateOtp();
			try {
				emailUtil.sendOtpEmail(user.getEmail(), otp);
				user.setOtp(otp);
				user.setOtpGeneratedTime(LocalDateTime.now());
				userRepository.save(user);
				Notification notification = new Notification();
				notification.setEmpName(user.getName());
				notification.setEmpId(user.getEmpId());
				System.out.println(user.getEmpId());
				notification.setIsread(false);
				notification.setStatus("registered");
				notificationService.createNotification(notification);
				return new RegisterResponse("User registered. OTP is sent to " + user.getEmail());
			} catch (MessagingException e) {
				throw new CustomException("Unable to send otp please try again");
			}
		} else {
			return new RegisterResponse("User information is incomplete. Please try again.");
		}
	}

	@Override
	public Optional<User> getUser(Long id) {
		return userRepository.findById(id);
	}

	@Override
	public List<User> employeesUnderStoreManager(Long storeManagerId) {
		Optional<User> storeManager = userRepository.findById(storeManagerId);
		Long storeManagerEmpId = storeManager.orElseThrow().getEmpId();
		List<User> lstEmployeesUnderStoreManager = userRepository.findByManagerId(storeManagerEmpId);
		for (int i = 0; i < lstEmployeesUnderStoreManager.size(); i++) {
			lstEmployeesUnderStoreManager.get(i).setStoreDetails(storeManager.orElseThrow().getStoreDetails());
			lstEmployeesUnderStoreManager.get(i).setChallengeEmployeeDetail(challengeEmployeeDetailRepository
					.findByEmployeeAutoId(lstEmployeesUnderStoreManager.get(i).getId()));
		}
		return lstEmployeesUnderStoreManager;
	}

	@Override
	public List<User> managersUnderCompany(Long id) {
		Optional<User> companyDetails = userRepository.findById(id);
		Long companyId = companyDetails.orElseThrow().getEmpId();
		List<User> lstManagersUnderCompany = userRepository.findByManagerId(companyId);
		List<User> employeesUnderStoreManagers;
		for (int i = 0; i < lstManagersUnderCompany.size(); i++) {
			if (lstManagersUnderCompany.get(i).getEmpId() == 0) {
				lstManagersUnderCompany.remove(i);
			} else {
				employeesUnderStoreManagers = employeesUnderStoreManager(lstManagersUnderCompany.get(i).getId());
				lstManagersUnderCompany.get(i).setChallengeEmployeeDetail(
						challengeEmployeeDetailRepository.findByEmployeeAutoId(lstManagersUnderCompany.get(i).getId()));
				if (!employeesUnderStoreManagers.isEmpty()) {
					lstManagersUnderCompany.get(i).setEmployeesUnderStoreManager(
							employeesUnderStoreManager(lstManagersUnderCompany.get(i).getId()));
				}
			}
		}
		return lstManagersUnderCompany;
	}

	@Override
	public User getLatestRegisteredUser() {
		return userRepository.findTheLatestEmail();
	}

	@Override
	public Optional<User> approveUser(long id) {
		return userRepository.findById(id).map(user -> {
			user.setApproved(true);
			return userRepository.save(user);
		});

	}

	@Override
	public Optional<User> declineUser(long id) {
		return userRepository.findById(id).map(user -> {
			user.setApproved(false);
			return userRepository.save(user);
		});
	}

	@Override
	public User loadUserByUsername(String employeeId) throws UsernameNotFoundException {
		return userRepository.findByEmpId(Long.parseLong(employeeId))
				.orElseThrow(() -> new UsernameNotFoundException("User not found"));
	}

}