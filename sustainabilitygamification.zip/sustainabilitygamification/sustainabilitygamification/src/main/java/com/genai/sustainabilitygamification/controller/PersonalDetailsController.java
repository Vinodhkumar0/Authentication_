package com.genai.sustainabilitygamification.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;

import com.genai.sustainabilitygamification.service.PersonalDetailsService;


@CrossOrigin("*")
@RestController
public class PersonalDetailsController {

	@Autowired
	PersonalDetailsService detailsService;

	public PersonalDetailsController(PersonalDetailsService detailsService) {
		this.detailsService = detailsService;
	}

	/*
	 * @GetMapping("/PersonalDetails/{employeeId}") public
	 * ResponseEntity<StoreManagerDto> getPersonalDetailsByEmployeeId(@PathVariable
	 * String employeeId) { return
	 * ResponseEntity.ok(detailsService.getDetailsByEmployeeId(employeeId)); }
	 */

}
