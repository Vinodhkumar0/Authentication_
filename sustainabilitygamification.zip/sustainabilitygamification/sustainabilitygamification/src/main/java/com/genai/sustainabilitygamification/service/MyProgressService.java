package com.genai.sustainabilitygamification.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genai.sustainabilitygamification.dto.MyProgressDto;
import com.genai.sustainabilitygamification.entity.MyProgress;
import com.genai.sustainabilitygamification.entity.Participate;
import com.genai.sustainabilitygamification.repository.ParticipateRepository;


@Service
public class MyProgressService {

    @Autowired
    ParticipateRepository participateRepository;

    public List<MyProgressDto> getProgressByEmployeeId(String employeeId) {
        Map<Integer, MyProgressDto> combinedData = new HashMap<>();
        LocalDate startDate=null;

        for (Participate p : participateRepository.findByEmployeeId(employeeId)) {
            if (p.getChallengeStatus().equalsIgnoreCase("enrolled") || p.getChallengeStatus().equalsIgnoreCase("defaultenrolled")) {
                if(startDate==null) {
                	startDate = p.getStartDate();
                }
                int weekNumber = 1;

                for (MyProgress pp : p.getMyProgress()) {
                    LocalDate progressDate = pp.getDate();
                    int dayDifference = startDate.until(progressDate).getDays();

                    if (dayDifference >= 0) {
                        weekNumber = (dayDifference / 7) + 1;

                        MyProgressDto weekData = combinedData.getOrDefault(weekNumber, new MyProgressDto(0L, 0L, 0L, weekNumber));
                        weekData.setDollerSavings(weekData.getDollerSavings() + pp.getDollerSavings());
                        weekData.setWasteSavings(weekData.getWasteSavings() + pp.getWasteSavings());
                        weekData.setCo2Savings(weekData.getCo2Savings() + pp.getCo2savings());

                        combinedData.put(weekNumber, weekData);
                    }
                }
            }
        }

        return new ArrayList<>(combinedData.values());
    }
}
