package com.genai.sustainabilitygamification.entity;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table
public class MyProgress {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private LocalDate date;
	private double sales;
	private double amountPackagingPurchased;
	private int progressPercentage;
	private Long dollerSavings;
	private Long wasteSavings;
	private Long co2savings;

	public MyProgress(Long id, LocalDate date, double sales, double amountPackagingPurchased) {
		this.id = id;
		this.date = date;
		this.sales = sales;
		this.amountPackagingPurchased = amountPackagingPurchased;
		this.dollerSavings = (long) (sales * amountPackagingPurchased);
		this.wasteSavings = (long) (sales * amountPackagingPurchased * 2);
		this.co2savings = (long) (sales * amountPackagingPurchased * 0.5);
	}

	public void setDollerSavings(double sales, double amountPackagingPurchased) {
		this.dollerSavings = (long) (sales * amountPackagingPurchased);
	}

	public void setWasteSavings(double sales, double amountPackagingPurchased) {
		this.wasteSavings = (long) (sales * amountPackagingPurchased * 2);
	}

	public void setCo2savings(double sales, double amountPackagingPurchased) {
		this.co2savings = (long) (sales * amountPackagingPurchased * 0.5);
	}

	public Long getDollerSavings() {
		return dollerSavings;
	}

	public Long getWasteSavings() {
		return wasteSavings;
	}

	public Long getCo2savings() {
		return co2savings;
	}

	public int getProgressPercentage() {
		return progressPercentage;
	}

	public void setProgressPercentage(int progressPercentage) {
		this.progressPercentage = progressPercentage;
	}

	public MyProgress() {
	}

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public double getSales() {
		return sales;
	}

	public void setSales(double sales) {
		this.sales = sales;
	}

	public double getAmountPackagingPurchased() {
		return amountPackagingPurchased;
	}

	public void setAmountPackagingPurchased(double amountPackagingPurchased) {
		this.amountPackagingPurchased = amountPackagingPurchased;
	}

	public void setDollerSavings(long l) {
		this.dollerSavings = l;

	}

	public void setCo2savings(long l) {
		this.co2savings = l;

	}

	public void setWasteSavings(long l) {
		this.wasteSavings = l;

	}

}
