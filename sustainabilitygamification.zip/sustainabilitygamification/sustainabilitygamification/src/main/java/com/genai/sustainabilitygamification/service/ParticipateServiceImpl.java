package com.genai.sustainabilitygamification.service;


import com.genai.sustainabilitygamification.entity.Employee;
import com.genai.sustainabilitygamification.entity.ParticipateTab;
import com.genai.sustainabilitygamification.exception.CustomException;
import com.genai.sustainabilitygamification.repository.EmployeeRepository;
import com.genai.sustainabilitygamification.repository.ParticipateRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ParticipateServiceImpl implements ParticipateService {
    private final ParticipateRepo participateRepository;
    private final EmployeeRepository userRepository;

    @Autowired
    public ParticipateServiceImpl(ParticipateRepo participateRepository, EmployeeRepository userRepository) {
        this.participateRepository = participateRepository;
        this.userRepository = userRepository;
    }

    @Override
    public List<ParticipateTab> getParticipateList() {
        return participateRepository.findAll();
    }

    @Override
    public ParticipateTab getParticipateById(int participateId) {
        return participateRepository.findById(participateId)
                .orElseThrow(() -> new CustomException("Participate ID not found.."));
    }

    @Override
    public List<ParticipateTab> getAllParticipatesByUserId(int id) {
        return userRepository.findById(id).map(Employee::getParticipateTabs)
                .orElseThrow(() -> new CustomException("User ID not found.."));
    }


}
