package com.genai.sustainabilitygamification.exception;

public class InvalidNameException extends Exception {

	public InvalidNameException(String msg) {
		super(msg);
	}
}
