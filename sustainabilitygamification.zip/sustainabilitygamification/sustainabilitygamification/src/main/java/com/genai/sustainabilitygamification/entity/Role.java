package com.genai.sustainabilitygamification.entity;

public enum Role {
    MANAGER,
    COMPANY,
	EMPLOYEE
}
