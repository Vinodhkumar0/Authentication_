package com.genai.sustainabilitygamification.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.genai.sustainabilitygamification.dto.RegisterDto;
import com.genai.sustainabilitygamification.service.ForgotPasswordService;

@RestController
@RequestMapping("/forgot")
public class ForgotPasswordController {

	private final ForgotPasswordService forgotPasswordService;

	@Autowired
	public ForgotPasswordController(ForgotPasswordService forgotPasswordService) {
		this.forgotPasswordService = forgotPasswordService;
	}

	@PostMapping("/register")
	public ResponseEntity<String> register(@RequestBody RegisterDto registerDto) {
		return new ResponseEntity<>(forgotPasswordService.register(registerDto), HttpStatus.OK);
	}

	@PutMapping("/forgot-password")
	public ResponseEntity<String> forgetPassword(@RequestParam String email) {
		return new ResponseEntity<>(forgotPasswordService.forgetPassword(email), HttpStatus.OK);
	}

	@PutMapping("/set-password")
	public ResponseEntity<String> setPassword(@RequestParam String email, @RequestHeader String newPassword) {
		return new ResponseEntity<>(forgotPasswordService.setPassword(email, newPassword), HttpStatus.OK);
	}

}
