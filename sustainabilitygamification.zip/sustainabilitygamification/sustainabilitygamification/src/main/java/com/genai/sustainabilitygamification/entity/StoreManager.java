package com.genai.sustainabilitygamification.entity;

import java.time.LocalDate;

import com.genai.sustainabilitygamification.dto.StoreDetailsDto;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "manager")
public class StoreManager {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@NotBlank(message = "Name is required")
	@Pattern(regexp = "^[a-zA-Z ]*$", message = "Name should contain only alphabetic characters")
	@Size(min = 2, max = 25, message = "Name length must be between 2 and 25 characters")
	private String name;

	@NotBlank(message = "Employee ID is required")
	@Pattern(regexp = "^\\d+$", message = "Employee ID should contain only digits")
	private String employeeId;

	@NotBlank(message = "Email is required")
	@Email(message = "Invalid email format")
	private String email;

	private LocalDate dateOfBirth;
	private String gender;

	
	/*
	 * @OneToOne(mappedBy = "storeManager", cascade = CascadeType.ALL) private
	 * StoreDetails storeDetails;
	 */
	 

	@NotBlank(message = "Password is required")
	@Size(min = 8, max = 20, message = "Password length must be between 8 and 20 characters")
	@Pattern(regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]+$", message = "Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character")
	private String password;

	@NotBlank(message = "Confirm Password is required")
	private String confirmPassword;

	private boolean isVerified;

	public StoreManager() {

	}

	public StoreManager(Long id,
			@NotBlank(message = "Name is required") @Pattern(regexp = "^[a-zA-Z ]*$", message = "Name should contain only alphabetic characters") @Size(min = 2, max = 25, message = "Name length must be between 2 and 25 characters") String name,
			@NotBlank(message = "Employee ID is required") @Pattern(regexp = "^\\d+$", message = "Employee ID should contain only digits") String employeeId,
			@NotBlank(message = "Email is required") @Email(message = "Invalid email format") String email,
			LocalDate dateOfBirth, String gender) {
		super();
		this.id = id;
		this.name = name;
		this.employeeId = employeeId;
		this.email = email;
		this.dateOfBirth = dateOfBirth;
		this.gender = gender;

	}
	public StoreManager (StoreDetails storeDetails,
						 @NotBlank(message = "Password is required") @Size(min = 8, max = 20, message = "Password length must be between 8 and 20 characters") @Pattern(regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]+$", message = "Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character") String password,
						 @NotBlank(message = "Confirm Password is required") String confirmPassword, Boolean isVerified){
		//this.storeDetails = storeDetails;
		this.password = password;
		this.confirmPassword = confirmPassword;
		this.isVerified = isVerified;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	
	/*
	 * public StoreDetails getStoreDetails() { return storeDetails; }
	 * 
	 * public void setStoreDetails(StoreDetails storeDetails) { this.storeDetails =
	 * storeDetails; }
	 */

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public boolean isVerified() {
		return isVerified;
	}

	public void setVerified(boolean verified) {
		isVerified = verified;
	}

	public StoreDetailsDto getStoreDetails() {
		// TODO Auto-generated method stub
		return null;
	}
}
