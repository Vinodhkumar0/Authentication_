package com.genai.sustainabilitygamification.entity;

import java.time.LocalDate;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table
public class Participate {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String challengeName;
	private LocalDate startDate;
	private LocalDate endDate;
	private String featuredBy;
	private String challengeStatus;
	private String createdBy;
	private String employeeId;
	@OneToMany
	private List<MyProgress> myProgress;

	public Participate() {

	}

	public Participate(Long id, String challengeName, LocalDate startDate, LocalDate endDate, String featuredBy,
			String challengeStatus, String createdBy, String employeeId, List<MyProgress> myProgress) {
		super();
		this.id = id;
		this.challengeName = challengeName;
		this.startDate = startDate;
		this.endDate = endDate;
		this.featuredBy = featuredBy;
		this.challengeStatus = challengeStatus;
		this.createdBy = createdBy;
		this.employeeId = employeeId;
		this.myProgress = myProgress;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getChallengeName() {
		return challengeName;
	}

	public void setChallengeName(String challengeName) {
		this.challengeName = challengeName;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public String getFeaturedBy() {
		return featuredBy;
	}

	public void setFeaturedBy(String featuredBy) {
		this.featuredBy = featuredBy;
	}

	public String getChallengeStatus() {
		return challengeStatus;
	}

	public void setChallengeStatus(String challengeStatus) {
		this.challengeStatus = challengeStatus;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public List<MyProgress> getMyProgress() {
		return myProgress;
	}

	public void setMyProgress(List<MyProgress> myProgress) {
		this.myProgress = myProgress;
	}

}
