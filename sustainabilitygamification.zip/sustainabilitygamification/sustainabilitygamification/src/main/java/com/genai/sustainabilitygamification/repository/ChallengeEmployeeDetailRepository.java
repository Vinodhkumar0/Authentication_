package com.genai.sustainabilitygamification.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.genai.sustainabilitygamification.entity.ChallengeEmployeeDetail;
import java.util.List;

@Repository
public interface ChallengeEmployeeDetailRepository extends JpaRepository<ChallengeEmployeeDetail, Long> {
	
	public List<ChallengeEmployeeDetail> findByEmployeeAutoId(Long employeeAutoId);

}
