package com.genai.sustainabilitygamification.dto;

public class MySavingsDto {

	private Long dollarSavings;
	private Long wasteSavings;
	private Long co2Savings;

	public MySavingsDto() {
	}

	public MySavingsDto(Long dollarSavings, Long wasteSavings, Long co2Savings) {
		super();
		this.dollarSavings = dollarSavings;
		this.wasteSavings = wasteSavings;
		this.co2Savings = co2Savings;
	}

	public Long getDollarSavings() {
		return dollarSavings;
	}

	public void setDollarSavings(Long dollarSavings) {
		this.dollarSavings = dollarSavings;
	}

	public Long getWasteSavings() {
		return wasteSavings;
	}

	public void setWasteSavings(Long wasteSavings) {
		this.wasteSavings = wasteSavings;
	}

	public Long getCo2Savings() {
		return co2Savings;
	}

	public void setCo2Savings(Long co2Savings) {
		this.co2Savings = co2Savings;
	}

}
