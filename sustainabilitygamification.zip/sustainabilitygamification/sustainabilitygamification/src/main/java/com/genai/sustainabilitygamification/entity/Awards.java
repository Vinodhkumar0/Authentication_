package com.genai.sustainabilitygamification.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Awards {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String winner;
	private String firstRunnerUp;
	private String secondRunnerUp;

	public Awards() {

	}

	public Awards(Long id, String winner, String firstRunnerUp, String secondRunnerUp) {
		this.id = id;
		this.winner = winner;
		this.firstRunnerUp = firstRunnerUp;
		this.secondRunnerUp = secondRunnerUp;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getWinner() {
		return winner;
	}

	public void setWinner(String winner) {
		this.winner = winner;
	}

	public String getFirstRunnerUp() {
		return firstRunnerUp;
	}

	public void setFirstRunnerUp(String firstRunnerUp) {
		this.firstRunnerUp = firstRunnerUp;
	}

	public String getSecondRunnerUp() {
		return secondRunnerUp;
	}

	public void setSecondRunnerUp(String secondRunnerUp) {
		this.secondRunnerUp = secondRunnerUp;
	}

}
