package com.genai.sustainabilitygamification.entity;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "notification")
public class Notification {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String empName;
	private Long empId;
	private String challengeName;
	private String notificationDate;
	private String notificationTime;
	private String status;
	private boolean isread;

	public Notification() {

	}

	public Notification(Long id, String empName, Long empId, String challengeName) {
        this.id = id;
        this.empName = empName;
        this.empId = empId;
        this.challengeName = challengeName;
    }
	 public Notification(String notificationDate, String notificationTime, String status, boolean isread) {
	        this.notificationDate = notificationDate;
	        this.notificationTime = notificationTime;
	        this.status = status;
	        this.isread = isread;
	    }
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public Long getEmpId() {
		return empId;
	}

	public void setEmpId(Long empId) {
		this.empId = empId;
	}

	public String getChallengeName() {
		return challengeName;
	}

	public void setChallengeName(String challengeName) {
		this.challengeName = challengeName;
	}

	public String getNotificationDate() {
		return notificationDate;
	}

	public void setNotificationDate(String notificationDate) {
		this.notificationDate = notificationDate;
	}

	public String getNotificationTime() {
		return notificationTime;
	}

	public void setNotificationTime(String notificationTime) {
		this.notificationTime = notificationTime;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public boolean isIsread() {
		return isread;
	}

	public void setIsread(boolean isread) { 
		this.isread = isread;
	}
	
	


}
