package com.genai.sustainabilitygamification.service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.TextStyle;
import java.time.temporal.ChronoField;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PatchMapping;

import com.genai.sustainabilitygamification.entity.Notification;
import com.genai.sustainabilitygamification.repository.NotificationRepository;

@Service
public class NotificationService {

	private NotificationRepository notificationRepository;

	@Autowired
	public NotificationService(NotificationRepository notificationRepository) {
		this.notificationRepository = notificationRepository;
	}

	public Notification createNotification(Notification notification) {
		LocalDate date = LocalDate.now();
		LocalTime time = LocalTime.now();
		DateTimeFormatter dateTimeFormatter = new DateTimeFormatterBuilder().appendPattern("d ")
				.appendText(ChronoField.MONTH_OF_YEAR, TextStyle.FULL_STANDALONE).toFormatter(Locale.ENGLISH);
		DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
		notification.setNotificationDate(date.format(dateTimeFormatter));
		notification.setNotificationTime(time.format(timeFormatter));

		return notificationRepository.save(notification);
	}

	public List<Notification> getAllNotifications() {
		return notificationRepository.findAll();
	}

	public List<Notification> getNotificationsByStatus(String status) {
		if (status == null || status.isEmpty()) {
			return getAllNotifications();
		} else {
			List<Notification> notifications = notificationRepository.findNotificationsByStatus(status);
			if (notifications.isEmpty()) {
				return getAllNotifications();
			} else {
				return notifications;
			}
		}
	}

	public void markAsRead(Long id) {
		Notification notification = notificationRepository.findById(id).orElse(null);
		if (notification != null) {
			notification.setIsread(true);
			notificationRepository.save(notification);

		}
	}

	public boolean deleteByNotificationId(Long id) {
		Notification notification = notificationRepository.findById(id).orElse(null);
		if (notification != null) {
			notificationRepository.delete(notification);
			return true;
		}
		return false;

	}

	public void markAsAllRead() {
		List<Notification> notifications = notificationRepository.findAll();
		for (Notification notification : notifications) {
			notification.setIsread(true);
		}
		notificationRepository.saveAll(notifications);
	}

}
