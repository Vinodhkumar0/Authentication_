package com.genai.sustainabilitygamification.exception;

public class EmployeeIdAlreadyExistsException extends Exception {

	public EmployeeIdAlreadyExistsException(String msg) {
		super(msg);
	}

}
