package com.genai.sustainabilitygamification.dto;

import java.util.List;

public class ManagersDto {
	
	private String managerName;
	private String employeeId;
	private String email;
	private String storeName;
	private String state;
	private String regDate;
	private List<EmployeeDto> employees;
	
	public ManagersDto(String managerName, String employeeId, String email, String storeName, String state,
			String regDate, List<EmployeeDto> employees) {
		this.managerName = managerName;
		this.employeeId = employeeId;
		this.email = email;
		this.storeName = storeName;
		this.state = state;
		this.regDate = regDate;
		this.employees = employees;
	}



	public String getManagerName() {
		return managerName;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public String getEmail() {
		return email;
	}
	public String getStoreName() {
		return storeName;
	}
	public String getState() {
		return state;
	}
	public String getRegDate() {
		return regDate;
	}
	public List<EmployeeDto> getEmployees() {
		return employees;
	}

}
