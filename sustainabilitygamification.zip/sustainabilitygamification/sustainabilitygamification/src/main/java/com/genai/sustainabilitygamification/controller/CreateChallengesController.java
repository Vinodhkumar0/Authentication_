package com.genai.sustainabilitygamification.controller;
import java.util.List;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.genai.sustainabilitygamification.entity.CreateChallenges;
import com.genai.sustainabilitygamification.service.CreateChallengesService;
import com.genai.sustainabilitygamification.util.CreateChallengeUtil;

@CrossOrigin("*")
@RestController
public class CreateChallengesController {

	@Autowired
	private CreateChallengesService challengesService;
	
	Logger logger = Logger.getLogger(CreateChallengesController.class.getSimpleName());

	@PostMapping("/saveDraft") 
	public ResponseEntity<String> saveDraft(@RequestBody CreateChallenges challenge) {
		logger.log(Level.INFO,"drafted challenge");
		challengesService.saveDraft(challenge);
		return ResponseEntity.ok(CreateChallengeUtil.DRAFTED_MESSAGE);
	}
	
	@PostMapping("/createAndPublish") 
	public ResponseEntity<String> createChallenge(@RequestBody CreateChallenges challenge) {
		System.out.println("Challenge to be published");
		logger.log(Level.INFO,"Challenge to be published");
		challengesService.createChallenge(challenge);
		return ResponseEntity.ok(CreateChallengeUtil.PUBLISHED_MESSAGE);
	}

	public void setChallengesService(CreateChallengesService service) {
		this.challengesService = service;
	}
	
	@GetMapping("/challenges")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<CreateChallenges> getChallenges() {
		return challengesService.getChallenges();
	}
	
	@GetMapping("/challenges/{id}")
	@CrossOrigin(origins = "http://localhost:4200")
	public Optional<CreateChallenges> getChallenges(@PathVariable Long id) {
		return challengesService.getChallenge(id);
	}
}
