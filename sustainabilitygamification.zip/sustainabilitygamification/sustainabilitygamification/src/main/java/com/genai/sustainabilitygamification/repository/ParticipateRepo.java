package com.genai.sustainabilitygamification.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.genai.sustainabilitygamification.entity.ParticipateTab;

@Repository
public interface ParticipateRepo extends JpaRepository<ParticipateTab, Integer> {
}
