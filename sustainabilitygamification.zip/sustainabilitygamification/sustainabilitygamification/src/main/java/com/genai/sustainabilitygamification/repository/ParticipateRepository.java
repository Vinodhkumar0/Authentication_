package com.genai.sustainabilitygamification.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.genai.sustainabilitygamification.entity.Participate;


@Repository
public interface ParticipateRepository extends JpaRepository<Participate, Long> {

	List<Participate> findByEmployeeId(String employeeId);

}
