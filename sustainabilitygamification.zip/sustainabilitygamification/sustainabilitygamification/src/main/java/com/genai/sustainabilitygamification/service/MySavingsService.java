package com.genai.sustainabilitygamification.service;

import java.util.Comparator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genai.sustainabilitygamification.dto.MySavingsDto;
import com.genai.sustainabilitygamification.entity.MyProgress;
import com.genai.sustainabilitygamification.entity.Participate;
import com.genai.sustainabilitygamification.repository.ParticipateRepository;


@Service
public class MySavingsService {

	@Autowired
	ParticipateRepository participateRepository;

	public MySavingsDto getSavingsByEmployeeId(String employeeId) {
		List<Participate> participates = participateRepository.findByEmployeeId(employeeId);
		Long dollerSavings = 0L;
		Long wasteSavings = 0L;
		Long co2Savings = 0L;
		for (Participate p : participates) {
			if (p.getChallengeStatus().equalsIgnoreCase("enrolled")
					|| p.getChallengeStatus().equalsIgnoreCase("defaultenrolled")) {
				List<MyProgress> list = p.getMyProgress();
				list.sort(Comparator.comparing(MyProgress::getDate).reversed());
				dollerSavings += list.stream().findFirst().get().getDollerSavings();
				wasteSavings += list.stream().findFirst().get().getWasteSavings();
				co2Savings += list.stream().findFirst().get().getCo2savings();
			}
		}

		return new MySavingsDto(dollerSavings, wasteSavings, co2Savings);

	}

}
