package com.genai.sustainabilitygamification.service;

import com.genai.sustainabilitygamification.entity.StoreManager;
import com.genai.sustainabilitygamification.repository.StoreManagerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StoreManagerServiceImpl implements StoreManagerService {

    private StoreManagerRepository storeManagerRepository;

    @Autowired
    public StoreManagerServiceImpl(StoreManagerRepository storeManagerRepository) {
        this.storeManagerRepository = storeManagerRepository;
    }

    @Override
    public StoreManager register(StoreManager storeManager) {
        return storeManagerRepository.save(storeManager);
    }

}
