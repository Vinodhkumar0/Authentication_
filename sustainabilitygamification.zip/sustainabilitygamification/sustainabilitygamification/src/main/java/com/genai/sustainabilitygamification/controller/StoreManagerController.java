//package com.genai.sustainabilitygamification.controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.util.StringUtils;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.genai.sustainabilitygamification.entity.Login;
//import com.genai.sustainabilitygamification.entity.StoreManager;
//import com.genai.sustainabilitygamification.exception.ContainsOnlyDigitsException;
//import com.genai.sustainabilitygamification.exception.EmailAlreadyExistsException;
//import com.genai.sustainabilitygamification.exception.EmployeeIdAlreadyExistsException;
//import com.genai.sustainabilitygamification.exception.EmployeeNotFoundException;
//import com.genai.sustainabilitygamification.exception.InvalidEmailFormatException;
//import com.genai.sustainabilitygamification.exception.InvalidNameException;
//import com.genai.sustainabilitygamification.exception.InvalidPasswordFormatException;
//import com.genai.sustainabilitygamification.repository.StoreDetailsRepository;
//import com.genai.sustainabilitygamification.repository.StoreManagerRepository;
//import com.genai.sustainabilitygamification.service.StoreManagerService;
//
//@CrossOrigin("*")
//@RestController
//public class StoreManagerController {
//	private StoreManagerService managerService;
//	private StoreManagerRepository repository;
//	private StoreDetailsRepository storeDetailsRepository;
//
//	@Autowired
//	public StoreManagerController(StoreManagerService managerService, StoreManagerRepository repository,
//			StoreDetailsRepository storeDetailsRepository) {
//		this.managerService = managerService;
//		this.repository = repository;
//		this.storeDetailsRepository = storeDetailsRepository;
//	}
//
//	public StoreManagerController() {
//	}
//
//	public StoreManagerService getManagerService() {
//		return managerService;
//	}
//
//	@PostMapping("/registermanager") // 1
//	public ResponseEntity<String> registerManager(@RequestBody StoreManager storeManager)
//			throws InvalidPasswordFormatException, InvalidNameException, InvalidEmailFormatException,
//			ContainsOnlyDigitsException, EmployeeIdAlreadyExistsException, EmailAlreadyExistsException {
//		validateStoreManager(storeManager);
//
//		StoreManager savedManager = repository.save(storeManager);
//
//		//StoreDetails storeDetails = storeManager.getStoreDetails();
//		/*
//		 * if (storeDetails == null) { storeDetails = new StoreDetails(); }
//		 * storeDetails.setStoreManager(savedManager);
//		 */
//
//		//storeDetailsRepository.save(storeDetails);
//
//		return ResponseEntity.ok("Manager registered successfully");// 2
//	}
//
//	@SuppressWarnings({ "static-access", "unused" })
//	private void validateStoreManager(StoreManager storeManager)
//			throws InvalidPasswordFormatException, InvalidNameException, InvalidEmailFormatException,
//			ContainsOnlyDigitsException, EmployeeIdAlreadyExistsException, EmailAlreadyExistsException {
//		String password = storeManager.getPassword();
//		String confirmPassword = storeManager.getConfirmPassword();
//		String employeeId = storeManager.getEmployeeId();
//		String name = storeManager.getName();
//		String email = storeManager.getEmail();
//
//		if (password == null || password.isBlank() || password.length() < 8 || password.length() > 20
//				|| !password.matches("^(?=.*[A-Z]).{8,20}$")) {// 3
//			throw new InvalidPasswordFormatException(
//					"Password must be between 8 and 20 characters long and contain at least one uppercase letter");// 4
//		}
//
//		if (!password.equals(confirmPassword)) {
//			throw new InvalidPasswordFormatException("Password and confirm password do not match");
//		}
//
//		if (employeeId == null || !employeeId.matches("\\d{6}")) {// 4
//			throw new ContainsOnlyDigitsException("Employee ID must be exactly 6 digits long and contain only digits");
//		}
//
//		if (repository.existsByEmployeeId(employeeId)) {
//			throw new EmployeeIdAlreadyExistsException("Employee ID Already Exists");
//		}
//
//		if (!StringUtils.hasText(name) || !name.matches("^[a-zA-Z]+$") || name.length() < 2 || name.length() > 25) {
//			throw new InvalidNameException("Invalid name provided");
//		}
//
//		if (!StringUtils.hasText(email) || !email.matches("^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,}$")) {
//			throw new InvalidEmailFormatException("Invalid email format");
//		}
//		if (email == null) {
//			throw new InvalidEmailFormatException("Email cannot be null");
//		}
//
//		if (repository.existsByEmail(email)) {
//			throw new EmailAlreadyExistsException("Email Already Exists");
//		}
//	}
//
//	@SuppressWarnings({ "static-access" })
//	@PostMapping("/login")
//	public ResponseEntity<String> login(@RequestBody Login login) throws EmployeeNotFoundException {
//		String employeeId = login.getEmployeeId();
//		String password = login.getPassword();
//
//		if (!StringUtils.hasText(employeeId) || !StringUtils.hasText(password)) {
//			return ResponseEntity.badRequest().body("Employee ID and password are required");
//		}
//
//		StoreManager storeManager = repository.findByEmployeeId(employeeId);
//		if (storeManager == null) {
//			throw new EmployeeNotFoundException("Employee with ID " + employeeId + " not found");
//		}
//
//		if (!password.equals(storeManager.getPassword())) {
//			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid credentials");
//		}
//
//		if (storeManager.isVerified()) {
//			return ResponseEntity.ok("Login successful");
//		} else {
//			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Company's approval pending");
//		}
//	}
//
//	public void setManagerService(StoreManagerService managerService) {
//		this.managerService = managerService;
//	}
//
//	public void setRepository(StoreManagerRepository repository) {
//		this.repository = repository;
//	}
//
//	public void setStoreDetailsRepository(StoreDetailsRepository storeDetailsRepository) {
//		this.storeDetailsRepository = storeDetailsRepository;
//	}
//}
