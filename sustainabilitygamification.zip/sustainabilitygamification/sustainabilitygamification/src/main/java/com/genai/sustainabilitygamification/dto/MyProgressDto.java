package com.genai.sustainabilitygamification.dto;

public class MyProgressDto {

	private Long dollerSavings;
	private Long wasteSavings;
	private Long co2Savings;
	private int weeknumber;

	public MyProgressDto() {
	}

	public MyProgressDto(Long dollerSavings, Long wasteSavings, Long co2Savings, int weeknumber) {
		super();
		this.dollerSavings = dollerSavings;
		this.wasteSavings = wasteSavings;
		this.co2Savings = co2Savings;
		this.weeknumber = weeknumber;
	}

	public Long getDollerSavings() {
		return dollerSavings;
	}

	public void setDollerSavings(Long dollerSavings) {
		this.dollerSavings = dollerSavings;
	}

	public Long getWasteSavings() {
		return wasteSavings;
	}

	public void setWasteSavings(Long wasteSavings) {
		this.wasteSavings = wasteSavings;
	}

	public Long getCo2Savings() {
		return co2Savings;
	}

	public void setCo2Savings(Long co2Savings) {
		this.co2Savings = co2Savings;
	}

	public int getWeeknumber() {
		return weeknumber;
	}

	public void setWeeknumber(int weeknumber) {
		this.weeknumber = weeknumber;
	}

}
