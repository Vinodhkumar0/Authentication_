package com.genai.sustainabilitygamification.exception;

public class CustomException extends RuntimeException{
    public CustomException(String message) {
        super(message);
    }
}
