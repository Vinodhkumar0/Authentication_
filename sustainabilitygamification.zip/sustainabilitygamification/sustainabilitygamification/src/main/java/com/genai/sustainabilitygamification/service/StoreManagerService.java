package com.genai.sustainabilitygamification.service;

import com.genai.sustainabilitygamification.entity.StoreManager;

public interface StoreManagerService {
	StoreManager register(StoreManager storeManager);
}
