package com.genai.sustainabilitygamification.dto;

import java.time.LocalDate;

public class StoreManagerDto {

	private String name;
	private String employeeId;
	private String email;
	private LocalDate dateOfBirth;
	private String gender;
	private StoreDetailsDto storeDetails;

	public StoreManagerDto() {
	}

	public StoreManagerDto(String name, String employeeId, String email, LocalDate dateOfBirth, String gender,
			StoreDetailsDto storeDetails) {
		this.name = name;
		this.employeeId = employeeId;
		this.email = email;
		this.dateOfBirth = dateOfBirth;
		this.gender = gender;
		this.storeDetails = storeDetails;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public StoreDetailsDto getStoreDetails() {
		return storeDetails;
	}

	public void setStoreDetails(StoreDetailsDto storeDetails) {
		this.storeDetails = storeDetails;
	}

}
