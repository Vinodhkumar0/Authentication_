package com.genai.sustainabilitygamification.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.genai.sustainabilitygamification.entity.StoreDetails;

@Repository
public interface StoreDetailsRepository extends JpaRepository<StoreDetails, Long> {

}
