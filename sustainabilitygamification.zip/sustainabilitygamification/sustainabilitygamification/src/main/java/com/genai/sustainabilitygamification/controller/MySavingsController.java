package com.genai.sustainabilitygamification.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.genai.sustainabilitygamification.dto.MySavingsDto;
import com.genai.sustainabilitygamification.service.MySavingsService;


@CrossOrigin("*")
@RestController
public class MySavingsController {

	@Autowired
	public MySavingsService savingsService;

	@GetMapping("/MySavings/{employeeId}")
	public ResponseEntity<MySavingsDto> findSavingsByEmployeeId(@PathVariable String employeeId) {
		return ResponseEntity.ok(savingsService.getSavingsByEmployeeId(employeeId));
	}

}
