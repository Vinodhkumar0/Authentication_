package com.genai.sustainabilitygamification.service;

import com.genai.sustainabilitygamification.dto.RegisterDto;
import com.genai.sustainabilitygamification.entity.User;
import com.genai.sustainabilitygamification.exception.CustomException;
import com.genai.sustainabilitygamification.repository.UserRepository;
import com.genai.sustainabilitygamification.util.EmailUtil;
import com.genai.sustainabilitygamification.util.OtpUtil;
import jakarta.mail.MessagingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

import static com.genai.sustainabilitygamification.util.CreateChallengeUtil.USER_NOT_FOUND;

@Service
public class ForgotPasswordServiceImpl implements ForgotPasswordService {

    private final UserRepository userRepository;
    private final OtpUtil otpUtil;
    private final EmailUtil emailUtil;

    @Autowired
    public ForgotPasswordServiceImpl(UserRepository userRepository, OtpUtil otpUtil, EmailUtil emailUtil) {
        this.userRepository = userRepository;
        this.otpUtil = otpUtil;
        this.emailUtil = emailUtil;
    }

    @Override
    public String forgetPassword(String email) {
        String otp = otpUtil.generateOtp();
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new CustomException("User not found with this email: " + email));
        user.setOtp(otp);
        user.setOtpGeneratedTime(LocalDateTime.now());

        try {
            emailUtil.sendOtpEmail(email, otp);
        } catch (MessagingException e) {
            throw new CustomException("Unable to send otp please try again");
        }
        return "Forgot Password link is sent to your email";
    }

    @Override
    public String setPassword(String email, String newPassword) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new CustomException(USER_NOT_FOUND + email));
        userRepository.save(user);
        return "Password changed successfully....";
    }

    @Override
    public String register(RegisterDto registerDto) {
        User user = new User();
        user.setName(registerDto.getName());
        user.setEmail(registerDto.getEmail());
        user.setPassword(registerDto.getPassword());
        userRepository.save(user);
        return "User registration successful";
    }

}
