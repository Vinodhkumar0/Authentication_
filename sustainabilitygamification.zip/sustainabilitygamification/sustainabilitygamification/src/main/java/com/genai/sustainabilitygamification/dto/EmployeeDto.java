package com.genai.sustainabilitygamification.dto;

public class EmployeeDto {
	
	private String name;
	private int totalChallenges;
	private int winChallenges;
	private int enrolledChallenges;
	private int carbonSavingPoint;
	private String dollarSavingPoint;
	public EmployeeDto(String name, int totalChallenges, int winChallenges, int enrolledChallenges,
			int carbonSavingPoint, String dollarSavingPoint) {
		this.name = name;
		this.totalChallenges = totalChallenges;
		this.winChallenges = winChallenges;
		this.enrolledChallenges = enrolledChallenges;
		this.carbonSavingPoint = carbonSavingPoint;
		this.dollarSavingPoint = dollarSavingPoint;
	}
	public int getEnrolledChallenges() {
		return enrolledChallenges;
	}
	public String getName() {
		return name;
	}
	public int getTotalChallenges() {
		return totalChallenges;
	}
	public int getWinChallenges() {
		return winChallenges;
	}
	public int getCarbonSavingPoint() {
		return carbonSavingPoint;
	}
	public String getDollarSavingPoint() {
		return dollarSavingPoint;
	}

}
