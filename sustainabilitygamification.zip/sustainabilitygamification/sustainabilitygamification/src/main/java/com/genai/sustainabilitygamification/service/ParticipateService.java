package com.genai.sustainabilitygamification.service;

import java.util.List;

import com.genai.sustainabilitygamification.entity.ParticipateTab;

public interface ParticipateService {
    List<ParticipateTab> getParticipateList();
    ParticipateTab getParticipateById(int participateId);

    List<ParticipateTab> getAllParticipatesByUserId(int id);
}
