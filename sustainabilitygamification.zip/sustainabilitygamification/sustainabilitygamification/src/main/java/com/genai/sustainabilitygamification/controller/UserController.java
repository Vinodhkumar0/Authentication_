package com.genai.sustainabilitygamification.controller;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.genai.sustainabilitygamification.dto.LoginDto;
import com.genai.sustainabilitygamification.entity.AuthenticationResponse;
import com.genai.sustainabilitygamification.entity.RegisterResponse;
import com.genai.sustainabilitygamification.entity.User;
import com.genai.sustainabilitygamification.service.UserService;
import com.genai.sustainabilitygamification.service.UserServiceImpl;

@CrossOrigin("*")
@RestController
public class UserController {

    private final UserService userService;
    
    UserServiceImpl impl;

    @Autowired
    public UserController(UserService userService,UserServiceImpl impl) {
        this.userService = userService;
        this.impl=impl;
    }

    @PutMapping("/verify-account")
    public ResponseEntity<String> verifyAccount(@RequestParam String otp){
        return new ResponseEntity<>(userService.verifyAccount(otp), HttpStatus.OK);
    }
    @PutMapping("/regenerate-otp")
    public ResponseEntity<String> regenerateOtp(){
        return new ResponseEntity<>(userService.regenerateOtp(), HttpStatus.OK);
    }
    @PostMapping("/login")
    public ResponseEntity<AuthenticationResponse> login(@RequestBody User user){
        return  ResponseEntity.ok(impl.authenticate(user));
    }
    
    @GetMapping("/users")
    public List<User> getUsers() {
        return this.userService.findAll();
    }

    @GetMapping("/users/{id}")
	public Optional<User> getUser(@PathVariable Long id) {
		return this.userService.getUser(id);
	}
    
    @GetMapping("/employees-under-store-manager/{id}")
    @CrossOrigin("*")
	public List<User> employeesUnderStoreManager(@PathVariable Long id) {
		return this.userService.employeesUnderStoreManager(id);
	}
    
    @GetMapping("/managers-under-company/{id}")
    @CrossOrigin("*")
	public List<User> managersUnderCompany(@PathVariable Long id) {
		return this.userService.managersUnderCompany(id);
	}
    
    @PostMapping("/register")
    public RegisterResponse save(@RequestBody User user) {
       return this.userService.save(user);
    }
    
    @PutMapping("/{id}/approve")
    public ResponseEntity<User> approve(@PathVariable long id){
        return userService.approveUser(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}/decline")
    public ResponseEntity<User> decline(@PathVariable long id){
        return userService.declineUser(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    


}
