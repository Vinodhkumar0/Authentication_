package com.genai.sustainabilitygamification.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.genai.sustainabilitygamification.dto.ManagersDto;
import com.genai.sustainabilitygamification.service.ExportToExcelService;

import jakarta.servlet.http.HttpServletResponse;

@RestController
public class ExportToExcelController {
	
	@Autowired
	private ExportToExcelService impl;
	
	public ExportToExcelController(ExportToExcelService impl) {
		this.impl=impl;
	}
	
	@PostMapping("/excel")
	public void generateExcel(@RequestBody List<ManagersDto> details,HttpServletResponse response) throws IOException {
		
		response.setContentType("application/octet-stream");
		String headerKey="Content-Disposition";
		String headerValue="attachment;filename=details.xls";
		response.setHeader(headerKey, headerValue);
		impl.getstoreAllstoreDetails(details,response);
	}
}
