package com.genai.sustainabilitygamification.util;

public class CreateChallengeUtil {

    public static final String PUBLISHED_MESSAGE = "Challenge is Published";
    public static final String DRAFTED_MESSAGE = "Challenge is saved as draft";
    public static final String STATUS_PUBLISHED = "Published";
    public static final String STATUS_DRAFT = "Draft";
    public static final String USER_NOT_FOUND="User not found with this email: ";

    private CreateChallengeUtil(){

    }
}
