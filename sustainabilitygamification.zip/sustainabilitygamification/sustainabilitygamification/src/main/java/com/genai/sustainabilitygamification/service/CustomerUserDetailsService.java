//package com.genai.sustainabilitygamification.service;
//
//import static com.genai.sustainabilitygamification.util.CreateChallengeUtil.USER_NOT_FOUND;
//import static javax.management.timer.Timer.ONE_MINUTE;
//
//import java.time.Duration;
//import java.time.LocalDateTime;
//import java.util.List;
//import java.util.Optional;
//
//import org.springframework.security.authentication.AuthenticationManager;
//import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.crypto.password.PasswordEncoder;
//
//import com.genai.sustainabilitygamification.dto.LoginDto;
//import com.genai.sustainabilitygamification.entity.AuthenticationResponse;
//import com.genai.sustainabilitygamification.entity.Notification;
//import com.genai.sustainabilitygamification.entity.RegisterResponse;
//import com.genai.sustainabilitygamification.entity.StoreDetails;
//import com.genai.sustainabilitygamification.entity.Token;
//import com.genai.sustainabilitygamification.entity.User;
//import com.genai.sustainabilitygamification.exception.CustomException;
//import com.genai.sustainabilitygamification.repository.ChallengeEmployeeDetailRepository;
//import com.genai.sustainabilitygamification.repository.StoreDetailsRepository;
//import com.genai.sustainabilitygamification.repository.TokenRepository;
//import com.genai.sustainabilitygamification.repository.UserRepository;
//import com.genai.sustainabilitygamification.util.EmailUtil;
//import com.genai.sustainabilitygamification.util.OtpUtil;
//
//import jakarta.mail.MessagingException;
//
//public interface CustomerUserDetailsService extends UserDetailsService{
//
////	String regenerateOtp();
//
//	String login(LoginDto loginDto);
//
//	String verifyAccount(String otp);
//
//	List<User> findAll();
//
//	RegisterResponse save(User user);
//
//	Optional<User> getUser(Long id);
//
//	List<User> employeesUnderStoreManager(Long storeManagerId);
//
//	List<User> managersUnderCompany(Long id);
//
//	User getLatestRegisteredUser();
//
//	Optional<User> approveUser(long id);
//
//	Optional<User> declineUser(long id);
//
//	
//}
