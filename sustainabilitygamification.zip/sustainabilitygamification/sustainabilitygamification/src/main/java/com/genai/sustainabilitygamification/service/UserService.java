package com.genai.sustainabilitygamification.service;

import java.util.List;
import java.util.Optional;

import com.genai.sustainabilitygamification.dto.LoginDto;
import com.genai.sustainabilitygamification.entity.RegisterResponse;
import com.genai.sustainabilitygamification.entity.User;

public interface UserService {
    String verifyAccount(String otp);
    String regenerateOtp();
    String login(LoginDto loginDto);
    List<User> findAll();
	RegisterResponse save(User user);
	Optional<User> getUser(Long id);
	List<User> employeesUnderStoreManager(Long storeManagerId);
	List<User> managersUnderCompany(Long id);
	User getLatestRegisteredUser();
	Optional<User> approveUser(long id);
	Optional<User> declineUser(long id);
}
