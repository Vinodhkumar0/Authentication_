package com.genai.sustainabilitygamification.service;

import com.genai.sustainabilitygamification.dto.RegisterDto;

public interface ForgotPasswordService {
    String forgetPassword(String email);

    String setPassword(String email, String newPassword);

    String register(RegisterDto registerDto);

}
