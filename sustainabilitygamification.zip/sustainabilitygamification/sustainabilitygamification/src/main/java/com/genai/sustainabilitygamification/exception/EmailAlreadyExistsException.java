package com.genai.sustainabilitygamification.exception;

public class EmailAlreadyExistsException extends Exception {

	public EmailAlreadyExistsException(String msg) {

		super(msg);
	}
}
