package com.genai.sustainabilitygamification.exception;

public class InvalidPasswordFormatException extends Exception {
	public InvalidPasswordFormatException(String message) {
		super(message);
	}
}