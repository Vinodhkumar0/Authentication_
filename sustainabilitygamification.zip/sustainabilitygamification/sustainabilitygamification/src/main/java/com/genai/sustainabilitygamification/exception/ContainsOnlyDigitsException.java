package com.genai.sustainabilitygamification.exception;

public class ContainsOnlyDigitsException extends Exception {

	public ContainsOnlyDigitsException(String msg) {
		super(msg);
	}

}
