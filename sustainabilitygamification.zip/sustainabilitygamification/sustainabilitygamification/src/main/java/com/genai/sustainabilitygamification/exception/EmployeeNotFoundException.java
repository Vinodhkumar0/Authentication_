package com.genai.sustainabilitygamification.exception;

public class EmployeeNotFoundException extends Exception {

	public EmployeeNotFoundException(String msg) {
		super(msg);
	}
}
