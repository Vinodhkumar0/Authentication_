package com.genai.sustainabilitygamification.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.genai.sustainabilitygamification.entity.ParticipateTab;
import com.genai.sustainabilitygamification.service.ParticipateService;

import java.util.List;

@RestController
public class ParticipateController {

    private final ParticipateService participateService;

    @Autowired
    public ParticipateController(ParticipateService participateService) {
        this.participateService = participateService;
    }

    @GetMapping("/getAllParticipate")
    public List<ParticipateTab> getParticipateList() {
        return participateService.getParticipateList();
    }
    @GetMapping("/{participateId}")
    public ResponseEntity<ParticipateTab> getParticipate(@PathVariable int participateId) {
        ParticipateTab participate =
                participateService.getParticipateById(participateId);
        return new ResponseEntity<>(participate, HttpStatus.OK);
    }

    @GetMapping("/participate/{userId}")
    public List<ParticipateTab> getAllParticipatesByUserId(@PathVariable int userId){
        return participateService.getAllParticipatesByUserId(userId);
    }


}
