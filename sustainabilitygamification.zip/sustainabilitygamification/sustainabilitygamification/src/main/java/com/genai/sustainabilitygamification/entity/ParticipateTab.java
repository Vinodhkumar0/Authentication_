package com.genai.sustainabilitygamification.entity;

import jakarta.persistence.*;

import java.time.LocalDate;
import java.util.Date;

import org.springframework.cglib.core.Local;

@Entity
public class ParticipateTab {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int challengeId;
    private String challengeName;
    private LocalDate startDate;
    private LocalDate endDate;
    private String featuredBy;
    private String challengeStatus;
    private String createdBy;
	public ParticipateTab() {

	}
	public ParticipateTab(int challengeId, String challengeName, LocalDate startDate, LocalDate endDate, String featuredBy,
			String challengeStatus, String createdBy) {

		this.challengeId = challengeId;
		this.challengeName = challengeName;
		this.startDate = startDate;
		this.endDate = endDate;
		this.featuredBy = featuredBy;
		this.challengeStatus = challengeStatus;
		this.createdBy = createdBy;
	}
	public int getChallengeId() {
		return challengeId;
	}
	public void setChallengeId(int challengeId) {
		this.challengeId = challengeId;
	}
	public String getChallengeName() {
		return challengeName;
	}
	public void setChallengeName(String challengeName) {
		this.challengeName = challengeName;
	}
	public LocalDate getStartDate() {
		return startDate;
	}
	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}
	public LocalDate getEndDate() {
		return endDate;
	}
	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}
	public String getFeaturedBy() {
		return featuredBy;
	}
	public void setFeaturedBy(String featuredBy) {
		this.featuredBy = featuredBy;
	}
	public String getChallengeStatus() {
		return challengeStatus;
	}
	public void setChallengeStatus(String challengeStatus) {
		this.challengeStatus = challengeStatus;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
    
}
