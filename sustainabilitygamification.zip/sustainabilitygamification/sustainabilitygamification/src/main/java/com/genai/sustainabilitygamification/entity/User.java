	package com.genai.sustainabilitygamification.entity;
	
	import jakarta.persistence.CascadeType;
	import jakarta.persistence.Column;
	import jakarta.persistence.Entity;
	import jakarta.persistence.EnumType;
	import jakarta.persistence.Enumerated;
	import jakarta.persistence.GeneratedValue;
	import jakarta.persistence.GenerationType;
	import jakarta.persistence.Id;
	import jakarta.persistence.JoinColumn;
	import jakarta.persistence.OneToMany;
	import jakarta.persistence.OneToOne;
	import jakarta.persistence.Table;
	
	import java.time.LocalDate;
	import java.time.LocalDateTime;
	import java.util.Collection;
	import java.util.List;
	
	import org.springframework.security.core.GrantedAuthority;
	import org.springframework.security.core.authority.SimpleGrantedAuthority;
	import org.springframework.security.core.userdetails.UserDetails;
	
	@Entity
	@Table(name="user")
	public class User implements UserDetails {
	
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;
	    private String name;
	    private String email;
	    private String password;
	    private String gender;
	    private boolean isApproved;
	    public String getGender() {
			return gender;
		}
	
		public void setGender(String gender) {
			this.gender = gender;
		}
	
		public LocalDate getDateOfBirth() {
			return dateOfBirth;
		}
	
		public void setDateOfBirth(LocalDate dateOfBirth) {
			this.dateOfBirth = dateOfBirth;
		}
	
		private LocalDate dateOfBirth;
	    private String otp;
	    private LocalDateTime otpGeneratedTime;
	    
	    private Long empId;
	    private Long managerId;
	    public boolean isApproved() {
			return isApproved;
		}
	
		public void setApproved(boolean isApproved) {
			this.isApproved = isApproved;
		}
	
		@Enumerated(value = EnumType.STRING)
		private Role role;
		
		@OneToMany(mappedBy = "user")
		private List<Token> tokens;
	
	    
	    @OneToOne(cascade = CascadeType.ALL)
	    @JoinColumn(name = "store_details_id")
	    private StoreDetails storeDetails;
	    
	    @OneToMany
	    private List<User> employeesUnderStoreManager;
	    
	    @OneToMany
	    private List<ChallengeEmployeeDetail> challengeEmployeeDetail;
	    
	    private Long carbonSaving;
	    
	    private Long dollarSaving;
	    
	    private Long wasteSaving;
	    
	    private LocalDate regDate;
	 
		public Long getCarbonSaving() {
			return carbonSaving;
		}
	
		public void setCarbonSaving(Long carbonSaving) {
			this.carbonSaving = carbonSaving;
		}
	
		public Long getDollarSaving() {
			return dollarSaving;
		}
	
		public void setDollarSaving(Long dollarSaving) {
			this.dollarSaving = dollarSaving;
		}
	
		public Long getWasteSaving() {
			return wasteSaving;
		}
	
		public void setWasteSaving(Long wasteSaving) {
			this.wasteSaving = wasteSaving;
		}
	
		public StoreDetails getStoreDetails() {
			return storeDetails;
		}
	
		public void setStoreDetails(StoreDetails storeDetails) {
			this.storeDetails = storeDetails;
		}
	
		public List<User> getEmployeesUnderStoreManager() {
			return employeesUnderStoreManager;
		}
	
		public void setEmployeesUnderStoreManager(List<User> list) {
			this.employeesUnderStoreManager = list;
		}
	
		public User() {
	
	    }
	
	    public User(Long id, String name, String email, String password, boolean isApproved, String otp,
	                LocalDateTime otpGeneratedTime,Long empId) {
	        this.id = id;
	        this.name = name;
	        this.email = email;
	        this.empId=empId;
	        this.password = password;
	        this.otp = otp;
	        this.otpGeneratedTime = otpGeneratedTime;
	        this.isApproved = isApproved;
	    }
	
	    public Long getId() {
	        return id;
	    }
	
	    public void setId(Long id) {
	        this.id = id;
	    }
	
	    public String getName() {
	        return name;
	    }
	
	    public void setName(String name) {
	        this.name = name;
	    }
	
	    public String getEmail() {
	        return email;
	    }
	
	    public void setEmail(String email) {
	        this.email = email;
	    }
	
	    public String getPassword() {
	        return password;
	    }
	
	    public void setPassword(String password) {
	        this.password = password;
	    }
	
	   
	
	    public String getOtp() {
	        return otp;
	    }
	
	    public void setOtp(String otp) {
	        this.otp = otp;
	    }
	
	    public LocalDateTime getOtpGeneratedTime() {
	        return otpGeneratedTime;
	    }
	
	    public void setOtpGeneratedTime(LocalDateTime otpGeneratedTime) {
	        this.otpGeneratedTime = otpGeneratedTime;
	    }
	
		public Long getEmpId() {
			return empId;
		}
	
		public void setEmpId(Long empId) {
			this.empId = empId;
		}
	
		public Long getManagerId() {
			return managerId;
		}
	
		public void setManagerId(Long managerId) {
			this.managerId = managerId;
		}
	
		public Role getRole() {
			return role;
		}
	
		public void setRole(Role role) {
			this.role = role;
		}
	
		public List<ChallengeEmployeeDetail> getChallengeEmployeeDetail() {
			return challengeEmployeeDetail;
		}
	
		public void setChallengeEmployeeDetail(List<ChallengeEmployeeDetail> challengeEmployeeDetail) {
			this.challengeEmployeeDetail = challengeEmployeeDetail;
		}
	
		public LocalDate getRegDate() {
			return regDate;
		}
	
		public void setRegDate(LocalDate regDate) {
			this.regDate = regDate;
		}
	
		@Override
		public String toString() {
			return "User [id=" + id + ", name=" + name + ", email=" + email + ", password=" + password + ", gender="
					+ gender + ", isApproved=" + isApproved + ", dateOfBirth=" + dateOfBirth + ", otp=" + otp
					+ ", otpGeneratedTime=" + otpGeneratedTime + ", empId=" + empId + ", managerId=" + managerId + ", role="
					+ role + ", storeDetails=" + storeDetails + ", employeesUnderStoreManager=" + employeesUnderStoreManager
					+ ", challengeEmployeeDetail=" + challengeEmployeeDetail + ", carbonSaving=" + carbonSaving
					+ ", dollarSaving=" + dollarSaving + ", wasteSaving=" + wasteSaving + ", regDate=" + regDate + "]";
		}
	
		@Override
		public Collection<? extends GrantedAuthority> getAuthorities() {
			System.out.println(role.name());
			return List.of(new SimpleGrantedAuthority("Role"+ role.name()));
		}
	
		
		@Override
		public String getUsername() {
			// TODO Auto-generated method stub
			return name;
		}
		@Override
		public boolean isAccountNonExpired() {
			return true;
		}
	
		@Override
		public boolean isAccountNonLocked() {
			return true;
		}
	
		@Override
		public boolean isCredentialsNonExpired() {
			return true;
		}
	
		@Override
		public boolean isEnabled() {
			return true;
		}
	
		
	}
