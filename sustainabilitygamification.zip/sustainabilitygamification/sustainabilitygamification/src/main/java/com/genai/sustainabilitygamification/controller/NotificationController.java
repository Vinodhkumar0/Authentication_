package com.genai.sustainabilitygamification.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;

import com.genai.sustainabilitygamification.entity.ChallengeEmployeeDetail;
import com.genai.sustainabilitygamification.entity.CreateChallenges;
import com.genai.sustainabilitygamification.entity.Notification;
import com.genai.sustainabilitygamification.entity.User;
import com.genai.sustainabilitygamification.repository.ChallengeEmployeeDetailRepository;
import com.genai.sustainabilitygamification.repository.CreateChallengesRepository;

import com.genai.sustainabilitygamification.repository.UserRepository;
import com.genai.sustainabilitygamification.service.NotificationService;

@CrossOrigin("*")
@RestController
public class NotificationController {

	private NotificationService notificationService;

	ChallengeEmployeeDetailRepository challengeEmployeeDetailRepository;

	UserRepository repository;

	CreateChallengesRepository challengesRepository;

	@Autowired
	public NotificationController(NotificationService notificationService,
			ChallengeEmployeeDetailRepository challengeEmployeeDetailRepository, UserRepository repository,
			CreateChallengesRepository challengesRepository) {
		this.notificationService = notificationService;
		this.challengeEmployeeDetailRepository = challengeEmployeeDetailRepository;
		this.repository = repository;
		this.challengesRepository = challengesRepository;
	}

	@PostMapping("/createNotification")
	public Notification createNotification(@RequestBody Notification notification) {
		return notificationService.createNotification(notification);
	}

	@GetMapping("/notifications/{status}")
	public List<Notification> getNotifications(@PathVariable String status) {
		return notificationService.getNotificationsByStatus(status);
	}

	@GetMapping("/getallnotifications")
	public List<Notification> getAllNotifications() {
		return notificationService.getAllNotifications();
	}

	@PutMapping("/notifications/markAsRead/{id}")
	public String markNotificationAsRead(@PathVariable Long id) {
		notificationService.markAsRead(id);
		return "Notification is Read";
	}

	@DeleteMapping("/deleteNotification/{id}")
	public String deleteNotificationById(@PathVariable Long id) {
		boolean delete = notificationService.deleteByNotificationId(id);
		if (delete) {
			return "Notification has been deleted";
		} else {
			return "Not deleted";
		}
	}

	@PatchMapping("/markallasread")
	public void markAsAllRead() {
		notificationService.markAsAllRead();
	}

	@GetMapping("/getenroll/{id}")
	public void getChallengeEnroll(@PathVariable Long id) {
		@SuppressWarnings("deprecation")
		Optional<ChallengeEmployeeDetail> challengeEmployeeDetail = Optional
				.ofNullable(challengeEmployeeDetailRepository.getById(id));
		if (challengeEmployeeDetail.isPresent()) {
			ChallengeEmployeeDetail detail = challengeEmployeeDetail.get();
			System.out.println("detial" + detail);
			Long empId = detail.getEmployeeAutoId();
			System.out.println(empId); 
			Optional<User> user = repository.findById(empId);
			@SuppressWarnings("deprecation")
			Optional<CreateChallenges> challenges = Optional.of(challengesRepository.getById(empId));
			CreateChallenges createChallenges = challenges.get();
			System.out.println(user.toString());
			if (user.isPresent()) {
				User user2 = user.get();
				System.out.println(user2.toString());
				Notification notification = new Notification();
				notification.setEmpId(user2.getEmpId());
				notification.setEmpName(user2.getName());
				notification.setChallengeName(createChallenges.getChallengeName());
				notification.setStatus(detail.getChallengeStatus());
				notificationService.createNotification(notification);
			}
		}

	}
}