package com.genai.sustainabilitygamification.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.genai.sustainabilitygamification.entity.StoreDetails;
import com.genai.sustainabilitygamification.entity.StoreManager;

@Repository
public interface StoreManagerRepository extends JpaRepository<StoreManager, Long> {

	boolean existsByEmail(String email);

	boolean existsByEmployeeId(String employeeId);

	StoreManager findByEmployeeId(String employeeId);

	void save(StoreDetails storeDetails);
}
