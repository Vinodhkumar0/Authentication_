package com.genai.sustainabilitygamification.service;

import java.io.IOException;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.stereotype.Service;

import com.genai.sustainabilitygamification.dto.EmployeeDto;
import com.genai.sustainabilitygamification.dto.ManagersDto;

import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;

@Service
public class ExportToExcelService {

	public void getstoreAllstoreDetails(List<ManagersDto> detail,HttpServletResponse response) throws IOException {
		HSSFWorkbook workbook=new HSSFWorkbook();
		HSSFSheet sheet=workbook.createSheet("StoreManagers Info");
		HSSFRow row=sheet.createRow(0);
		
		row.createCell(0).setCellValue("Manager Name");
		row.createCell(1).setCellValue("EmployeeId");
		row.createCell(2).setCellValue("Email");
		row.createCell(3).setCellValue("Store Name");
		row.createCell(4).setCellValue("State");
		row.createCell(5).setCellValue("Reg.Date");
		
		int dataRowIndex=1;
		 
		for(ManagersDto details:detail) {
			
			HSSFRow dataRow =sheet.createRow(dataRowIndex);
			dataRow.createCell(0).setCellValue(details.getManagerName());
			dataRow.createCell(1).setCellValue(details.getEmployeeId());
			dataRow.createCell(2).setCellValue(details.getEmail());
			dataRow.createCell(3).setCellValue(details.getStoreName());
			dataRow.createCell(4).setCellValue(details.getState());
			dataRow.createCell(5).setCellValue(details.getRegDate());
			if(details.getEmployees()!=null&&details.getEmployees().size()!=0) {
				dataRow.createCell(6).setCellValue("Employee Name");
				dataRow.createCell(7).setCellValue("Total Challenges");
				dataRow.createCell(8).setCellValue("WinChallenges");
				dataRow.createCell(9).setCellValue("EnrolledChallenges");
				dataRow.createCell(10).setCellValue("CarbonSavingPoint");
				dataRow.createCell(11).setCellValue("DollarSavingPoint");
				dataRowIndex++;
				for(EmployeeDto e:details.getEmployees()) {
					HSSFRow EmpRow =sheet.createRow(dataRowIndex);
					EmpRow.createCell(6).setCellValue(e.getName());
					EmpRow.createCell(7).setCellValue(e.getTotalChallenges());
					EmpRow.createCell(8).setCellValue(e.getWinChallenges());
					EmpRow.createCell(9).setCellValue(e.getEnrolledChallenges());
					EmpRow.createCell(10).setCellValue(e.getCarbonSavingPoint());
					EmpRow.createCell(11).setCellValue(e.getDollarSavingPoint());
					dataRowIndex++;
				}
				
				
			}
			dataRowIndex++;
		}
		
		ServletOutputStream outputStream=response.getOutputStream();
		workbook.write(outputStream);
		workbook.close();
		outputStream.close();
		
	}
}

