package com.genai.sustainabilitygamification.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.genai.sustainabilitygamification.dto.MyChallengesDto;
import com.genai.sustainabilitygamification.service.MyChallengesService;


@CrossOrigin("*")
@RestController
public class MyChallengesController {

	@Autowired
	public MyChallengesService challengesService;

	@GetMapping("/MyChallenges/{employeeId}")
	public ResponseEntity<MyChallengesDto> findChallengeDetailsByEmployeeID(@PathVariable String employeeId) {
		return ResponseEntity.ok(challengesService.getMychallegesByEmployeeId(employeeId));
	}
}
