package com.genai.sustainabilitygamification.util;

import org.springframework.stereotype.Component;

import java.security.SecureRandom;

@Component
public class OtpUtil {
    private SecureRandom random = new SecureRandom();

    public String generateOtp() {
        int randomNum = this.random.nextInt(999999);
        return String.format("%06d", randomNum);
    }
}
