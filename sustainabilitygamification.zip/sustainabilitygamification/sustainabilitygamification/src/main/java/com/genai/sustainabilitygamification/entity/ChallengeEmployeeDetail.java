package com.genai.sustainabilitygamification.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="challenge_employee_detail")
public class ChallengeEmployeeDetail {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private Long employeeAutoId;
	
	private Long challengeId;
	
	private String challengeStatus;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getEmployeeAutoId() {
		return employeeAutoId;
	}

	public void setEmployeeAutoId(Long employeeAutoId) {
		this.employeeAutoId = employeeAutoId;
	}

	public Long getChallengeId() {
		return challengeId;
	}

	public void setChallengeId(Long challengeId) {
		this.challengeId = challengeId;
	}

	public String getChallengeStatus() {
		return challengeStatus;
	}

	public void setChallengeStatus(String challengeStatus) {
		this.challengeStatus = challengeStatus;
	}

	@Override
	public String toString() {
		return "ChallengeEmployeeDetail [id=" + id + ", employeeAutoId=" + employeeAutoId + ", challengeId="
				+ challengeId + ", challengeStatus=" + challengeStatus + "]";
	}
}
