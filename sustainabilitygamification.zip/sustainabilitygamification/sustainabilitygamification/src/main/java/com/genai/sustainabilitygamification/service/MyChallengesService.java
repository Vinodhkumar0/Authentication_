package com.genai.sustainabilitygamification.service;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genai.sustainabilitygamification.dto.MyChallengesDto;
import com.genai.sustainabilitygamification.entity.MyProgress;
import com.genai.sustainabilitygamification.entity.Participate;
import com.genai.sustainabilitygamification.repository.ParticipateRepository;



@Service
public class MyChallengesService {

	@Autowired
	ParticipateRepository participateRepository;

	public MyChallengesDto getMychallegesByEmployeeId(String employeeId) {
		int ongoingChallenges = 0;
		int completedChallenges = 0;
		int ownedChallenges = 0;
		List<Participate> part=participateRepository.findAll();
		for(Participate i:part) {
			if (i.getCreatedBy().equalsIgnoreCase(employeeId)) {
				ownedChallenges++;
			}
		}
		List<Participate> participates = participateRepository.findByEmployeeId(employeeId);
		
		for (Participate p : participates) {
			if (p.getChallengeStatus().equalsIgnoreCase("enrolled")
					|| p.getChallengeStatus().equalsIgnoreCase("defaultenrolled")) {
				LocalDate startDate = p.getStartDate();
				LocalDate endDate = p.getEndDate();
				LocalDate today = LocalDate.now();
				if (startDate.isBefore(today) && endDate.isAfter(today)) {
					ongoingChallenges++;
				}
				if (endDate.isBefore(today)) {
					List<MyProgress> list = p.getMyProgress();
					list.sort(Comparator.comparing(MyProgress::getDate).reversed());
					if (list.stream().findFirst().get().getProgressPercentage() == 100) {
						completedChallenges++;
					}
				}
				
			}
		}
		return new MyChallengesDto(completedChallenges, ongoingChallenges, ownedChallenges);
	}

}
