package com.genai.sustainabilitygamification.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.genai.sustainabilitygamification.entity.User;

import java.util.List;
import java.util.Optional;


public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);
    List<User> findByManagerId(Long id);
    
    @Query("SELECT r FROM User r ORDER BY r.otpGeneratedTime DESC LIMIT 1")
    User findTheLatestEmail();

    @Query("Select e from User e where e.empId=?1")
    Optional<User> findByEmpId(Long id);

}
