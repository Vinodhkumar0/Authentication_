package com.genai.sustainabilitygamification.entity;


import java.time.LocalDate;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;

@Entity
public class CreateChallenges {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String challengeName;
	private String description;
	private String evaluationKpi;
	private String eligibility;
	private String createdBy;
	private String dataRequired;
	@OneToMany
	@JoinColumn(name = "type_of_savings_id")
	private List<TypeOfSavings> typeOfSavings;
	@OneToOne
	@JoinColumn(name = "awards_id")
	private Awards awards;
	private LocalDate startDate;
	private LocalDate endDate;
	private LocalDate winnerAnnouncementDate;
	private String status;
	private String challengeStatus;
	private String featuredBy;

	public CreateChallenges() {

	}

	public CreateChallenges(Long id, String challengeName, String evaluationKpi, String eligibility, String createdBy,
			String dataRequired, List<TypeOfSavings> typeOfSavings, Awards awards, LocalDate startDate,
			LocalDate endDate, LocalDate winnerAnnouncementDate, String status, String featuredBy) {
		super();
		this.id = id;
		this.challengeName = challengeName;
		this.evaluationKpi = evaluationKpi;
		this.eligibility = eligibility;
		this.createdBy = createdBy;
		this.dataRequired = dataRequired;
		this.typeOfSavings = typeOfSavings;
		this.awards = awards;
		this.startDate = startDate;
		this.endDate = endDate;
		this.winnerAnnouncementDate = winnerAnnouncementDate;
		this.status = status;
		this.setFeaturedBy(featuredBy);
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getChallengeName() {
		return challengeName;
	}

	public void setChallengeName(String challengeName) {
		this.challengeName = challengeName;
	}

	public String getEvaluationKpi() {
		return evaluationKpi;
	}

	public void setEvaluationKpi(String evaluationKpi) {
		this.evaluationKpi = evaluationKpi;
	}

	public String getEligibility() {
		return eligibility;
	}

	public void setEligibility(String eligibility) {
		this.eligibility = eligibility;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getDataRequired() {
		return dataRequired;
	}

	public void setDataRequired(String dataRequired) {
		this.dataRequired = dataRequired;
	}

	public List<TypeOfSavings> getTypeOfSavings() {
		return typeOfSavings;
	}

	public void setTypeOfSavings(List<TypeOfSavings> typeOfSavings) {
		this.typeOfSavings = typeOfSavings;
	}

	public Awards getAwards() {
		return awards;
	}

	public void setAwards(Awards awards) {
		this.awards = awards;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public LocalDate getWinnerAnnouncementDate() {
		return winnerAnnouncementDate;
	}

	public void setWinnerAnnouncementDate(LocalDate winnerAnnouncementDate) {
		this.winnerAnnouncementDate = winnerAnnouncementDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getChallengeStatus() {
		return challengeStatus;
	}

	public void setChallengeStatus(String challengeStatus) {
		this.challengeStatus = challengeStatus;
	}

	public String getFeaturedBy() {
		return featuredBy;
	}

	public void setFeaturedBy(String featuredBy) {
		this.featuredBy = featuredBy;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
