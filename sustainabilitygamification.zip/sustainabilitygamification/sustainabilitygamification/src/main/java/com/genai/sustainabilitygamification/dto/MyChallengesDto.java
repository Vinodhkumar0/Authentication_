package com.genai.sustainabilitygamification.dto;

public class MyChallengesDto {

	private int completedChallenges;
	private int ongoingChallenges;
	private int ownedChallenges;

	public MyChallengesDto() {
	}

	public MyChallengesDto(int completedChallenges, int ongoingChallenges, int ownedChallenges) {
		super();
		this.completedChallenges = completedChallenges;
		this.ongoingChallenges = ongoingChallenges;
		this.ownedChallenges = ownedChallenges;
	}

	public int getCompletedChallenges() {
		return completedChallenges;
	}

	public void setCompletedChallenges(int completedChallenges) {
		this.completedChallenges = completedChallenges;
	}

	public int getOngoingChallenges() {
		return ongoingChallenges;
	}

	public void setOngoingChallenges(int ongoingChallenges) {
		this.ongoingChallenges = ongoingChallenges;
	}

	public int getOwnedChallenges() {
		return ownedChallenges;
	}

	public void setOwnedChallenges(int ownedChallenges) {
		this.ownedChallenges = ownedChallenges;
	}

}
